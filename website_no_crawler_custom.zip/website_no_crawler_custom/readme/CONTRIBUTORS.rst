* Roel Adriaans <roel.adriaans@b-informed.nl>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
* Kaushal Prajapati <kbprajapati@live.com>
