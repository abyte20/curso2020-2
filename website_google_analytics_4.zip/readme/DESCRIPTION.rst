This module overrides the Google Analytic script in favor of integrating with Google analytic version 4.
