## Module <login_user_detail>

#### 10.03.2019
#### Version 13.0.1.0.0
#### ADD
- Initial Commit for login_user_detail
