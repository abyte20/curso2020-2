# Corrección de traducción del portal · website_profile_custom · Odoo 13

Parche sobre el módulo instalado que has enviado. Corrige el fallo de la vista `website_profile_custom.portal_layout` al abrir el editor de traducciones. Versión técnica resultante: `13.0.1.0.1`.

## Causa

El selector anterior buscaba un `<li>` cuyo texto directo fuese exactamente `Details` o `Detalles`. El editor de traducciones de Odoo 13 envuelve los textos en elementos `<span data-oe-translation-id="...">`, de modo que el selector deja de encontrar el elemento y se interrumpe la construcción de la página.

El selector nuevo localiza la condición estable `t-if="page_name == 'my_details'"`, que identifica ese elemento en la plantilla oficial de Odoo 13. Conserva el rótulo personalizado `Invoicing details` y su traducción existente.

El parche contiene solo `views/portal_templates.xml` y `__manifest__.py`. No incorpora los estados de actividad propuestos para TuxAIA. No requiere restaurar vistas.

## Instalación

Sube `website_profile_custom_traduccion_fix.zip` a `/home/od/` y ejecuta como usuario `od`:

```bash
cd /home/od
unzip website_profile_custom_traduccion_fix.zip
cd website_profile_custom_traduccion_fix
python3 instalar.py --check /home/od/odoo/slimbook
```

Debe indicar 2 archivos pendientes sobre la versión enviada. Si detecta diferencias, se detiene; conserva la salida para revisarla. Si la comprobación es correcta:

```bash
python3 instalar.py /home/od/odoo/slimbook
```

El instalador crea una copia de los archivos anteriores en la carpeta `copias`, junto al instalador, y muestra su ruta. No cambia la base de datos. Conserva esa carpeta.

En Odoo abre **Aplicaciones**, quita el filtro «Aplicaciones», busca **website_profile_custom** y pulsa **Actualizar**. Este paso carga el XML corregido en la base de datos. Al cambiar únicamente XML y el manifiesto, no se requiere un reinicio del servicio para cargar código Python.

Después recarga `/en/support` con `Ctrl+F5` y entra en **Traducir**. Verifica también `/support` y la ruta del portal **Mi cuenta → datos de facturación**. No pulses «Restaurar vistas» para aplicar esta corrección.

Si todavía aparece el mismo error después de actualizar, envía la traza completa; una variante personalizada de la vista en la base de datos puede requerir revisión adicional.

## Revertir archivos

Utiliza la ruta exacta de la copia impresa por el instalador:

```bash
python3 instalar.py --restore /ruta/real/website_profile_translation_backup_XXXX /home/od/odoo/slimbook
```

Después actualiza `website_profile_custom` en Odoo para que vuelva a cargar el XML anterior. Esta reversión recupera también el selector que falla en el editor de traducciones. La restauración se detiene si encuentra cambios posteriores en los archivos.

## Verificación

- Reproducido el error del selector original con el marcado del editor de traducciones de Odoo 13.
- Aplicada la herencia mediante la función oficial `apply_inheritance_specs` de Odoo 13 sobre su plantilla `portal_breadcrumbs`.
- Ocho combinaciones de rótulos e inicio del editor aceptadas por el selector corregido; se mantiene el enlace al inicio del portal y el rótulo de facturación.
- Sintaxis XML/Python, comprobación sin cambios, instalación, repetición, protección ante modificaciones y restauración exacta de archivos verificadas.

Las pruebas son aisladas. Falta comprobar la actualización en vuestro Odoo y la combinación con todas las vistas instaladas en su base de datos.

Fuentes oficiales utilizadas:

- https://raw.githubusercontent.com/odoo/odoo/13.0/addons/portal/views/portal_templates.xml
- https://raw.githubusercontent.com/odoo/odoo/13.0/odoo/tools/template_inheritance.py
- https://raw.githubusercontent.com/odoo/odoo/13.0/addons/web_editor/models/ir_translation.py
