# Copyright 2024 Slimbook - Luis Herrera
# Copyright 2025 Slimbook - Samanta Sánchez

{
    "name": "Website profile custom",
    "summary": "Adds a sales order tab to the user's profile",
    "version": "13.0.1.0.1",
    "category": "website",
    "website": "https://slimbook.com/",
    "author": "Slimbook - Luis Herrera, Samanta Sánchez",
    "license": "AGPL-3",
    "application": False,
    "installable": True,
    "depends": ["website","website_profile","sale"],
    "data": [
        "views/website_profile.xml",
        "views/portal_templates.xml"
    ],
}
