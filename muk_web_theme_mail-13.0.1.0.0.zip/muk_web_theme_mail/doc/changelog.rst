`1.1.0`
-------

- Mobile Chatter

`1.0.0`
-------

- Init version
