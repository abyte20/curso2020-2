from odoo import fields, models


class SlimAIASettings(models.TransientModel):
    _inherit = 'res.config.settings'

    slimaia_sales_model_id = fields.Char(
        string='Sales model ID', config_parameter='website_openwebui_chat.openwebui_sales_model',
        help='Exact Open WebUI preset ID. Leave empty to use the existing model setting. Prompt and parameters stay in Open WebUI.')
    slimaia_support_model_id = fields.Char(
        string='Support model ID', config_parameter='website_openwebui_chat.openwebui_support_model',
        help='Exact Open WebUI preset ID. Leave empty to keep Support unavailable.')
