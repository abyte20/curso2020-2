# SlimAIA · revisión v5

Esta entrega implementa los cambios de interfaz y separación de agentes, y añade evidencia para investigar la recuperación de conocimientos. **No presenta como resuelto el fallo de documentación de tu instancia.** No tengo acceso a esa instancia ni a su clave. Las respuestas del modelo de las pruebas locales son simuladas.

## Qué se sabe del fallo

El registro v4.1 muestra actualizaciones antes del final, un turno guardado y cero búsquedas/lecturas de herramientas observadas. `profile_prompt_present: null` significa que la API no deja ver ese dato; no prueba ausencia de prompt. `configured_model_matches_profile: true` compara IDs, no demuestra el prompt efectivo. Los contadores tampoco detectan necesariamente contexto inyectado mediante RAG clásico.

Hay una diferencia concreta que hay que contrastar: el diagnóstico D que dio resultado enviaba `params.function_calling: native`. V4.1 hereda ese ajuste del servidor. No se vuelve a forzar aquí, porque debes controlar prompt y parámetros desde Open WebUI. Tampoco se añaden instrucciones como «consulta siempre los documentos» ni se modifica la pregunta.

El código publicado de Open WebUI 0.11.4 combina los parámetros globales con los del perfil y los de la petición. Los parámetros del perfil pueden estar ocultos para la credencial de lectura aunque el servidor los aplique. En modo nativo, la presencia de herramientas disponibles no garantiza que el modelo las utilice.

## Comparar primero, sin reinstalar Odoo

1. Abre el fichero `comparar_peticion_openwebui.js` y copia su contenido completo en la consola de **Open WebUI**, no en Odoo.
2. Selecciona el perfil de Ventas que allí funciona y haz la misma pregunta concreta: «Consulta la documentación del Creative y dime su CPU y la capacidad de su batería». Conserva también si la respuesta de Open WebUI es correcta y si usó herramientas.
3. Ejecuta allí:

```javascript
JSON.stringify(SlimAIACompare.snapshot(), null, 2)
```

4. Comparte ese resultado junto con `SlimAIADebug.snapshot()` de Odoo para esa misma pregunta. No pegues cabeceras ni cookies. Una conversación con historial distinto puede producir una respuesta distinta; el informe incluye el número de mensajes para detectar esa diferencia.

El comparador observa la petición existente: no realiza consultas adicionales, no la modifica y no captura cabeceras, tokens, preguntas, respuestas, documentos o el texto del prompt. Registra el ID del modelo, parámetros numéricos y opciones técnicas; conserva como máximo cinco peticiones. No demuestra por sí mismo el prompt efectivo posterior a los filtros del servidor. Se retira recargando o con `SlimAIACompare.stop()`.

Si aparece `request_parameters.function_calling: native` en la web pero el perfil hereda otro valor, el ajuste debe hacerse conscientemente en el perfil de Open WebUI. Si los IDs difieren, hay que corregir el ID de Odoo. No se toma ninguna de esas hipótesis como confirmada antes de ver la comparación.

## Interfaz y agentes incluidos

- Cabecera con icono pequeño y «SlimAIA - Asistente Inteligencia Artificial»; en inglés, «SlimAIA - Artificial Intelligence Assistant».
- Selector azul compacto «Hablar con: Ventas / Soporte», bajo el título, sin estrechar el campo de mensaje. Se bloquea mientras se envía una respuesta.
- El icono original de Tux aparece en el botón cerrado, sin modificar el fichero gráfico.
- Carga: «SlimAIA está pensando…» / «SlimAIA is thinking…».
- Aviso pequeño: «La IA puede cometer errores. Comprueba la información importante.» / «AI can make mistakes. Check important information.».
- Idioma de la interfaz según `html.lang` de la página Odoo (`es`, `es-ES`, `en`, `en-US`, etc.). Esto no impone un idioma al modelo: su respuesta sigue las instrucciones de Open WebUI y la conversación.
- Persistencia del estado abierto/cerrado y agente seleccionado en el navegador. Los mensajes se recuperan del chat asociado a la sesión Odoo. No se confía en un ID remoto aportado por el navegador.
- Cada agente conserva su propio chat. Cambiar de agente no crea una generación ni un chat remoto; el primer envío crea su chat y los siguientes reutilizan ese mismo chat.
- El historial de Ventas de v4.1 se mantiene si no cambian identidad, URL, clave o modelo. Soporte comienza separado. Los chats antiguos permanecen en Open WebUI.
- Chats nuevos: prefijo Ventas/Soporte seguido del correo del usuario autenticado, o fecha/hora y tres dígitos aleatorios para visitantes.
- Soporte sin configurar muestra que aún no está disponible y permite volver a Ventas. Nunca utiliza silenciosamente el perfil de Ventas.

## Instalar la revisión de interfaz y diagnóstico

Descomprime **todo** el ZIP en una carpeta y, desde ella:

```bash
python3 instalar.py /home/od/odoo/slimbook/website_openwebui_chat
```

El instalador conserva una copia privada en `/tmp/website_openwebui_chat_backup_v5_…`. Añade los campos de IDs de agente a Ajustes, incorpora una vista al manifiesto y un import al inicializador conservando su contenido y autoría. Copia controlador, widget, CSS, icono y auxiliares. No cambia las plantillas existentes, claves, documentos, perfiles ni chats de Open WebUI. No requiere instalar paquetes Python en Odoo.

Después reinicia Odoo y **actualiza `website_openwebui_chat` en Aplicaciones**; es necesario cargar los nuevos campos y la vista. Recarga la web con Ctrl+F5. En la consola debe aparecer `native-profile-v5`.

En **Ajustes → SlimAIA**, indica:

- **Sales model ID**: ID exacto del perfil de Ventas, por ejemplo `ventas-clone` si sigue siendo el correcto. Vacío conserva el modelo configurado en el ajuste anterior del addon.
- **Support model ID**: ID exacto del perfil de Soporte que hayas creado en Open WebUI. Se deja vacío hasta que exista; no se inventa uno.

Ambos perfiles deben ser accesibles para la clave API configurada. Usa perfiles personalizados, no el ID del motor base. Cada perfil conserva su prompt, parámetros y conocimientos en Open WebUI. No hay campos de prompt en Odoo.

Los nuevos parámetros son `website_openwebui_chat.openwebui_sales_model` y `website_openwebui_chat.openwebui_support_model`. Ventas vacío hereda `website_openwebui_chat.openwebui_model` (ya existente). Se usan campos distintos para evitar que otros campos antiguos de Ajustes sobrescriban el nuevo valor al guardar. La URL y la clave continúan siendo las existentes.

## Qué verifica ahora el registro

Se toman las opciones de funciones predeterminadas de la metadata publicada del modelo, que puede incluir valores heredados; v4.1 solo usaba la metadata del perfil sin resolver. Esto corrige esa diferencia de configuración, pero no prueba que sea la causa del fallo de conocimientos.

Se consulta el perfil y `/api/models`, como hace la web de Open WebUI, antes de preparar cada generación. Se exige que el ID del perfil coincida y esté publicado para esta credencial. El log añade:

- `requested_model_id`, `profile_base_model_id`: IDs comprobables, no claves.
- `profile_knowledge_count`, `published_knowledge_count`: asociaciones del perfil y de la lista de modelos; no número de documentos recuperados.
- `published_builtin_tools_enabled`, `published_knowledge_tools_enabled`: capacidades publicadas, no prueba de las herramientas que recibió el proveedor.
- `base_model_visible`: visibilidad de la base para esta clave. Un `false` puede deberse a permisos y no demuestra un motor ausente.
- `effective_prompt_verified: false`, `effective_tools_verified: false`: esta API no permite acreditar el cuerpo efectivo recibido por el motor.

El límite sigue siendo 60 registros por página; no se registra cada fragmento de texto. Para compartirlos:

```javascript
JSON.stringify(SlimAIADebug.snapshot(), null, 2)
```

## Texto progresivo

Se conserva el transporte que ya funciona con tu clave API: una generación por turno y lectura del estado en curso como máximo una vez por segundo, solo durante ese turno. Open WebUI 0.11.4 incorpora su respuesta en curso al recuperar el chat. Se envían los cambios al widget conforme llegan.

**Son actualizaciones por bloques, no streaming de cada token mediante socket.** No se añade un efecto visual de escritura para ocultarlo. El historial completo devuelto por la API supone un coste creciente; no hay sondeo en reposo. Con un JWT se conserva la vía de eventos existente, sin solicitar ni extraer credenciales nuevas.

`stream: true` es una solicitud de transporte; si el perfil lo desactiva, no se cambia su configuración. No se envían `params`, `tools`, `system`, temperatura ni `top_k` propios.

## Validación y límites

Se han superado diez pruebas de controlador con API/modelo simulados y Socket.IO real local: generación única, herencia sin overrides, transporte con API key/JWT, texto antes del final, restauración, identidad y dos agentes sin mezclar mensajes. Se prueba también el instalador sobre un addon temporal, incluida repetición sin duplicar imports/vistas ni cambiar autoría.

El widget se ha probado con jQuery de Odoo 13 y DOM simulado: español/inglés, selector, bloqueo durante generación, historial, apertura, texto incremental, UTF-8 fragmentado, limpieza de HTML y logs sin contenido. El comparador se valida con peticiones simuladas para comprobar que no cambie la petición ni registre secretos.

No se ha podido completar una comprobación visual con Chromium en este entorno: su arranque está bloqueado por permisos del entorno. No hay una prueba completa con Odoo real, tu servidor de Open WebUI ni tu modelo. La recuperación de conocimientos sigue pendiente de la comparación descrita arriba.

Código de referencia contrastado (versión 0.11.4):

- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/main.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/utils/middleware.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/utils/models.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/routers/chats.py

## Revertir

La copia indicada por el instalador contiene `archivos.json`: los archivos con `existed: true` se restauran desde esa copia; los que indica como nuevos se retiran al desinstalar esta revisión. Después reinicia Odoo y actualiza el addon. No borres los chats de Open WebUI. La copia incluye el manifiesto y el inicializador anteriores.
