#!/usr/bin/env python3
"""Instala la revision v5 con copia privada en /tmp. No instala paquetes globales."""
import ast
import json
import io
import tokenize
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile


def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else
                '/home/od/odoo/slimbook/website_openwebui_chat').resolve()
    source = Path(__file__).resolve().parent
    controller = root / 'controllers' / 'main.py'
    widget = root / 'static' / 'src' / 'js' / 'chat_widget.js'
    for target in (controller, widget):
        if not target.is_file() or target.is_symlink():
            raise SystemExit('No se ha cambiado nada. Revisa la ruta: %s' % target)
        if not os.access(str(target.parent), os.W_OK):
            raise SystemExit('No se ha cambiado nada. Sin permiso de escritura en: %s' % target.parent)
    # Integrar los campos en el modulo existente, conservando el manifiesto
    # y su autoria literalmente. Validar todo antes de reemplazar ficheros.
    manifest = root/'__manifest__.py'
    init = root/'__init__.py'
    if not manifest.is_file() or not init.is_file():
        raise SystemExit('Faltan __manifest__.py o __init__.py en la raiz del addon.')
    manifest_text = manifest.read_text(encoding='utf-8')
    values = ast.literal_eval(manifest_text)
    xml_name = 'views/slimaia_settings.xml'
    if xml_name not in values.get('data', []):
        tokens = list(tokenize.generate_tokens(io.StringIO(manifest_text).readline))
        lines = manifest_text.splitlines(keepends=True)
        def offset(position):
            return sum(len(line) for line in lines[:position[0]-1]) + position[1]
        insertion = None
        for index, token in enumerate(tokens):
            if token.type == tokenize.STRING and ast.literal_eval(token.string) == 'data':
                if tokens[index+1].string != ':' or tokens[index+2].string != '[':
                    continue
                depth = 0
                for close in tokens[index+2:]:
                    if close.string == '[': depth += 1
                    if close.string == ']':
                        depth -= 1
                        if depth == 0:
                            insertion = offset(tokens[index+2].end)
                            break
                if insertion is not None: break
        if insertion is None:
            raise SystemExit('El manifiesto debe contener una lista data literal. No se ha cambiado nada.')
        manifest_text = manifest_text[:insertion] + repr(xml_name) + ', ' + manifest_text[insertion:]
    init_text = init.read_text(encoding='utf-8')
    if 'from . import slimaia_settings' not in init_text:
        init_text += '\nfrom . import slimaia_settings\n'
    generated = Path(tempfile.mkdtemp(prefix='slimaia_install_', dir='/tmp'))
    (generated/'__manifest__.py').write_text(manifest_text, encoding='utf-8')
    (generated/'__init__.py').write_text(init_text, encoding='utf-8')
    pairs = [(generated/'__manifest__.py', manifest), (generated/'__init__.py', init),
             (source/'slimaia_settings.py', root/'slimaia_settings.py'),
             (source/'slimaia_settings.xml', root/'views'/'slimaia_settings.xml'),
             (source/'chat_widget.css', root/'static'/'src'/'css'/'chat_widget.css'),
             (source/'agent_icon.png', root/'static'/'src'/'img'/'agent_icon.png'),
             (source/'main.py', controller), (source/'chat_widget.js', widget),
             (source/'openwebui_transport.py', root/'controllers'/'openwebui_transport.py')]
    vendor = source/'owui_websocket'
    if not (vendor/'__init__.py').is_file() or not (vendor/'LICENSE').is_file():
        raise SystemExit('Paquete incompleto: descomprime todo el ZIP, incluida la carpeta owui_websocket.')
    for item in sorted(vendor.iterdir()):
        if item.is_file() and (item.suffix == '.py' or item.name in ('LICENSE', 'ORIGEN.txt')):
            pairs.append((item, root/'controllers'/'owui_websocket'/item.name))
    for original, target in pairs:
        if not original.is_file() or target.is_symlink() or root not in target.resolve().parents:
            raise SystemExit('No se ha cambiado nada. Ruta no valida: %s' % target)
        if original.suffix == '.py':
            ast.parse(original.read_text(encoding='utf-8'), filename=original.name)
    backup = Path(tempfile.mkdtemp(prefix='website_openwebui_chat_backup_v5_', dir='/tmp'))
    metadata_default = controller.stat()
    staged, replaced, records = [], [], []
    try:
        for original, target in pairs:
            existed = target.exists()
            relative = str(target.relative_to(root))
            records.append({'path':relative, 'existed':existed})
            if existed:
                saved = backup/relative
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(target), str(saved))
            if not target.parent.exists():
                target.parent.mkdir(mode=0o755, parents=True)
                if os.geteuid() == 0:
                    os.chown(str(target.parent), metadata_default.st_uid, metadata_default.st_gid)
            metadata = target.stat() if existed else metadata_default
            fd, name = tempfile.mkstemp(prefix='.openwebui-v4-', dir=str(target.parent))
            staged.append(Path(name))
            with os.fdopen(fd, 'wb') as stream:
                stream.write(original.read_bytes());stream.flush();os.fsync(stream.fileno())
                os.fchmod(stream.fileno(), stat.S_IMODE(metadata.st_mode) if existed else 0o644)
                if (os.geteuid(), os.getegid()) != (metadata.st_uid, metadata.st_gid):
                    os.fchown(stream.fileno(), metadata.st_uid, metadata.st_gid)
        (backup/'archivos.json').write_text(json.dumps({'module':str(root),'files':records}, indent=2),encoding='utf-8')
        for temporary, (_, target), record in zip(staged, pairs, records):
            os.replace(str(temporary), str(target))
            replaced.append((target,record))
    except Exception:
        for target, record in reversed(replaced):
            if record['existed']:
                shutil.copyfile(str(backup/record['path']), str(target))
            else:
                target.unlink()
        print('Instalacion interrumpida. Copia: %s' % backup,file=sys.stderr)
        raise
    finally:
        for temporary in staged:
            if temporary.exists():temporary.unlink()
    print('Instalado: native-profile-v5. Copia privada: %s' % backup)
    print('Reinicia Odoo, actualiza website_openwebui_chat en Aplicaciones y recarga con Ctrl+F5.')
    print('En F12 > Consola debe aparecer [SlimAIA] y native-profile-v5.')
    print('No se modifican el prompt, parametros, documentos ni chats de Open WebUI.')
    shutil.rmtree(str(generated))
    print('Configura los IDs de Ventas y Soporte en Ajustes > SlimAIA. No hay campos de prompt.')


if __name__ == '__main__':
    main()
