"""Canal Socket.IO de Open WebUI. Sin credenciales ni contenido en logs.

Engine.IO v4 / Socket.IO v5: solo namespace predeterminado y eventos JSON.
WebSocket usa websocket-client privado; polling se admite si el servidor
rechaza ese transporte. No modifica la configuracion de Open WebUI.
"""
import json
import queue
import threading
import time
from urllib.parse import urlencode
from urllib.request import Request

from . import owui_websocket as websocket


class TransportError(Exception):
    def __init__(self, code, stage=None, http_status=None, exception_type=None):
        super().__init__(code)
        self.code, self.stage = code, stage
        self.http_status, self.exception_type = http_status, exception_type


class EventChannel:
    def __init__(self, client, timeout):
        self.client = client
        self.deadline = time.monotonic() + timeout
        self.socket = None
        self.engine_id = None
        self.session_id = None
        self.kind = 'websocket'
        self.closed = threading.Event()
        self.events = queue.Queue(maxsize=128)
        self.thread = None
        self.pending = []
        self.read_timeout = 40
        self.stage = 'initializing'

    def _path(self):
        values = {'EIO': '4', 'transport': 'polling', 't': str(time.monotonic())}
        if self.engine_id:
            values['sid'] = self.engine_id
        return '/ws/socket.io/?' + urlencode(values)

    def _poll(self, body=None):
        headers = dict(self.client.headers, **{'Content-Type': 'text/plain; charset=UTF-8'})
        request = Request(self.client.url + self._path(), data=body.encode('utf-8') if body is not None else None,
                          headers=headers, method='POST' if body is not None else 'GET')
        with self.client.opener.open(request, timeout=self.read_timeout) as response:
            return response.read().decode('utf-8')

    def _send(self, packet):
        if self.socket:
            self.socket.send(packet)
        else:
            self._poll(packet)

    def _recv(self):
        if self.pending:
            return self.pending.pop(0)
        value = self.socket.recv() if self.socket else self._poll()
        if not value:
            raise TransportError('events_disconnected')
        if isinstance(value, bytes):
            value = value.decode('utf-8')
        packets = value.split('\x1e')
        self.pending.extend(packets[1:])
        return packets[0]

    def _packet(self):
        while not self.closed.is_set() and time.monotonic() < self.deadline:
            packet = self._recv()
            if packet.startswith('2'):
                self._send('3' + packet[1:])  # Ping Engine.IO, independiente del ping WebSocket.
                continue
            if packet in ('1', '41') or packet.startswith('44'):
                raise TransportError('events_disconnected')
            return packet
        raise TransportError('events_timeout')

    def connect(self):
        url = ('wss://' if self.client.url.startswith('https://') else 'ws://') + self.client.url.split('://', 1)[1]
        try:
            self.stage = 'websocket_handshake'
            try:
                self.socket = websocket.create_connection(
                    url + '/ws/socket.io/?EIO=4&transport=websocket', timeout=10,
                    suppress_origin=True, redirect_limit=0, enable_multithread=True)
                if self.socket.getstatus() != 101:
                    raise TransportError('events_handshake')
            except websocket.WebSocketBadStatusException as exc:
                if exc.status_code != 400:
                    raise
                self.kind = 'polling'
                self.socket = None
                self.stage = 'polling_handshake'
            self.stage = 'engineio_open'
            opening = self._recv()
            if not opening.startswith('0'):
                raise TransportError('events_handshake')
            config = json.loads(opening[1:])
            self.engine_id = config['sid']
            self.read_timeout = max(15, (config.get('pingInterval', 25000) + config.get('pingTimeout', 20000)) / 1000 + 5)
            if self.socket:
                self.socket.settimeout(self.read_timeout)
            key = self.client.headers['Authorization'][7:]
            self.stage = 'socketio_authentication'
            self._send('40' + json.dumps({'token': key}))
            while not self.session_id:
                packet = self._packet()
                if packet.startswith('40'):
                    self.session_id = json.loads(packet[2:])['sid']
            # always_connect=True puede confirmar el socket antes de autenticar.
            # Este ACK verifica que la cuenta ha entrado en su sala de eventos.
            self._send('421' + json.dumps(['user-join', {'auth': {'token': key}}]))
            self.stage = 'user_join_authentication'
            authenticated = False
            while not authenticated:
                packet = self._packet()
                if packet.startswith('431'):
                    reply = json.loads(packet[3:])
                    authenticated = bool(reply and isinstance(reply[0], dict) and reply[0].get('id'))
                    if not authenticated:
                        raise TransportError('events_authentication')
            self.thread = threading.Thread(target=self._listen, name='owui-events', daemon=True)
            self.thread.start()
            return self
        except Exception as exc:
            # Solo clase, fase y estado HTTP. Nunca str(exc), headers, token
            # ni el cuerpo que devuelva el servidor.
            stage = self.stage
            code = exc.code if isinstance(exc, TransportError) else 'events_connection_failed'
            status = getattr(exc, 'status_code', None)
            if not isinstance(status, int):
                status = getattr(exc, 'code', None)
            if not isinstance(status, int):
                status = None
            self.close()
            raise TransportError(code, stage, status, type(exc).__name__) from None

    def _put(self, value):
        while not self.closed.is_set():
            try:
                self.events.put(value, timeout=0.5)
                return
            except queue.Full:
                pass

    def _listen(self):
        try:
            while not self.closed.is_set():
                packet = self._packet()
                if not packet.startswith('42'):
                    continue
                raw = packet[2:]
                pos = raw.find('[')
                if pos < 0:
                    continue
                event = json.loads(raw[pos:])
                if len(event) >= 2 and event[0] == 'events' and isinstance(event[1], dict):
                    data = event[1]
                    if (data.get('chat_id') == self.chat_id and data.get('message_id') == self.message_id
                            and not data.get('internal')):
                        self._put(data)
        except Exception:
            if not self.closed.is_set():
                self._put({'transport_error': True})

    def get(self, timeout=1):
        try:
            return self.events.get(timeout=timeout)
        except queue.Empty:
            return None

    def close(self):
        if self.closed.is_set():
            return
        self.closed.set()
        try:
            if self.socket:
                self.socket.close(timeout=1)
            elif self.engine_id:
                self.read_timeout = 2
                self._send('1')
        except Exception:
            pass
