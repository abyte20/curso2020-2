odoo.define('website_openwebui_chat.widget', function (require) {
    'use strict';

    var PROTOCOL = 'native-profile-v5';
    $(document).ready(function () {
        if (!document.getElementById('ow-chat-messages')) return;
        var conversation = null;
        var english = /^en([_-]|$)/i.test(document.documentElement.lang || 'es');
        var agent = 'sales';
        var agents = {sales: true, support: false};
        var restoreSequence = 0;
        try { if (sessionStorage.getItem('slimaia_agent') === 'support') agent = 'support'; } catch (ignore) {}
        function tr(es, en) { return english ? en : es; }
        function publicError(text) {
            if (!english) return text || 'No se pudo completar la consulta. Inténtalo de nuevo.';
            return 'The request could not be completed. Reload to check the saved conversation before trying again.';
        }
        var $header = $('.ow-chat-header span').first();
        $header.empty().append($('<i>').addClass('fa fa-shopping-bag').attr('aria-hidden', 'true'))
            .append(document.createTextNode(tr(' SlimAIA - Asistente Inteligencia Artificial', ' SlimAIA - Artificial Intelligence Assistant')));
        var $selector = $('<select id="ow-chat-agent">').attr('aria-label', tr('Hablar con', 'Talk to'));
        $selector.append($('<option value="sales">').text(tr('Ventas', 'Sales')))
            .append($('<option value="support">').text(tr('Soporte', 'Support'))).val(agent);
        var $bar = $('<div class="ow-agent-bar">').append($('<label for="ow-chat-agent">').text(tr('Hablar con', 'Talk to'))).append($selector);
        $('.ow-chat-header').after($bar);
        $('#openwebui-chat-button').empty().append($('<img>').attr({src:'/website_openwebui_chat/static/src/img/agent_icon.png', alt:'SlimAIA'}))
            .attr({role:'button', tabindex:'0', 'aria-label':tr('Abrir chat con SlimAIA', 'Open SlimAIA chat'), 'aria-controls':'openwebui-chat-modal'});
        $('#ow-chat-close').attr('aria-label',tr('Cerrar chat', 'Close chat'));
        $('#ow-chat-send').attr('aria-label',tr('Enviar mensaje','Send message'));
        $('#ow-chat-input').attr({placeholder:tr('Escribe tu consulta…','Type your question…'), 'aria-label':tr('Tu mensaje','Your message')});
        $('<div class="ow-disclaimer">').text(tr('La IA puede cometer errores. Comprueba la información importante.',
            'AI can make mistakes. Check important information.')).appendTo('#openwebui-chat-modal');
        var openPreference = null;
        try { openPreference = sessionStorage.getItem('slimaia_open_v4'); } catch (ignore) {}
        if (openPreference === '1') $('#openwebui-chat-modal').removeClass('ow-hidden');
        var debugRecords = [];
        var debugEnabled = true;
        function diagnostic(values) {
            var safe = {};
            var allowed = ['request_message_count', 'published_metadata_visible', 'requested_model_id', 'profile_base_model_id', 'base_model_visible', 'profile_knowledge_count',
                'published_knowledge_count', 'published_builtin_tools_enabled', 'published_knowledge_tools_enabled',
                'effective_prompt_verified', 'effective_tools_verified', 'revision', 'request', 'phase', 'profile_read', 'profile_prompt_present',
                'configured_model_matches_profile', 'profile_is_preset', 'profile_parameters_visibility',
                'credential_kind', 'poll_interval_ms', 'snapshots_received', 'progressive_updates',
                'updates_before_done', 'transport_stage', 'http_status', 'exception_type',
                'profile_parameters', 'parameter_overrides', 'system_messages_added', 'user_message_changed',
                'engine_effective_parameters', 'transport', 'elapsed_ms', 'first_text_ms', 'live_text_updates',
                'events_received', 'knowledge_calls', 'file_reads', 'tool_results', 'saved', 'code',
                'network_chunks', 'browser_first_text_ms', 'browser_elapsed_ms', 'messages_restored', 'pending'];
            allowed.forEach(function (key) { if (Object.prototype.hasOwnProperty.call(values, key)) safe[key] = values[key]; });
            if (debugRecords.length >= 60) debugRecords.shift();
            debugRecords.push(safe);
            if (debugEnabled && window.console && console.info) console.info('[SlimAIA]', JSON.stringify(safe));
        }
        window.SlimAIADebug = {
            snapshot: function () { return JSON.parse(JSON.stringify(debugRecords)); },
            clear: function () { debugRecords.length = 0; },
            setEnabled: function (value) { debugEnabled = Boolean(value); }
        };
        diagnostic({revision: PROTOCOL, phase: 'widget_loaded'});
        var history = [];
        var busy = false;
        var ready = false;
        var $messages = $('#ow-chat-messages');
        $messages.empty();
        var $notice = $('<div>').attr('role', 'status').css({fontSize: '0.85em', padding: '6px 12px'});
        $messages.after($notice);

        function scroll() {
            var element = $messages[0];
            element.scrollTop = element.scrollHeight;
        }

        // Markdown con una lista limitada de etiquetas. Nunca insertar HTML
        // del modelo directamente en la pagina de Odoo.
        function render($target, text) {
            if (typeof marked === 'undefined' || !marked.parse) {
                $target.text(text).css('white-space', 'pre-wrap');
                return;
            }
            var template = document.createElement('template');
            template.innerHTML = marked.parse(text);
            var allowed = ['P', 'BR', 'STRONG', 'EM', 'B', 'I', 'UL', 'OL', 'LI', 'BLOCKQUOTE',
                'PRE', 'CODE', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'TABLE', 'THEAD', 'TBODY', 'TR', 'TH', 'TD', 'HR', 'A'];
            function clean(node, parent) {
                if (node.nodeType === 3) {
                    parent.appendChild(document.createTextNode(node.textContent));
                    return;
                }
                if (node.nodeType !== 1) return;
                if (['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'SVG', 'MATH', 'FORM', 'IMG'].indexOf(node.tagName) !== -1) return;
                var destination = parent;
                if (allowed.indexOf(node.tagName) !== -1) {
                    destination = document.createElement(node.tagName.toLowerCase());
                    if (node.tagName === 'A') {
                        var href = node.getAttribute('href') || '';
                        try {
                            var url = new URL(href, window.location.href);
                            if (['http:', 'https:', 'mailto:'].indexOf(url.protocol) !== -1) {
                                destination.setAttribute('href', url.href);
                                destination.setAttribute('rel', 'noopener noreferrer');
                            }
                        } catch (ignore) { /* enlace invalido: conservar solo el texto */ }
                    }
                    parent.appendChild(destination);
                }
                Array.prototype.forEach.call(node.childNodes, function (child) { clean(child, destination); });
            }
            var fragment = document.createDocumentFragment();
            Array.prototype.forEach.call(template.content.childNodes, function (node) { clean(node, fragment); });
            $target.empty().append(fragment);
        }

        function bubble(text, role) {
            var $element = $('<div>').addClass('ow-msg ' + (role === 'user' ? 'ow-msg-user' : 'ow-msg-bot'));
            if (role === 'user') $element.text(text);
            else render($element, text);
            $messages.append($element);
            scroll();
            return $element;
        }

        function controls() {
            $selector.prop('disabled', busy);
            $('#ow-chat-send').prop('disabled', busy || !ready);
            $('#ow-chat-input').prop('disabled', busy || !ready);
        }

        function cache() {
            try {
                sessionStorage.setItem('slimbook_chat_v5_' + agent, JSON.stringify({conversation: conversation, messages: history}));
            } catch (ignore) { /* Odoo conserva el historial aunque se bloquee el almacenamiento local. */ }
        }

        async function restore(silent) {
            var sequence = ++restoreSequence;
            var selectedAgent = agent;
            ready = false;
            controls();
            $notice.text(tr('Recuperando conversación…', 'Restoring conversation…'));
            if (!agents[agent]) {
                $messages.empty();
                $notice.text(tr('Soporte todavía no está disponible. Puedes hablar con Ventas.', 'Support is not available yet. You can talk to Sales.'));
                return;
            }
            try {
                var response = await fetch('/website_chat/state?agent=' + encodeURIComponent(selectedAgent), {credentials: 'same-origin', cache: 'no-store'});
                if (!response.ok) throw new Error(await response.text());
                var state = await response.json();
                if (sequence !== restoreSequence) return;
                if (state.revision !== PROTOCOL) throw new Error('Actualiza el módulo y recarga: las versiones no coinciden.');
                conversation = state.conversation_id;
                history = state.messages;
                if (!Array.isArray(history)) throw new Error('No se pudo recuperar el historial.');
                // No mostrar la copia local antes de validar la sesion: puede
                // pertenecer a la identidad anterior tras iniciar/cerrar sesion.
                $messages.empty();
                history.forEach(function (message) { bubble(message.error ? publicError(message.content) : message.content, message.role); });
                if (openPreference === null && history.length) {
                    $('#openwebui-chat-modal').removeClass('ow-hidden');
                }
                if (silent !== true) diagnostic({phase: 'history_restored', messages_restored: history.length, pending: state.pending});
                cache();
                if (state.pending) {
                    $notice.text(tr('SlimAIA está pensando…', 'SlimAIA is thinking…'));
                    window.setTimeout(function () { if (sequence === restoreSequence) restore(true); }, 5000);
                    return;
                }
                ready = true;
                $notice.text(history.length ? '' : tr('Escribe tu consulta para empezar.', 'Type your question to get started.'));
            } catch (error) {
                if (sequence !== restoreSequence) return;
                $notice.text(publicError(error.message));
                $('<button type="button">').text(tr('Reintentar', 'Retry')).on('click', restore).appendTo($notice);
            }
            controls();
        }

        async function send() {
            var text = $('#ow-chat-input').val();
            if (!text.trim() || busy || !ready) return;
            busy = true;
            controls();
            $('#ow-chat-input').val('');
            bubble(text, 'user');
            var $answer = bubble(tr('SlimAIA está pensando…', 'SlimAIA is thinking…'), 'assistant');
            var answer = '';
            var complete = false;
            var reader;
            var started = performance.now();
            var firstText = null;
            var chunks = 0;
            diagnostic({phase: 'request_started'});
            $notice.empty();
            try {
                var form = new FormData();
                form.append('message', text);
                form.append('agent', agent);
                form.append('conversation_id', conversation);
                form.append('protocol', PROTOCOL);
                var response = await fetch('/website_chat/stream_message', {
                    method: 'POST', body: form, credentials: 'same-origin', cache: 'no-store'
                });
                if (!response.ok) throw new Error(await response.text());
                if (response.headers.get('X-OpenWebUI-Protocol') !== PROTOCOL) {
                    throw new Error('Actualiza el controlador de Odoo: la respuesta usa otra versión.');
                }
                if (!response.body) throw new Error('El navegador no permite leer la respuesta progresiva.');
                reader = response.body.getReader();
                var decoder = new TextDecoder('utf-8');
                var buffer = '';
                function process(line) {
                    if (!line.trim()) return;
                    var event = JSON.parse(line);
                    if (event.type === 'diagnostic') { diagnostic(event); return; }
                    if (event.type === 'heartbeat') return;
                    if (event.type === 'error') throw new Error(event.text);
                    if (event.type === 'status' && !answer) $answer.text(tr('SlimAIA está pensando…', 'SlimAIA is thinking…'));
                    if (event.type === 'delta' || event.type === 'replace') {
                        if (firstText === null && event.text) firstText = Math.round(performance.now() - started);
                        answer = event.type === 'replace' ? event.text : answer + event.text;
                        render($answer, answer);
                        scroll();
                    }
                    if (event.type === 'done') {
                        complete = true;
                        if (!event.saved) $notice.text(tr('No se pudo guardar la respuesta.', 'The response could not be saved.'));
                    }
                }
                while (true) {
                    var part = await reader.read();
                    if (!part.done) chunks += 1;
                    buffer += decoder.decode(part.value || new Uint8Array(), {stream: !part.done});
                    var newline;
                    while ((newline = buffer.indexOf('\n')) !== -1) {
                        process(buffer.slice(0, newline));
                        buffer = buffer.slice(newline + 1);
                    }
                    if (part.done) break;
                }
                if (buffer.trim()) process(buffer);
                if (!complete) throw new Error('La respuesta se interrumpió antes de terminar. Recarga para recuperar su estado.');
                diagnostic({phase: 'browser_completed', network_chunks: chunks,
                    browser_first_text_ms: firstText, browser_elapsed_ms: Math.round(performance.now() - started)});
                history.push({role: 'user', content: text}, {role: 'assistant', content: answer});
                cache();
            } catch (error) {
                if (reader) { try { await reader.cancel(); } catch (ignore) {} }
                // Una respuesta parcial no se presenta ni se guarda como valida.
                $answer.text(publicError(error.message));
                diagnostic({phase: 'browser_error', code: 'request_failed', network_chunks: chunks,
                    browser_first_text_ms: firstText, browser_elapsed_ms: Math.round(performance.now() - started)});
            } finally {
                busy = false;
                controls();
                $('#ow-chat-input').focus();
                scroll();
            }
        }

        $('#openwebui-chat-button, #ow-chat-close').on('click', function (event) {
            event.preventDefault();
            $('#openwebui-chat-modal').toggleClass('ow-hidden');
            openPreference = $('#openwebui-chat-modal').hasClass('ow-hidden') ? '0' : '1';
            try { sessionStorage.setItem('slimaia_open_v4', openPreference); } catch (ignore) {}
        });
        $('#ow-chat-input').on('keydown', function (event) {
            if ((event.key === 'Enter' || event.keyCode === 13) && !event.shiftKey) {
                event.preventDefault();
                send();
            }
        });
        $('#ow-chat-send').on('click', function (event) { event.preventDefault(); send(); });
        $selector.on('change', function () {
            if (busy) { $selector.val(agent); return; }
            agent = $selector.val();
            try { sessionStorage.setItem('slimaia_agent', agent); } catch (ignore) {}
            $messages.empty();
            $('#ow-chat-input').val('');
            restore();
        });
        $('#openwebui-chat-button').on('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
        });
        fetch('/website_chat/agents', {credentials:'same-origin', cache:'no-store'})
            .then(function (response) { if (!response.ok) throw new Error('agents'); return response.json(); })
            .then(function (available) { agents = available; restore(); })
            .catch(function () { $notice.text(tr('No se pudo cargar el chat. Recarga la página.', 'Could not load chat. Reload the page.')); });
    });
});
