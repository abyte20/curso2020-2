/* Ejecutar SOLO en la consola de Open WebUI antes de una pregunta que alli funciona.
   No envia nada extra, no modifica el cuerpo, no lee cabeceras ni claves.
   Se desinstala con SlimAIACompare.stop() o recargando la pagina. */
(function () {
    'use strict';
    if (window.SlimAIACompare) window.SlimAIACompare.stop();
    var original = window.fetch;
    var records = [];
    function inspect(input, init) {
        try {
            var url = new URL(typeof input === 'string' ? input : input.url, location.href);
            if (url.origin !== location.origin || !/^\/api\/(v1\/)?chat\/completions\/?$/.test(url.pathname)) return;
            if (!init || typeof init.body !== 'string') return;
            var body = JSON.parse(init.body);
            var params = {};
            ['temperature','top_k','top_p','min_p','seed','max_tokens','num_ctx','repeat_penalty',
             'presence_penalty','frequency_penalty','stream_response','stream_delta_chunk_size'].forEach(function (key) {
                var value = (body.params || {})[key];
                if (typeof value === 'number' || typeof value === 'boolean') params[key] = value;
            });
            if (['native','legacy'].includes((body.params || {}).function_calling)) params.function_calling = body.params.function_calling;
            var features = {};
            Object.keys(body.features || {}).forEach(function (key) {
                if (['web_search','image_generation','code_interpreter','memory'].includes(key)) features[key] = Boolean(body.features[key]);
            });
            var systems = (body.messages || []).filter(function (m) { return m.role === 'system'; });
            var record = {
                endpoint: url.pathname, requested_model_id: body.model, request_message_count: (body.messages || []).length, request_parameters: params,
                features: features, session_id_present: Boolean(body.session_id),
                chat_id_present: Boolean(body.chat_id), user_message_present: Boolean(body.user_message),
                system_messages_in_request: systems.length,
                params_system_present: Boolean((body.params || {}).system),
                model_item_direct: Boolean((body.model_item || {}).direct),
                explicit_tools_present: Object.prototype.hasOwnProperty.call(body, 'tools'),
                tool_ids_count: (body.tool_ids || []).length,
                filter_ids_count: (body.filter_ids || []).length,
                skill_ids_count: (body.skill_ids || []).length,
                files_count: (body.files || []).length,
                server_effective_prompt_and_parameters: 'not_observable_in_browser_request'
            };
            records.push(record);
            if (records.length > 5) records.shift();
            console.info('[SlimAIA comparison]', JSON.stringify(record));
        } catch (ignore) { /* Nunca interrumpir la peticion real. */ }
    }
    function wrapped(input, init) { inspect(input, init); return original.apply(this, arguments); }
    window.fetch = wrapped;
    window.SlimAIACompare = {
        snapshot: function () { return JSON.parse(JSON.stringify(records)); },
        stop: function () { if (window.fetch === wrapped) window.fetch = original; }
    };
    console.info('Comparacion preparada. Haz UNA pregunta que funcione aqui. Despues: JSON.stringify(SlimAIACompare.snapshot(), null, 2)');
})();
