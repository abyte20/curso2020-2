# TuxAIA 6.6.2 · Estados de actividad y miniatura del editor · Odoo 13

Parche de seis archivos sobre `website_openwebui_chat` 6.6.1. Versión técnica nueva: `13.0.2.0.3`. El parche del módulo `website_profile_custom` para el error del editor de traducciones es independiente; puede instalarse antes o después.

## Cambios

### Actividad real

El controlador convierte señales de Open WebUI en códigos de estado limitados. El navegador muestra sus propias traducciones, en el idioma de la página:

| Señal disponible | Español | Inglés |
| --- | --- | --- |
| Inicio, procesamiento o actividad no identificable | TuxAIA está pensando… | TuxAIA is thinking… |
| Consulta documental en curso | Buscando en la documentación… | Searching the documentation… |
| Lectura de un archivo en curso | Consultando información relevante… | Reading relevant information… |
| Texto de respuesta en generación | Preparando la respuesta… | Preparing the response… |

Se reconocen las consultas nativas `search_knowledge_files`, `query_knowledge_files`, `query_knowledge_bases` y las lecturas `view_file`, `view_knowledge_file`, además del evento de búsqueda documental del flujo antiguo cuando llega por el canal de eventos. Las consultas terminadas no se mantienen como búsquedas en curso. Una herramienta desconocida conserva un estado genérico.

Los estados pueden repetirse y volver a una fase anterior cuando el modelo realiza otra consulta. No se utiliza una secuencia simulada ni un porcentaje. Si Open WebUI no publica una señal, se mantiene el estado genérico. Una operación demasiado rápida puede transcurrir entre dos lecturas HTTP y no llegar a mostrarse.

- Tres puntos animados: se conservan sus nodos al cambiar el texto del estado.
- El aviso inicial ocupa el lugar de espera de la respuesta. Cuando ya hay texto, la actividad sigue visible en el campo de espera sin sustituir la respuesta recibida.
- Los estados no se guardan como mensajes del chat ni se envían al modelo.
- Tras 25 segundos sin un cambio de actividad o nuevo texto se muestra un aviso neutro de demora. En el campo pequeño se usa una versión abreviada. Desaparece cuando llega un nuevo avance o termina la solicitud.
- Se conserva la animación de aparición de respuestas y el foco del campo.
- Al recuperar una conversación pendiente, se intenta reconocer la actividad a partir de su respuesta en curso.
- Funciona tanto con el transporte de instantáneas HTTP como con el canal de eventos. No añade llamadas de sondeo ni cambia sus intervalos.

La interfaz recibe códigos de estado, no descripciones proporcionadas por herramientas. Los avisos no publican preguntas de búsqueda, nombres de archivos, argumentos, resultados internos ni razonamiento. Los eventos de otras conversaciones o mensajes siguen fuera del filtro autorizado de la sesión.

### Miniatura e imágenes

El problema de la captura era que una regla de edición hacía visible el cuerpo completo del bloque dentro del catálogo de Odoo. El cuerpo debe permanecer oculto allí y mostrarse al colocar el bloque en una página.

- La regla de visualización del contenido editable queda limitada a la página.
- Se mantiene oculto el cuerpo del bloque en el catálogo y en la copia utilizada al arrastrarlo.
- La miniatura de TuxAIA en el catálogo tiene una altura máxima de 90 px y se ajusta sin deformarse.
- La imagen del flotante cerrado tiene límites de 76 × 62 px. La imagen de bienvenida tiene límites de 128 × 105 px y conserva el tamaño menor en móvil.
- Se mantiene exactamente el archivo original `agent_icon.png` de Alejandro.

## Instalación

Sube `TuxAIA_v6.6.2_activity_ui.zip` a `/home/od/`. Como usuario `od`:

```bash
cd /home/od
unzip TuxAIA_v6.6.2_activity_ui.zip
cd TuxAIA_v6.6.2_activity_ui
python3 instalar.py --check /home/od/odoo/slimbook
```

Sobre una 6.6.1 sin cambios debe indicar seis archivos pendientes. Si detecta diferencias, se detiene sin sobrescribirlas: conserva la salida para revisarla.

Conserva tu copia de seguridad de la base de datos y **detén Odoo** mediante el procedimiento habitual. Después aplica:

```bash
python3 instalar.py /home/od/odoo/slimbook
```

El instalador guarda una copia de los archivos anteriores en `copias/tuxaia_v662_backup_...`, junto al instalador, e imprime su ubicación. No modifica la base de datos ni reinicia el servicio.

**Arranca Odoo** para cargar el controlador actualizado. En **Aplicaciones**, quita el filtro «Aplicaciones», busca `website_openwebui_chat` y pulsa **Actualizar**. Recarga con `Ctrl+F5` tanto la página como el editor.

No requiere nuevos ajustes. Los estados se aplican a Ventas y Soporte según la actividad que publique cada perfil.

## Comprobación en vuestro servidor

1. Entra en el editor de una página. En el catálogo debe verse solo la miniatura y el título de TuxAIA, sin la tarjeta larga debajo.
2. Coloca el bloque en la página: su contenido debe mostrarse normalmente.
3. Haz una consulta que requiera documentación. El aviso cambia cuando Open WebUI publica una búsqueda o lectura en curso.
4. Comprueba que la respuesta continúa visible si se realiza otra consulta documental durante su generación.
5. Al terminar, los avisos de actividad desaparecen. No deben aparecer como mensajes en el historial al recargar.

En la consola, `TuxAIADebug.presentation()` debe mostrar `revision: "tuxaia-v6.6.2-ui"`. El registro `widget_loaded` de `TuxAIADebug.snapshot()` debe mostrar `widget_revision: "tuxaia-v6.6.2-ui"`.

## Restaurar

Con Odoo detenido, utiliza la ruta real de la copia:

```bash
python3 instalar.py --restore /ruta/real/tuxaia_v662_backup_XXXX /home/od/odoo/slimbook
```

Arranca Odoo, actualiza `website_openwebui_chat` y recarga la página. El instalador comprueba que no haya modificaciones posteriores antes de restaurar los archivos.

## Pruebas realizadas y límites

- Código real del controlador: clasificación de herramientas, resultados completados o fallidos, salida incremental, eventos antiguos de búsqueda, ambos transportes y ausencia de datos privados en los mensajes de estado.
- Rechazo de eventos de otras conversaciones, de otros mensajes y de eventos internos; pruebas de sesión, usuario, sitio, caducidad e identificadores manipulados.
- Chromium: interfaz en escritorio/móvil y español/inglés, cambios de estado, conservación de puntos y foco, aviso de demora con reloj simulado, recuperación de actividad y limpieza al finalizar.
- Reproducción de la estructura del catálogo de Odoo 13: cuerpo oculto en catálogo y copia de arrastre, contenido visible al insertarlo, miniatura de 90 px y límite del icono flotante frente a reglas del tema.
- Regresiones de la 6.6: chat compacto, ampliación, perfiles, formulario, bloques múltiples y limpieza al entrar en edición.
- Instalación, repetición sin cambios, protección ante modificaciones y restauración exacta sobre una copia de la 6.6.1.

Las pruebas usan el código del módulo con transporte simulado y una página de prueba. Se ha contrastado la estructura del catálogo con el código oficial de Odoo 13 y las señales de herramientas con Open WebUI 0.11.4. Falta validar la integración completa con vuestro tema, vuestra base de datos y las respuestas reales de Open WebUI.

Los adjuntos del chatbot y la recuperación de conversaciones antiguas continúan fuera de esta versión.
