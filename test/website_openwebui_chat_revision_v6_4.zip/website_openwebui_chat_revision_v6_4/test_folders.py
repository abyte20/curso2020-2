"""Pruebas de asignación y títulos con API simulada; no requieren Odoo."""
import ast
import copy
from datetime import datetime
import json
import random
import time
import unittest
import uuid
from pathlib import Path
from urllib.parse import quote, urlencode

source = Path(__file__).with_name('main.py')
tree = ast.parse(source.read_text())
scope = dict(time=time, uuid=uuid, quote=quote, urlencode=urlencode, json=json)
for name in ('IntegrationError', '_turn_error', '_output_text', '_node_text', '_messages_from_chat', 'OpenWebUIClient'):
    node = next(n for n in tree.body if getattr(n, 'name', '') == name)
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(source), 'exec'), scope)
Client, Error = scope['OpenWebUIClient'], scope['IntegrationError']
controller = next(n for n in tree.body if getattr(n, 'name', '') == 'OpenWebUIChatController')
method = next(n for n in controller.body if getattr(n, 'name', '') == '_desired_title')
exec(compile(ast.Module(body=[method], type_ignores=[]), str(source), 'exec'), scope)

class Fake(Client):
    def __init__(self, folder='Sales-folder'):
        self.folder_name=folder; self.model='profile'; self.timeout=240
        self.folders=[{'id':'sales-id','name':'Sales-folder'}, {'id':'support-id','name':'Support-folder'}]
        self.shared=[]; self.records={}; self.calls=[]; self.denied=False
    def _json(self, method, path, payload=None, **kw):
        self.calls.append((method,path,copy.deepcopy(payload)))
        if path=='/api/v1/folders/': return self.folders
        if path=='/api/v1/folders/shared': return self.shared
        if path.startswith('/api/v1/models/model?'): return {'id':'profile','base_model_id':'base'}
        if path=='/api/models': return {'data':[{'id':'profile'}]}
        if path.startswith('/api/tasks/chat/'): return {'task_ids':[]}
        if path=='/api/v1/chats/new':
            if self.denied: raise Error('forbidden',403)
            key=str(len(self.records)+1)
            self.records[key]=dict(copy.deepcopy(payload),id=key)
            return copy.deepcopy(self.records[key])
        key=path.split('/')[4]
        if key not in self.records: raise Error('missing',404)
        if path.endswith('/folder'):
            if self.denied: raise Error('forbidden',403)
            self.records[key]['folder_id']=payload['folder_id']
        elif method=='POST': self.records[key]['chat'].update(copy.deepcopy(payload['chat']))
        return copy.deepcopy(self.records[key])
    def completed(self, ctx):
        self.records[ctx['chat_id']]['chat']['history']['messages'][ctx['assistant_id']]['done']=True

class FolderTests(unittest.TestCase):
    def test_create_in_each_folder(self):
        for name, expected in [('Sales-folder','sales-id'),('Support-folder','support-id')]:
            c=Fake(name); ctx=c.prepare(None,'Consulta','mail@example.test')
            self.assertEqual(c.records[ctx['chat_id']]['folder_id'],expected)
            self.assertEqual(ctx['chat']['title'],'mail@example.test')
            self.assertEqual(ctx['messages'],[{'role':'user','content':'Consulta'}])
    def test_reuse_preserves_history_and_does_not_duplicate(self):
        c=Fake(); first=c.prepare(None,'Primera','mail@example.test'); c.completed(first)
        c.records['1']['folder_id']=None
        second=c.prepare({'chat_id':'1'},'Segunda','mail@example.test')
        self.assertEqual(len(c.records),1)
        self.assertEqual(c.records['1']['folder_id'],'sales-id')
        self.assertEqual(len(second['chat']['history']['messages']),4)
        self.assertEqual(second['messages'][0]['content'],'Primera')
    def test_missing_or_duplicate_folder_has_no_writes(self):
        for folders in ([],[{'id':'a','name':'Sales-folder'},{'id':'b','name':'Sales-folder'}]):
            c=Fake();c.folders=folders
            with self.assertRaises(Error): c.prepare(None,'Hola','Title')
            self.assertFalse(any(m=='POST' for m,_,_ in c.calls))
    def test_shared_folder_requires_write(self):
        c=Fake();c.folders=[];c.shared=[{'id':'shared','name':'Sales-folder','permission':'read'}]
        with self.assertRaises(Error):c.prepare(None,'Hola','Title')
        c.shared[0]['permission']='write'
        ctx=c.prepare(None,'Hola','Title');self.assertEqual(c.records[ctx['chat_id']]['folder_id'],'shared')
    def test_denied_move_does_not_append_pending_turn(self):
        c=Fake();first=c.prepare(None,'Primera','Title');c.completed(first)
        c.records['1']['folder_id']=None;before=copy.deepcopy(c.records)
        c.denied=True
        with self.assertRaises(Error):c.prepare({'chat_id':'1'},'Segunda','Title')
        self.assertEqual(c.records,before)
    def test_already_assigned_no_move(self):
        c=Fake();ctx=c.prepare(None,'Primera','Title');c.completed(ctx)
        c.prepare({'chat_id':'1'},'Segunda','Title')
        self.assertFalse(any(path.endswith('/folder') for _,path,_ in c.calls))
    def test_deleted_chat_recreated_in_correct_folder(self):
        c=Fake('Support-folder');ctx=c.prepare({'chat_id':'deleted'},'Hola','Title')
        self.assertEqual(c.records[ctx['chat_id']]['folder_id'],'support-id')
    def test_titles_guest_stable_and_authenticated_email(self):
        class Controller:
            owner=None
            _owner=lambda self:self.owner
            _title=lambda self,stamp=None:'user@example.test' if self.owner else '07-10-2026_11:00:00_123'
            _desired_title=scope['_desired_title']
        c=Controller()
        for prefix in ('Ventas · ','Soporte · ',''):
            active={'title':prefix+'05-10-2026_09:12:45_987'}
            self.assertEqual(c._desired_title('sales',active),'05-10-2026_09:12:45_987')
            self.assertEqual(c._desired_title('sales',active),'05-10-2026_09:12:45_987')
        self.assertEqual(c._desired_title('support',{}),'07-10-2026_11:00:00_123')
        c.owner=1
        self.assertEqual(c._desired_title('support',active),'user@example.test')

if __name__=='__main__':unittest.main(verbosity=2)
