"""Prueba local: Socket.IO/Engine.IO reales; API y generacion simuladas."""
import ast, asyncio, copy, importlib.util, json, logging, sys, threading, time, types, unittest
from pathlib import Path
sys.path.insert(0, '/tmp/owui-socket-test')
from aiohttp import web
import socketio

class Response:
    def __init__(self, response='', status=200, headers=None, **kwargs):
        self.response, self.status_code, self.headers = response, status, headers or {}
http=types.ModuleType('odoo.http');http.Controller=object;http.route=lambda *a,**k:lambda f:f;http.request=None
odoo=types.ModuleType('odoo');odoo.http=http
sys.modules.update({'odoo':odoo,'odoo.http':http})
wrappers=types.ModuleType('werkzeug.wrappers');wrappers.Response=Response
sys.modules['werkzeug']=types.ModuleType('werkzeug');sys.modules['werkzeug.wrappers']=wrappers
package=types.ModuleType('testaddon');package.__path__=[str(Path(__file__).parent.resolve())];sys.modules['testaddon']=package
spec=importlib.util.spec_from_file_location('testaddon.main',Path(__file__).with_name('main.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

# Ejecutar las funciones publicadas de 0.11.4 con dobles de sus dependencias.
def source_function(path, name, scope):
    tree=ast.parse(Path(path).read_text())
    function=next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    function.decorator_list=[]
    exec(compile(ast.Module(body=[function],type_ignores=[]), path, 'exec'),scope)
    return scope[name]

TEST_JWT='header.payload.signature'
async def valid_token(data, redis):return True
async def get_user(identifier):return types.SimpleNamespace(id=identifier,role='user')
verified=source_function('/tmp/owui-v0114/backend__open_webui__utils__auth.py','get_verified_user_by_token',
 {'decode_token':lambda token: {'id':'u'} if token==TEST_JWT else None,
  'is_valid_token':valid_token,'Users':types.SimpleNamespace(get_user_by_id=get_user),'VERIFIED_USER_ROLES':{'user','admin'}})
overlay=source_function('/tmp/owui-v0114/backend__open_webui__routers__chats.py','overlay_response_streams',{})

class FakeOpenWebUI:
    def __init__(self, transport='websocket'):
        self.loop=asyncio.new_event_loop();self.ready=threading.Event();self.release=threading.Event()
        self.chats={};self.calls=[];self.tasks={};self.streams={};self.created=0;self.authenticated=0;self.socket_attempts=0
        self.mode='normal';self.transport=transport;self.port=None
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start();self.ready.wait(10)
        if not self.port:raise RuntimeError('Servidor de prueba no iniciado')
    def run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self.start());self.loop.run_forever();self.loop.close()
    async def start(self):
        self.sio=socketio.AsyncServer(async_mode='aiohttp',transports=[self.transport],always_connect=True,ping_interval=.25,ping_timeout=3)
        @self.sio.event
        async def connect(sid,environ,auth):
            self.socket_attempts+=1
            if auth and await verified(auth.get('token')):
                await self.sio.enter_room(sid,'user:test')
        @self.sio.on('user-join')
        async def joined(sid,data):
            if await verified(data.get('auth',{}).get('token','')):
                self.authenticated+=1
                await self.sio.enter_room(sid,'user:test');return {'id':'u','name':'private-name'}
        app=web.Application();self.sio.attach(app,socketio_path='/ws/socket.io')
        app.router.add_route('*','/{tail:.*}',self.api)
        self.runner=web.AppRunner(app);await self.runner.setup()
        site=web.TCPSite(self.runner,'127.0.0.1',0);await site.start();self.port=site._server.sockets[0].getsockname()[1];self.ready.set()
    async def api(self,request):
        path=request.path
        if request.method=='GET':
            if path=='/api/v1/folders/':
                return web.json_response([{'id':'sales-folder','name':'Sales-folder'}, {'id':'support-folder','name':'Support-folder'}])
            if path=='/api/v1/models/model':
                return web.json_response({'id':request.query.get('id'),'base_model_id':'base','write_access':False,'params':{},'meta':{'knowledge':[]}})
            if path=='/api/models':
                return web.json_response({'data':[{'id': 'ventas-clone','info': {'meta': {'knowledge': [{'id':'kb-sales','type':'collection'}]}}}, {'id': 'soporte-test', 'info': {'meta': {'knowledge': [{'id':'kb-support','type':'collection'}]}}}, {'id':'base'}]})
            if path.startswith('/api/tasks/chat/'):
                return web.json_response({'task_ids':['t'] if self.tasks.get(path.rsplit('/',1)[1]) else []})
            if path.startswith('/api/v1/chats/'):
                key=path.rsplit('/',1)[1]
                return web.json_response(overlay({'folder_id':getattr(self,'folder_ids',{}).get(key),'chat':copy.deepcopy(self.chats[key])},self.streams.get(key,[])))
        payload=await request.json();self.calls.append((path,copy.deepcopy(payload)))
        if path.endswith('/folder'):
            key=path.split('/')[-2];self.folder_ids=getattr(self,'folder_ids',{});self.folder_ids[key]=payload['folder_id']
            return web.json_response({'id':key,'folder_id':payload['folder_id']})
        if path=='/api/v1/chats/new':
            self.created+=1;key='chat-'+str(self.created);self.chats[key]=payload['chat'];return web.json_response({'id':key})
        if path.startswith('/api/v1/chats/'):
            key=path.rsplit('/',1)[1];self.chats[key].update(payload['chat']);return web.json_response({'id':key})
        if path=='/api/chat/completions':
            self.tasks[payload['chat_id']]=True
            asyncio.create_task(self.generate(payload));return web.json_response({'status':True,'task_ids':['t']})
        return web.json_response({},status=404)
    async def emit(self,payload,kind,data,foreign=False):
        await self.sio.emit('events',{'chat_id':'foreign-chat' if foreign else payload['chat_id'], 'message_id':payload['id'],'data':{'type':kind,'data':data}},room='user:test')
    async def generate(self,p):
        await self.emit(p,'chat:completion',{'content':'FOREIGN_CONVERSATION_SENTINEL'},foreign=True)
        await self.emit(p,'response:completion',{'type':'response.output_item.added','output_index':0,'item':{'type':'message','role':'assistant','content':[]}})
        await self.emit(p,'response:completion',{'type':'response.output_text.delta','output_index':0,'content_index':0,'delta':'Hola, soy '})
        self.streams[p['chat_id']]=[{'message_id':p['id'],'content':'Hola, soy ',
           'output':[{'type':'message','role':'assistant','content':[{'type':'output_text','text':'Hola, soy '}]}]}]
        while not self.release.is_set():await asyncio.sleep(.03)
        # Prueba los dos nombres de eventos que emite 0.11.4.
        await self.emit(p,'response:completion',{'type':'response.output_text.delta','output_index':0,'content_index':0,'delta':'TuxAIA.'})
        output=[{'type':'message','role':'assistant','content':[{'type':'output_text','text':'Hola, soy TuxAIA.'}]}]
        node=self.chats[p['chat_id']]['history']['messages'][p['id']]
        node.update(done=True,output=output,content='')
        node.pop('odoo_final',None)
        self.tasks[p['chat_id']]=False
        self.streams.pop(p['chat_id'],None)
        await self.emit(p,'chat:completion',{'done':True,'output':output})
    def stop(self):
        self.release.set()
        async def shutdown():
            await self.sio.shutdown();await self.runner.cleanup()
            pending=[t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
            for task in pending:task.cancel()
            await asyncio.gather(*pending,return_exceptions=True)
        asyncio.run_coroutine_threadsafe(shutdown(),self.loop).result(10)
        self.loop.call_soon_threadsafe(self.loop.stop);self.thread.join(3)

class Config:
    def __init__(self,url):self.values={'website_openwebui_chat.openwebui_url':url,'website_openwebui_chat.openwebui_api_key':TEST_JWT}
    def sudo(self):return self
    def get_param(self,key,default=None):return self.values.get(key,default)
class Env:
    uid=7
    def __init__(self,url):
        self.config=Config(url);self.user=types.SimpleNamespace(_is_public=lambda:False,partner_id=types.SimpleNamespace(id=101,email='test@example.test'))
    def __getitem__(self,key):return self.config

class NativeTests(unittest.TestCase):
    def setUp(self):
        self.server=FakeOpenWebUI();self.configure()
    def configure(self):
        self.url='http://127.0.0.1:'+str(self.server.port)
        m.request=types.SimpleNamespace(env=Env(self.url),website=types.SimpleNamespace(id=1),session={},params={},httprequest=types.SimpleNamespace(host='odoo.test',headers={'X-Requested-With':'XMLHttpRequest','Origin':'https://odoo.test'}))
        self.controller=m.OpenWebUIChatController()
        self.bootstrap()
    def bootstrap(self):
        r=self.controller.chat_session();self.assertEqual(r.status_code,200)
        token=json.loads(r.response)['token'];m.request.httprequest.headers['X-SlimAIA-Session']=token
        return token
    def tearDown(self):self.server.stop()
    def state(self):
        r=self.controller.state();self.assertEqual(r.status_code,200);return json.loads(r.response)
    def send(self,question):
        cid=self.state()['conversation_id'];m.request.params={'protocol':m.REVISION,'conversation_id':cid,'message':question}
        r=self.controller.stream_message();self.assertEqual(r.status_code,200);return iter(r.response)
    def test_native_stream_without_prompt_or_parameter_overrides_and_same_chat(self):
        question='  Hola, respeta mi texto exactamente.\nCPU y batería\n\nOtra línea: ñ 🔋  '
        stream=self.send(question);frames=[]
        for raw in stream:
            event=json.loads(raw);frames.append(event)
            if event['type']=='delta':break
        self.assertEqual(frames[-1]['text'],'Hola, soy ')
        self.assertFalse(self.server.release.is_set())
        # Esperar un ping real Engine.IO durante un turno abierto.
        time.sleep(.7);self.server.release.set();frames.extend(json.loads(x) for x in stream)
        self.assertEqual(frames[-1]['type'],'done')
        self.assertTrue(frames[-1]['saved'])
        calls=[p for path,p in self.server.calls if path=='/api/chat/completions']
        self.assertEqual(len(calls),1)
        for key in ('params','tools','system','temperature','top_k'):self.assertNotIn(key,calls[0])
        self.assertEqual(calls[0]['messages'][-1]['content'],question)
        self.assertEqual(calls[0]['user_message']['content'],question)
        self.assertEqual(self.server.authenticated,1)
        diagnostic=json.dumps([e for e in frames if e['type']=='diagnostic'])
        for secret in ('PRIVATE_PROMPT_SENTINEL',TEST_JWT,'test@example.test','FOREIGN_CONVERSATION_SENTINEL',question):
            self.assertNotIn(secret,diagnostic)
        self.assertNotIn('FOREIGN_CONVERSATION_SENTINEL',json.dumps(frames))
        self.assertEqual(self.state()['messages'][-1]['content'],'Hola, soy TuxAIA.')
        self.assertEqual(len(self.state()['messages']),2)
        list(self.send('Creative'))
        self.assertEqual(self.server.created,1)
        self.assertEqual(len(self.state()['messages']),4)
        self.assertEqual(len([p for path,p in self.server.calls if path=='/api/chat/completions']),2)
    def test_api_key_rejected_by_socket_but_live_http_works(self):
        # Esta es la distincion que v4 no probaba.
        self.assertIsNone(asyncio.run(verified('sk-test-key')))
        m.request.env.config.values['website_openwebui_chat.openwebui_api_key']='sk-test-key'
        stream=self.send('Hola sin cambiar mi mensaje')
        frames=[]
        for raw in stream:
            event=json.loads(raw);frames.append(event)
            if event['type']=='delta':break
        self.assertEqual(frames[-1]['text'],'Hola, soy ')
        self.assertFalse(self.server.release.is_set())
        self.assertEqual(self.server.socket_attempts,0)
        self.server.release.set();frames.extend(json.loads(x) for x in stream)
        self.assertEqual(frames[-1]['type'],'done')
        profile=next(e for e in frames if e.get('phase')=='profile_read')
        self.assertIsNone(profile['profile_prompt_present'])
        self.assertEqual(profile['profile_parameters_visibility'],'hidden_read_only')
        done=next(e for e in frames if e.get('phase')=='completed')
        self.assertGreater(done['updates_before_done'],0)
        self.assertEqual(done['transport'],'http_live_snapshots')
        self.assertEqual(self.state()['messages'][-1]['content'],'Hola, soy TuxAIA.')
        calls=[p for path,p in self.server.calls if path=='/api/chat/completions']
        self.assertEqual(len(calls),1)
        self.assertNotIn('params',calls[0]);self.assertNotIn('system',calls[0])
        self.assertEqual(calls[0]['user_message']['content'],'Hola sin cambiar mi mensaje')
        list(self.send('Segunda pregunta'))
        self.assertEqual(self.server.created,1)

    def test_agents_keep_independent_conversations_and_model_ids(self):
        self.server.release.set()
        m.request.env.config.values['website_openwebui_chat.openwebui_support_model'] = 'soporte-test'
        list(self.send('Consulta de ventas'))
        sales_id = self.state()['conversation_id']
        support_state = json.loads(self.controller.state(agent='support').response)
        self.assertNotEqual(sales_id, support_state['conversation_id'])
        self.assertEqual(support_state['messages'], [])
        m.request.params = {'protocol':m.REVISION, 'agent':'support', 'conversation_id':support_state['conversation_id'], 'message':'Consulta de soporte'}
        list(self.controller.stream_message().response)
        support = json.loads(self.controller.state(agent='support').response)
        self.assertEqual(support['messages'][0]['content'], 'Consulta de soporte')
        self.assertEqual(self.state()['messages'][0]['content'], 'Consulta de ventas')
        list(self.send('Segunda de ventas'))
        self.assertEqual(self.server.created, 2)
        calls = [p for path,p in self.server.calls if path=='/api/chat/completions']
        self.assertEqual([p['model'] for p in calls], ['ventas-clone','soporte-test','ventas-clone'])
        self.assertEqual(calls[0]['chat_id'], calls[2]['chat_id'])
        self.assertNotEqual(calls[0]['chat_id'], calls[1]['chat_id'])
        self.assertNotIn('Consulta de ventas', json.dumps(calls[1]))
        for payload in calls:
            self.assertNotIn('params', payload)
            self.assertFalse(any(msg['role']=='system' for msg in payload['messages']))

    def test_unconfigured_support_and_invalid_agent_do_not_create_chat(self):
        self.assertEqual(self.controller.state(agent='support').status_code, 503)
        self.assertEqual(self.controller.state(agent='unknown').status_code, 400)
        self.assertEqual(self.server.created, 0)
        self.assertEqual(self.controller._settings('sales')[0].model, 'ventas-clone')
        m.request.env.config.values['website_openwebui_chat.openwebui_sales_model'] = 'soporte-test'
        self.assertEqual(self.controller._settings('sales')[0].model, 'soporte-test')
        m.request.env.config.values['website_openwebui_chat.openwebui_sales_model'] = ''
        self.assertEqual(self.controller._settings('sales')[0].model, 'ventas-clone')

    def test_published_feature_defaults_are_used_without_copying_prompt_or_params(self):
        client=m.OpenWebUIClient(self.url,'sk-test-key','ventas-clone')
        ctx={'chat_id':'c', 'assistant_id':'a', 'user_node':{'id':'u','content':'Exact question'},
             'messages':[{'role':'user','content':'Exact question'}],
             'profile':{'meta':{}, 'params':{'system':'PRIVATE_PROMPT_SENTINEL','temperature':.1}},
             'resolved_model':{'info':{'meta':{'defaultFeatureIds':['web_search'],
                'capabilities':{'web_search':True},'toolIds':['profile-tool']}}}}
        payload=client._payload(ctx,'logical-session')
        self.assertTrue(payload['features']['web_search'])
        self.assertEqual(payload['tool_ids'],['profile-tool'])
        self.assertNotIn('params',payload)
        self.assertNotIn('PRIVATE_PROMPT_SENTINEL',json.dumps(payload))
        self.assertEqual(payload['model'],'ventas-clone')

    def test_restore_errors_from_v3_and_output_only_answers(self):
        chat={'history':{'currentId':'a','messages':{'u':{'role':'user','content':'Hola','parentId':None},
          'a':{'role':'assistant','content':'No he podido recuperar el contenido de la documentación.', 'parentId':'u','done':True,'error':{'content':'old error'},'odoo_final':True}}}}
        result=m._messages_from_chat(chat);self.assertEqual(len(result),2);self.assertTrue(result[-1]['error'])
        chat['history']['messages']['a'].update(content='',error=None,output=[{'type':'message','role':'assistant','content':[{'type':'output_text','text':'Solo output'}]}])
        self.assertEqual(m._messages_from_chat(chat)[-1]['content'],'Solo output')
    def test_socket_api_key_error_reports_phase_without_secrets(self):
        client=m.OpenWebUIClient(self.url,'sk-test-key','ventas-clone')
        channel=m.EventChannel(client,10)
        channel.chat_id=channel.message_id='probe'
        with self.assertRaises(m.TransportError) as result:
            channel.connect()
        self.assertEqual(result.exception.code,'events_authentication')
        self.assertEqual(result.exception.stage,'user_join_authentication')
        self.assertNotIn('sk-test-key',str(result.exception))
    def test_tool_round_is_not_end_of_turn_and_real_fixture_is_read(self):
        state=m.LiveOutput()
        state.apply({'type':'response:completion','data':{'type':'response.completed','response':{'output':[]}}})
        self.assertFalse(state.done)
        text=(Path(__file__).parent.parent/'upload'/'Texto pegado.txt').read_text()
        report=json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
        output=report['pruebas'][0]['salida_estructurada']
        state.apply({'type':'chat:completion','data':{'done':True,'output':output}})
        self.assertTrue(state.done);self.assertIn('Ryzen',state.text)
        self.assertGreaterEqual(state.stats()['file_reads'],1)
        self.assertGreaterEqual(state.stats()['knowledge_calls'],1)
    def test_polling_transport_when_websocket_disabled(self):
        self.server.stop();self.server=FakeOpenWebUI('polling');self.configure();self.server.release.set()
        frames=[json.loads(x) for x in self.send('Hola')]
        self.assertEqual(frames[-1]['type'],'done')
        self.assertTrue(any(e.get('transport')=='polling' for e in frames))
    def test_tab_token_required_even_with_persistent_odoo_cookie(self):
        self.server.release.set();list(self.send('Private question'))
        original=self.state()['conversation_id']
        old=m.request.httprequest.headers.pop('X-SlimAIA-Session')
        self.assertEqual(self.controller.state().status_code,409)
        self.bootstrap()
        self.assertEqual(self.state()['messages'],[])
        self.assertNotEqual(self.state()['conversation_id'],original)
        m.request.httprequest.headers['X-SlimAIA-Session']=old
        self.assertEqual(self.state()['conversation_id'],original)

    def test_expiry_and_reset_keep_remote_chats_but_revoke_browser_access(self):
        self.server.release.set();list(self.send('Private question'))
        old=m.request.httprequest.headers['X-SlimAIA-Session']
        tab,_=self.controller._tab();tab['last_activity']=time.time()-901;self.controller._store_tab(tab)
        self.assertEqual(self.controller.state().status_code,409)
        self.bootstrap();self.assertEqual(self.state()['messages'],[])
        self.assertEqual(len(self.server.chats),1)
        list(self.send('New session'))
        self.assertEqual(self.controller.end_chat().status_code,200)
        self.assertEqual(self.controller.state().status_code,409)
        self.bootstrap();self.assertEqual(self.state()['messages'],[])
        self.assertEqual(len(self.server.chats),2)
        m.request.httprequest.headers['X-SlimAIA-Session']=old
        self.assertEqual(self.controller.state().status_code,409)

    def test_guest_login_links_both_agents_without_replacing_history(self):
        m.request.session={};m.request.env.uid=3;m.request.env.user._is_public=lambda:True
        token=self.bootstrap();self.server.release.set()
        list(self.send('Guest sales'))
        m.request.env.config.values['website_openwebui_chat.openwebui_support_model']='soporte-test'
        support=json.loads(self.controller.state(agent='support').response)
        m.request.params={'protocol':m.REVISION,'agent':'support','conversation_id':support['conversation_id'],'message':'Guest support'}
        list(self.controller.stream_message().response)
        histories={key:copy.deepcopy(chat['history']) for key,chat in self.server.chats.items()}
        calls=len([p for path,p in self.server.calls if path=='/api/chat/completions'])
        m.request.env.uid=42;m.request.env.user._is_public=lambda:False
        m.request.env.user.partner_id.email='customer@example.test'
        self.assertEqual(self.bootstrap(),token)
        for key,chat in self.server.chats.items():
            self.assertEqual(chat['history'],histories[key])
            self.assertIn('customer@example.test',chat['title'])
            self.assertEqual(chat['odoo_contact']['user_id'],42)
        self.assertEqual(len([p for path,p in self.server.calls if path=='/api/chat/completions']),calls)
        self.assertEqual(self.state()['messages'][0]['content'],'Guest sales')
        self.assertEqual(json.loads(self.controller.state(agent='support').response)['messages'][0]['content'],'Guest support')
        m.request.env.uid=77
        self.assertEqual(self.controller.state().status_code,409)
        self.bootstrap();self.assertEqual(self.state()['messages'],[])

    def test_cross_origin_cannot_reset_or_start_chat(self):
        m.request.httprequest.headers['Origin']='https://foreign.test'
        self.assertEqual(self.controller.end_chat().status_code,403)
        self.assertEqual(self.controller.chat_session().status_code,403)
        self.assertEqual(self.server.created,0)

    def test_model_history_unchanged_from_v61(self):
        old=ast.parse((Path(__file__).parent.parent/'stream_v61'/'main.py').read_text())
        function=next(n for n in ast.walk(old) if isinstance(n,ast.FunctionDef) and n.name=='_messages_from_chat')
        scope={'_node_text':m._node_text,'IntegrationError':m.IntegrationError}
        exec(compile(ast.Module(body=[function],type_ignores=[]),'v61','exec'),scope)
        exported=json.loads((Path(__file__).parent.parent/'upload/chat-export-1791141869626.json').read_text())[0]['chat']
        self.assertEqual(m._messages_from_chat(exported,for_model=True),scope['_messages_from_chat'](exported,for_model=True))

    def test_title_preserved_repaired_and_guest_timestamp_stable(self):
        self.server.release.set();list(self.send('Hola'))
        chat=self.server.chats['chat-1'];self.assertEqual(chat['title'],'test@example.test')
        calls=[p for path,p in self.server.calls if path=='/api/chat/completions']
        self.assertNotIn('title_generation',calls[0]['background_tasks'])
        history=copy.deepcopy(chat['history']);chat['title']='Hola'
        self.state();self.assertEqual(chat['title'],'test@example.test');self.assertEqual(chat['history'],history)
        patch=self.server.calls[-1][1]['chat'];self.assertEqual(set(patch),{'title'})
        m.request.session={};m.request.env.user._is_public=lambda:True;self.bootstrap()
        list(self.send('Hola'));guest=self.server.chats['chat-2'];title=guest['title']
        self.assertRegex(title,r'^\d{2}-\d{2}-\d{4}_\d{2}:\d{2}:\d{2}_\d{3}$')
        list(self.send('Otra consulta'));self.assertEqual(guest['title'],title)

    def test_context_error_is_safe_and_restored_in_history(self):
        raw={'content':'request (40515 tokens) exceeds the available context size (32768 tokens), try increasing it'}
        exc=m._turn_error(raw);self.assertEqual(exc.code,'context_limit')
        self.assertEqual(exc.diagnostic,{'requested_tokens':40515,'context_limit':32768})
        self.server.release.set();list(self.send('Hola'))
        chat=self.server.chats['chat-1'];node=chat['history']['messages'][chat['history']['currentId']]
        node.update(content='',output=[],error=raw)
        message=self.state()['messages'][-1];self.assertEqual(message['error_code'],'context_limit')
        self.assertNotIn(raw['content'],message['content'])
        self.assertEqual(m._turn_error({'content':'PRIVATE_CONTENT'}).code,'upstream_turn_error')
        self.assertNotIn('PRIVATE_CONTENT',str(m._turn_error({'content':'PRIVATE_CONTENT'})))

    def test_context_limit_reaches_stream_and_private_diagnostic(self):
        client=m.OpenWebUIClient(self.url,'sk-test','ventas-clone')
        client._profile_diagnostic=lambda ctx: {'phase':'profile_read'}
        client._payload=lambda ctx,sid: {}
        client._json=lambda *args,**kw: {'status':True}
        client._chat=lambda ctx: ({},{'error':{'content':'request (40515 tokens) exceeds the available context size (32768 tokens), try increasing it'},'done':True})
        frames=[json.loads(raw) for raw in client._stream_snapshots({'trace':'test'})]
        failure=next(x for x in frames if x.get('phase')=='error')
        self.assertEqual(failure['reason_code'],'context_limit')
        self.assertEqual(failure['requested_tokens'],40515)
        self.assertEqual(failure['context_limit'],32768)
        self.assertEqual(failure['transport_stage'],'model_response')
        self.assertEqual(frames[-1]['code'],'context_limit')

    def test_real_openwebui_title_fallback_is_skipped_when_key_absent(self):
        updates=[]
        messages={'u':{'role':'user','content':'Hola'},'a':{'role':'assistant','content':'Respuesta','model':'ventas-clone'}}
        async def get_map(chat_id):return messages
        async def update_title(chat_id,title):updates.append(title)
        async def emitter(event):pass
        async def review(*args,**kw):pass
        handler=source_function('/tmp/tuxaia_sources/middleware.py','background_tasks_handler',{
            're':__import__('re'),'review_memory_after_turn':review,'is_saved_chat_id':lambda cid:True,
            'Chats':types.SimpleNamespace(get_messages_map_by_chat_id=get_map,update_chat_title_by_id=update_title),
            'get_message_list':lambda m,i:list(m.values()),'get_last_user_message':lambda m:m[0]['content'],
            'TASKS':types.SimpleNamespace(TITLE_GENERATION='title_generation',TAGS_GENERATION='tags_generation',FOLLOW_UP_GENERATION='follow_up_generation')})
        ctx={'request':None,'form_data':{},'user':None,'model':{},'metadata':{'chat_id':'c','message_id':'a'},'event_emitter':emitter,
             'tasks':{'title_generation':False,'tags_generation':False,'follow_up_generation':False}}
        asyncio.run(handler(ctx));self.assertEqual(updates,['Hola'])
        updates.clear();ctx['tasks'].pop('title_generation');asyncio.run(handler(ctx));self.assertEqual(updates,[])

    def test_project_url_is_optional_and_validated(self):
        self.assertNotIn('project_url',json.loads(self.controller.agents().response))
        m.request.env.config.values['website_openwebui_chat.project_url']='https://tuxaia.com'
        self.assertEqual(json.loads(self.controller.agents().response)['project_url'],'https://tuxaia.com')
        for bad in ['javascript:alert(1)','https://user:secret@tuxaia.com','https://[bad']:
            m.request.env.config.values['website_openwebui_chat.project_url']=bad
            self.assertNotIn('project_url',json.loads(self.controller.agents().response))

    def test_disabled_stops_bootstrap_and_generation(self):
        m.request.env.config.values['website_openwebui_chat.openwebui_active']='False'
        self.assertEqual(json.loads(self.controller.agents().response), {'active':False})
        self.assertEqual(self.controller.chat_session().status_code,503)
        with self.assertRaises(m.IntegrationError):self.controller._settings()
        self.assertEqual(self.server.created,0)

    def test_cloudflare_headers_all_api_routes_and_no_public_credentials(self):
        from unittest.mock import patch
        from io import BytesIO
        client=m.OpenWebUIClient('https://ai.test','API_SECRET','ventas-clone',
            cf_client_id='test.access',cf_client_secret='CF_SECRET')
        observed=[]
        class Opener:
            def open(self, request, **kw):
                observed.append(request)
                response=BytesIO(b'{}');response.headers={};return response
        client.opener=Opener()
        for path in ['/api/models','/api/v1/chats/chat-id','/api/tasks/chat/chat-id','/api/chat/completions']:
            client._json('GET' if path!='/api/chat/completions' else 'POST',path)
        for request in observed:
            headers={k.lower():v for k,v in request.header_items()}
            self.assertEqual(headers['cf-access-client-secret'],'CF_SECRET')
            self.assertEqual(headers['cf-access-client-id'],'test.access')
            self.assertEqual(headers['authorization'],'Bearer API_SECRET')
        # El handshake WebSocket necesita las mismas credenciales de Access.
        with patch.object(m.EventChannel.connect.__globals__['websocket'], 'create_connection', side_effect=RuntimeError('hidden')) as connect:
            with self.assertRaises(m.TransportError):m.EventChannel(client,10).connect()
            self.assertEqual(connect.call_args.kwargs['header'],{'CF-Access-Client-Id':'test.access','CF-Access-Client-Secret':'CF_SECRET'})
            self.assertEqual(connect.call_args.kwargs['redirect_limit'],0)
        channel=m.EventChannel(client,10);channel._poll()
        self.assertEqual(dict((k.lower(),v) for k,v in observed[-1].header_items())['cf-access-client-secret'],'CF_SECRET')
        for url,id_value,secret in [('http://ai.test','test.access','CF_SECRET'),('https://ai.test','test.access',''),('https://ai.test','test.access','bad\nvalue')]:
            with self.assertRaises(m.IntegrationError):m.OpenWebUIClient(url,'API_SECRET','ventas-clone',cf_client_id=id_value,cf_client_secret=secret)
        m.request.env.config.values.update({'website_openwebui_chat.cf_client_id':'test.access','website_openwebui_chat.cf_client_secret':'CF_SECRET'})
        public=self.controller.agents().response
        self.assertNotIn('CF_SECRET',public);self.assertNotIn('test.access',public)


if __name__=='__main__':unittest.main(verbosity=2)
