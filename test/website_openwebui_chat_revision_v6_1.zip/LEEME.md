# SlimAIA · revisión v6.1

Parte de la revisión v5 que confirmaste que funciona. Mantiene la preparación de preguntas, el historial enviado, el perfil de Open WebUI y el transporte de generación. No añade instrucciones, no modifica preguntas ni impone temperatura, top_k o modo de herramientas. Cada perfil conserva su configuración en Open WebUI.


## Cambios de v6.1

- Se mantienen las actualizaciones de respuesta que llegan durante la generación. Cada fragmento nuevo se revela con una cortina horizontal y opacidad de **180 ms**, mediante CSS. Se retira el efecto por caracteres; no se acumula la respuesta completa antes de mostrarla.
- Se conservan los nodos de texto y formato ya mostrados. Un párrafo nuevo de varias líneas se descubre conjuntamente; no se calculan ni separan líneas visuales. Al completarse Markdown incompleto, su formato puede corregirse sin volver a animar párrafos anteriores.
- El pingüino blanco tiene una regla `display` explícita y limitada a la cabecera para imponerse a reglas del tema que ocultaban el icono.
- «SlimAIA está pensando» lleva tres puntos que pulsan por turnos con CSS. El texto y su espacio permanecen fijos. No hay nuevas peticiones o temporizadores de animación JavaScript.
- Las dos animaciones respetan la preferencia de movimiento reducido.
- El bloque antiguo de Ajustes identifica el modelo general como **Modelo de Ventas (respaldo)** y explica dónde configurar ambos agentes. Se ocultan los campos antiguos vinculados a parámetros de prompt del addon; sus valores no se borran. La URL, la clave y la activación continúan en ese bloque.

**Actualización desde v6:** no desinstales el módulo. Ejecuta el instalador, reinicia Odoo, actualiza el módulo desde Aplicaciones y recarga con Ctrl+F5. Se conserva el protocolo `native-profile-v6` y la sesión de pestaña de v6. `SlimAIADebug.snapshot()` añade `widget_revision: "blocks-v6.1"` al evento `widget_loaded` para identificar esta actualización.

El controlador, el transporte, el registro privado y la configuración enviada a Open WebUI son idénticos a v6. Los cambios del servidor en esta revisión solo afectan a la presentación de Ajustes.

## Instalación

Descomprime **todo** el ZIP en una carpeta y, desde esa carpeta, ejecuta:

```bash
python3 instalar.py /home/od/odoo/slimbook/website_openwebui_chat
```

Usa una cuenta con permiso para modificar el addon. El instalador crea una copia privada en `/tmp/website_openwebui_chat_backup_v61_…`; conserva el manifiesto, su autoría y los imports existentes. Copia los auxiliares incluidos; no necesita instalar paquetes Python globales.

Después:

1. Reinicia Odoo con el procedimiento habitual de tu instalación.
2. **Actualiza el módulo `website_openwebui_chat` en Aplicaciones.** Reiniciar por sí solo no carga los campos y el menú nuevos.
3. Recarga la página con Ctrl+F5.
4. Como administrador, abre **Ajustes → SlimAIA**, el nuevo menú dedicado. Configura los dos IDs y pulsa **Guardar**.

La revisión se puede comprobar en la consola del navegador:

```javascript
JSON.stringify(SlimAIADebug.snapshot(), null, 2)
```

Debe indicar `native-profile-v6`. La consola no imprime registros automáticamente; para activarlos temporalmente: `SlimAIADebug.setEnabled(true)`. El historial de diagnóstico está limitado a 60 entradas y excluye conversaciones, documentos, credenciales y texto del prompt.

**Al actualizar desde v5, el chat de la web comienza vacío una vez**, porque v6 exige una credencial nueva de pestaña para recuperar conversaciones. Los chats anteriores se conservan en Open WebUI. Después, las recargas normales mantienen los mensajes y el estado abierto/cerrado mientras la sesión del chat siga vigente.

## Ventas y Soporte

La pantalla dedicada evita depender del filtro de la pantalla general de Ajustes. Muestra ambos IDs y solo guarda sus propios seis parámetros; no sobrescribe ajustes de otros módulos.

- **Modelo de Ventas (ID):** ID exacto del perfil personalizado, por ejemplo `ventas-clone`. Vacío conserva el modelo general anterior del addon.
- **Modelo de Soporte (ID):** ID exacto del segundo perfil. Vacío deja Soporte sin activar; no usa Ventas como sustituto.

La clave API existente debe poder acceder a ambos perfiles. La URL y la clave siguen en los ajustes anteriores. No se crean campos de prompt en Odoo.

Cada agente conserva un chat independiente. Cambiar de agente no genera respuestas ni crea un chat remoto: el primer mensaje crea su chat; los siguientes reutilizan el mismo.

## Interfaz en español e inglés

El idioma sigue `html.lang` de la web, sin cambiar el prompt o el idioma de respuesta del modelo.

- Cabecera y botón de envío `#0056b3`; mensajes del cliente `#3984c6`.
- Pingüino **blanco monocromo** de Font Awesome (`fa-linux`) junto a SlimAIA y su subtítulo. El lanzador conserva el pingüino original en color, con **Hola / Hello** debajo, dentro del mismo botón.
- Franja inferior de dos columnas, encima del campo de mensaje: selector azul **Hablar con / Talk to** a la izquierda; **Entra en tu cuenta para vincular esta conversación contigo** a la derecha. Al estar identificado se oculta la invitación a entrar.
- Botón **↻ Nueva conversación / New conversation** al lado de enviar. Se desactiva durante una respuesta.
- Aviso pequeño sobre errores de la IA y enlace **Aviso legal / Legal notice** a https://slimbook.com/legal.
- H1 de las respuestas: `1.2rem`; H2 y H3: `1.1rem`.
- Indicador **SlimAIA está pensando… / SlimAIA is thinking…**.

El texto recibido se descubre con cortina y opacidad durante 180 ms. JavaScript reconcilia el contenido saneado una vez por bloque recibido; CSS realiza la animación. No hay un bucle por carácter ni por fotograma. Los bloques ya mostrados se conservan. Respeta la preferencia de movimiento reducido y muestra directamente respuestas muy largas o recibidas con el panel oculto. No añade peticiones al modelo. El transporte con clave API continúa recibiendo bloques mediante el mecanismo que funcionaba en v6: **el efecto visual no convierte ese transporte en streaming real de tokens**.

## Entrar en la cuenta desde una conversación

El enlace de entrada mantiene la misma pestaña y regresa a la página. Tras la autenticación Odoo, los chats de Ventas y Soporte iniciados como invitado conservan su identidad e historial; su título pasa a identificar al cliente por su correo. Se añade una referencia al usuario/contacto de Odoo en la metadata del chat.

Solo se actualizan título y metadata; no se reescribe el historial para asociar la cuenta. Esto **no crea una cuenta Open WebUI para el cliente ni transfiere la propiedad del chat**: siguen siendo chats de la cuenta de integración, identificados con los datos autenticados de Odoo. Si la asociación remota falla, queda pendiente para reintentar.

## Privacidad y duración

Se exige una credencial aleatoria por pestaña, guardada en `sessionStorage`. Los mensajes no se guardan en `localStorage` ni en `sessionStorage`; se recuperan del servidor. La cookie de Odoo por sí sola ya no permite recuperar un chat de SlimAIA. Se retiran las antiguas cachés del widget al cargar v6.

- Caducidad predeterminada: **15 minutos sin actividad**, configurable entre 5 y 120 minutos. Se comprueba también en el servidor.
- Una recarga normal conserva el chat mientras su sesión siga activa.
- **↻ Nueva conversación** revoca la asociación de esa pestaña para ambos agentes y limpia la interfaz. Los chats anteriores permanecen en Open WebUI. Se crea otro chat remoto únicamente al enviar el siguiente mensaje.
- Un usuario autenticado distinto no puede adoptar la conversación del anterior. Se revalida el acceso al volver a la pestaña o restaurarla desde la caché del navegador.
- No hay consultas periódicas en reposo; la actividad del cliente puede renovar la sesión con una frecuencia limitada.

**Cerrar el navegador no es una garantía de borrado:** algunos navegadores restauran pestañas y su `sessionStorage`. En un ordenador compartido, utiliza ↻ y cierra la sesión de tu cuenta Odoo antes de marcharte. La caducidad limita el tiempo de exposición, pero no sustituye esa acción. Los eventos de cierre del navegador no permiten implementar una garantía universal fiable.

## Registro privado del servidor

Desactivado por defecto. Se configura en **Ajustes → SlimAIA** o mediante los parámetros de sistema siguientes:

| Parámetro | Valor predeterminado |
| --- | --- |
| `website_openwebui_chat.debug_logging` | `False` |
| `website_openwebui_chat.debug_prompt` | `False` |
| `website_openwebui_chat.debug_log_path` | `/var/log/odoo/slimaia_debug.log` |
| `website_openwebui_chat.session_idle_minutes` | `15` |
| `website_openwebui_chat.openwebui_sales_model` | Vacío: usa el modelo general anterior |
| `website_openwebui_chat.openwebui_support_model` | Vacío: Soporte desactivado |

Para registrar: activa el diagnóstico, elige la ruta y guarda. Para detenerlo: desactívalo y guarda; se comprueba el interruptor antes de cada escritura, incluso durante una generación en curso. No hace falta reiniciar para ese cambio.

La carpeta debe existir y permitir al usuario del proceso Odoo crear y rotar archivos. Se puede seleccionar `/tmp/slimaia_debug.log` si `/var/log/odoo/` no es escribible. **No se presupone que `/tmp` se limpie automáticamente**: depende del sistema. Ambas rutas usan rotación propia.

Se escriben líneas JSON, con permisos `0600`, bloqueo entre procesos Odoo y rotación de **5 MiB por archivo más tres copias**: aproximadamente 20 MiB en total. Un fallo de permisos produce un aviso genérico en el log habitual, no interrumpe la respuesta y no vuelca contenido sensible allí.

El registro recoge IDs de modelo, parámetros observables, capacidades publicadas, contadores, tiempos y errores técnicos. No guarda preguntas, respuestas, documentos, cookies o claves API. La instantánea de perfil se registra al primer turno observado de cada conversación/agente y cuando cambia su configuración, evitando repetir el prompt en cada mensaje.

Para leer el texto del prompt es necesario activar también **Incluir el prompt del perfil si la API permite leerlo**. Se guarda solo en el archivo privado, con un máximo de 65.536 caracteres y marca de truncado. Ese archivo debe tratarse como privado porque contiene las instrucciones comerciales o internas del perfil. No se publica en el navegador ni se le pide al modelo que revele sus instrucciones.

**Límite de la comprobación:** se registra lo que la API autoriza a leer del perfil, no la petición final recibida por el motor tras filtros y ajustes globales. Si la API oculta el prompt o los parámetros, se indica como no observable; no se inventan valores ni se elevan permisos. Que no se observen llamadas a herramientas tampoco descarta por sí solo un contexto RAG inyectado de otra manera.

## Validación realizada en v6.1

- Comprobado que `main.py`, `openwebui_transport.py` y `private_debug.py` son idénticos a v6.
- Chromium real a 375 y 1200 píxeles, ES/EN: regla del tema que oculta iconos simulada, pingüino visible, puntos animados, fragmentos separados por un segundo visibles antes del final, una sola generación, nodos anteriores conservados y movimiento reducido.
- Pruebas de DOM: UTF-8 fragmentado, Markdown seguro, continuidad de sesiones, dos agentes, caducidad y reinicio.
- Dos pruebas de adaptación de la vista antigua: modelo de respaldo aclarado, prompt obsoleto oculto, campos de otros módulos intactos. Odoo simulado.
- Instalador comprobado sobre un addon temporal, incluyendo ejecución repetida.

## Validaciones anteriores de v6

- 14 pruebas de controlador, con API/modelo simulados y Socket.IO real local: una generación por turno, reutilización de chats, agentes independientes, adopción tras login, aislamiento entre usuarios/pestañas, caducidad y reinicio sin borrar chats remotos.
- Comparación del código de preparación, payload, extracción de historial y ambos transportes con v5: sin cambios.
- Cuatro pruebas de registro: permisos, rotación concurrente entre procesos, exclusión de campos no permitidos, rechazo de enlaces simbólicos, prompt privado y apagado durante generación.
- Instalador probado dos veces sobre un addon temporal, sin duplicar imports/vistas ni cambiar autoría.
- Widget con jQuery de Odoo 13: UTF-8 fragmentado, Markdown seguro, animación, movimiento reducido, restauración, agentes, reinicio, caducidad y ausencia de mensajes en almacenamiento.
- **Chromium real** a 375 y 1200 píxeles, en español e inglés: diseño, controles, icono blanco, imagen y ausencia de desbordamientos o errores JavaScript. API simulada.

No se ha desplegado en tu servidor ni se dispone aquí de una instancia completa de Odoo 13 o de tu modelo. Las pruebas locales no acreditan las respuestas del modelo ni la recuperación real de tus documentos.

Se contrastó la autenticación de Odoo 13 y la actualización parcial de chats de Open WebUI 0.11.4 con su código publicado:

- https://github.com/odoo/odoo/blob/13.0/odoo/http.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/routers/chats.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/models/chats.py

## Revertir

La copia del instalador contiene `archivos.json`: restaura desde ella los archivos con `existed: true`; retira los que indique como nuevos. Incluye el manifiesto y el inicializador anteriores. Después reinicia Odoo y actualiza el addon. No borres los chats de Open WebUI.
