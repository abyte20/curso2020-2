"""Registro privado acotado: bloqueo entre workers y sin contenido de clientes."""
import fcntl
import json
import logging
import os
import re
import stat
import threading
import time

_LOCK = threading.RLock()
_WARNING_AT = 0
_ALLOWED = frozenset(('revision', 'request', 'phase', 'agent', 'chat_ref', 'profile_prompt_present',
    'profile_parameters_visibility', 'requested_model_id', 'profile_base_model_id',
    'profile_parameters', 'parameter_overrides', 'system_messages_added', 'user_message_changed',
    'effective_prompt_verified', 'effective_tools_verified', 'engine_effective_parameters',
    'request_message_count', 'request_characters', 'stored_tool_calls', 'stored_tool_results',
    'profile_knowledge_count', 'published_knowledge_count', 'published_builtin_tools_enabled',
    'published_knowledge_tools_enabled', 'prompt_sha256', 'prompt_characters', 'profile_prompt',
    'prompt_truncated', 'prompt_redacted', 'profile_source', 'transport', 'elapsed_ms',
    'first_text_ms', 'events_received', 'knowledge_calls', 'file_reads', 'tool_results',
    'snapshots_received', 'progressive_updates', 'updates_before_done', 'saved', 'code',
    'exception_type', 'http_status', 'transport_stage'))


def _secure_open(path):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_nlink != 1:
        os.close(fd)
        raise OSError('El archivo de diagnostico no es privado del usuario Odoo.')
    os.fchmod(fd, 0o600)
    return fd


class PrivateDebug:
    def __init__(self, path, enabled, max_bytes=5*1024*1024, backups=3):
        self.path, self.enabled = path, enabled
        self.max_bytes, self.backups = max_bytes, backups

    def write(self, values):
        global _WARNING_AT
        try:
            if not self.enabled():
                return False
            if not os.path.isabs(self.path) or not self.path.endswith('.log'):
                raise OSError('Ruta de diagnostico invalida.')
            record = {key: value for key, value in values.items() if key in _ALLOWED}
            record['timestamp_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
            data = (json.dumps(record, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8')
            if len(data) > 128*1024:
                record.pop('profile_prompt', None)
                record['prompt_truncated'] = True
                data = (json.dumps(record, ensure_ascii=False) + '\n').encode('utf-8')
            with _LOCK:
                lockfd = _secure_open(self.path + '.lock')
                try:
                    fcntl.flock(lockfd, fcntl.LOCK_EX)
                    # Comprobar otra vez despues de esperar por otro worker.
                    if not self.enabled():
                        return False
                    if os.path.lexists(self.path):
                        checkfd = _secure_open(self.path)
                        size = os.fstat(checkfd).st_size
                        os.close(checkfd)
                        if size + len(data) > self.max_bytes:
                            for number in range(self.backups, 0, -1):
                                previous = self.path if number == 1 else self.path + '.' + str(number-1)
                                destination = self.path + '.' + str(number)
                                if os.path.lexists(previous):
                                    if os.path.islink(previous) or os.path.islink(destination):
                                        raise OSError('Enlace no permitido en rotacion.')
                                    os.replace(previous, destination)
                    fd = _secure_open(self.path)
                    try:
                        with os.fdopen(fd, 'ab') as output:
                            output.write(data)
                    except Exception:
                        raise
                finally:
                    fcntl.flock(lockfd, fcntl.LOCK_UN)
                    os.close(lockfd)
            return True
        except Exception as exc:
            if time.monotonic() - _WARNING_AT > 60:
                _WARNING_AT = time.monotonic()
                logging.getLogger(__name__).warning('SlimAIA: no se pudo escribir el diagnostico privado (%s). Revisa la ruta y permisos.', type(exc).__name__)
            return False
