from odoo import fields, models, _
from odoo.exceptions import AccessError, ValidationError
import os


class SlimAIASettings(models.TransientModel):
    _inherit = 'res.config.settings'

    slimaia_sales_model_id = fields.Char(string='Modelo de Ventas (ID)',
        config_parameter='website_openwebui_chat.openwebui_sales_model',
        help='ID exacto del perfil Open WebUI. Vacio conserva el modelo general anterior.')
    slimaia_support_model_id = fields.Char(string='Modelo de Soporte (ID)',
        config_parameter='website_openwebui_chat.openwebui_support_model')
    slimaia_debug_logging = fields.Boolean(string='Activar registro privado de diagnostico',
        config_parameter='website_openwebui_chat.debug_logging', default=False)
    slimaia_debug_prompt = fields.Boolean(string='Incluir el prompt del perfil si la API permite leerlo',
        config_parameter='website_openwebui_chat.debug_prompt', default=False)
    slimaia_debug_path = fields.Char(string='Archivo del registro',
        config_parameter='website_openwebui_chat.debug_log_path', default='/var/log/odoo/slimaia_debug.log')
    slimaia_idle_minutes = fields.Integer(string='Caducidad del chat por inactividad (minutos)',
        config_parameter='website_openwebui_chat.session_idle_minutes', default=15)

    def action_slimaia_save(self):
        self.ensure_one()
        if not self.env.user.has_group('base.group_system'):
            raise AccessError(_('Solo los administradores pueden configurar SlimAIA.'))
        path = (self.slimaia_debug_path or '/var/log/odoo/slimaia_debug.log').strip()
        if not os.path.isabs(path) or not path.endswith('.log'):
            raise ValidationError(_('Usa una ruta absoluta terminada en .log.'))
        if not 5 <= self.slimaia_idle_minutes <= 120:
            raise ValidationError(_('La caducidad debe estar entre 5 y 120 minutos.'))
        values = {
            'openwebui_sales_model': (self.slimaia_sales_model_id or '').strip(),
            'openwebui_support_model': (self.slimaia_support_model_id or '').strip(),
            'debug_logging': 'True' if self.slimaia_debug_logging else 'False',
            'debug_prompt': 'True' if self.slimaia_debug_prompt else 'False',
            'debug_log_path': path,
            'session_idle_minutes': str(self.slimaia_idle_minutes),
        }
        for key, value in values.items():
            self.env['ir.config_parameter'].sudo().set_param('website_openwebui_chat.' + key, value)
        # No ejecutar res.config.settings.execute(): esta pantalla solo guarda
        # sus seis ajustes y nunca valores de otros modulos que no se muestran.
        return {'type': 'ir.actions.client', 'tag': 'reload'}
