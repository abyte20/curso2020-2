odoo.define('website_openwebui_chat.widget', function (require) {
    'use strict';
    var PROTOCOL = 'native-profile-v6';
    $(document).ready(function () {
        if (!document.getElementById('ow-chat-messages')) return;
        var english = /^en([_-]|$)/i.test(document.documentElement.lang || 'es');
        function tr(es, en) { return english ? en : es; }
        var conversation = null, token = null, agent = 'sales', authenticated = false;
        var agents = {sales:true, support:false}, busy = false, ready = false;
        var openPreference = '0', expiresAt = 0, idleSeconds = 900;
        var restoreSequence = 0, expiryTimer = null, pendingTimer = null, animation = null;
        var lastTouch = 0, lastFocus = 0, sessionPromise = null;
        var $modal = $('#openwebui-chat-modal'), $messages = $('#ow-chat-messages');
        try {
            var stored = JSON.parse(sessionStorage.getItem('slimaia_session_v6') || 'null');
            if (stored && stored.expires_at > Date.now()/1000) {
                token = stored.token; agent = stored.agent === 'support' ? 'support' : 'sales';
                openPreference = stored.open === '1' ? '1' : '0'; expiresAt = stored.expires_at;
            }
            // Retirar las copias de mensajes que guardaban versiones anteriores.
            ['slimbook_chat_v4','slimbook_chat_v5_sales','slimbook_chat_v5_support','slimaia_agent','slimaia_open_v4'].forEach(function(k){sessionStorage.removeItem(k);});
        } catch (ignore) {}
        $messages.empty();
        if (openPreference === '1') $modal.removeClass('ow-hidden');
        $('.ow-chat-header span').first().empty()
            .append($('<i class="fa fa-linux ow-header-penguin" aria-hidden="true">'))
            .append($('<span class="ow-header-title">').append($('<strong>').text('SlimAIA'))
                .append($('<small>').text(tr('Asistente Inteligencia Artificial','Artificial Intelligence Assistant'))));
        var $launcher = $('#openwebui-chat-button').empty()
            .append($('<img>').attr({src:'/website_openwebui_chat/static/src/img/agent_icon.png',alt:''}))
            .append($('<span class="ow-launcher-label">').text(tr('Hola','Hello')))
            .attr({role:'button',tabindex:'0','aria-label':tr('Hola. Abre el chat con SlimAIA','Hello. Open SlimAIA chat'),'aria-controls':'openwebui-chat-modal'});
        $('#ow-chat-close').attr('aria-label',tr('Cerrar ventana del chat','Close chat window'));
        $('#ow-chat-send').attr({type:'button','aria-label':tr('Enviar mensaje','Send message'),title:tr('Enviar mensaje','Send message')});
        $('#ow-chat-input').attr({placeholder:tr('Escribe tu consulta…','Type your question…'),'aria-label':tr('Tu mensaje','Your message')});
        var $selector = $('<select id="ow-chat-agent">').attr('aria-label',tr('Hablar con','Talk to'))
            .append($('<option value="sales">').text(tr('Ventas','Sales')))
            .append($('<option value="support">').text(tr('Soporte','Support'))).val(agent);
        var $bar = $('<div class="ow-agent-bar">');
        var $department = $('<div class="ow-agent-column">').append($('<label for="ow-chat-agent">').text(tr('Hablar con','Talk to'))).append($selector);
        var $login = $('<a class="ow-login-link">').text(tr('Entra en tu cuenta','Sign in to your account'));
        var redirect = window.location.pathname + window.location.search + '#slimaia';
        $login.attr('href','/web/login?redirect=' + encodeURIComponent(redirect));
        var $account = $('<div class="ow-account-column">').append($login)
            .append(document.createTextNode(tr(' para vincular esta conversación contigo.',' to link this conversation to you.')));
        $bar.append($department).append($account);
        var $footer = $('.ow-chat-footer');
        if (!$footer.length) $footer = $('#ow-chat-input').parent();
        $footer.before($bar);
        var $reset = $('<button id="ow-chat-reset" type="button">').text('↻').attr({
            'aria-label':tr('Nueva conversación: finalizar los chats actuales','New conversation: end the current chats'),
            title:tr('Nueva conversación','New conversation')});
        $('#ow-chat-send').before($reset);
        var $notice = $('<div class="ow-chat-notice" role="status">');
        $bar.before($notice);
        $('<div class="ow-disclaimer">')
            .append(document.createTextNode(tr('La IA puede cometer errores. Comprueba la información importante.','AI can make mistakes. Check important information.')))
            .append($('<span class="ow-legal">').append(document.createTextNode(tr('Lee el ','Read the ')))
                .append($('<a>').attr({href:'https://slimbook.com/legal',target:'_blank',rel:'noopener noreferrer'}).text(tr('Aviso legal','Legal notice')))
                .append(document.createTextNode(tr(' aquí.',' here.')))).appendTo($modal);
        function publicError(message) {
            return english ? 'The request could not be completed. Reload to check the saved conversation before trying again.' : (message || 'No se pudo completar la consulta.');
        }
        function headers() { var h={'X-Requested-With':'XMLHttpRequest'}; if(token)h['X-SlimAIA-Session']=token; return h; }
        function cache() {
            try {
                if(token) sessionStorage.setItem('slimaia_session_v6',JSON.stringify({token:token,agent:agent,open:openPreference,expires_at:expiresAt}));
                else sessionStorage.removeItem('slimaia_session_v6');
            } catch(ignore) {}
        }
        function controls() {
            $('#ow-chat-send, #ow-chat-input').prop('disabled',busy || !ready);
            $selector.prop('disabled',busy); $reset.prop('disabled',busy);
            $login.attr('aria-disabled', busy ? 'true' : 'false');
        }
        function scroll() { var e=$messages[0];e.scrollTop=e.scrollHeight; }
        function identity(value) {authenticated=Boolean(value);$account.toggle(!authenticated);$bar.toggleClass('ow-authenticated',authenticated);}
        function armExpiry() {
            window.clearTimeout(expiryTimer);
            if(!expiresAt)return;
            expiryTimer=window.setTimeout(function(){
                if(busy){expiryTimer=window.setTimeout(armExpiry,1000);return;}
                expire();
            },Math.max(100,expiresAt*1000-Date.now()));
        }
        function expire() {
            ++restoreSequence;ready=false;conversation=null;token=null;expiresAt=0;
            window.clearTimeout(pendingTimer);window.clearTimeout(expiryTimer);
            if(animation)animation.cancel();
            $messages.empty();$('#ow-chat-input').val('');cache();controls();
            $notice.empty().text(tr('La sesión del chat ha terminado por seguridad. ','The chat session has ended for your privacy. '))
                .append($('<button type="button" class="ow-retry">').text(tr('Empezar de nuevo','Start again')).on('click',function(){bootstrap().then(function(){restore();}).catch(showSessionError);}));
        }
        function showSessionError(error) {$notice.text(publicError(error.message));controls();}
        async function bootstrap() {
            if(sessionPromise)return sessionPromise;
            sessionPromise=(async function(){
                var oldToken=token;
                var r=await fetch('/website_chat/session',{method:'POST',credentials:'same-origin',cache:'no-store',headers:headers()});
                if(!r.ok)throw new Error(await r.text());
                var state=await r.json();token=state.token;expiresAt=state.expires_at;idleSeconds=state.idle_seconds;
                identity(state.authenticated);lastTouch=Date.now();cache();armExpiry();
                if(oldToken && oldToken!==token){$messages.empty();conversation=null;ready=false;}
                return oldToken!==token;
            })();
            try{return await sessionPromise;}finally{sessionPromise=null;}
        }
        function touch() {
            if(!token || busy || Date.now()-lastTouch<60000)return;
            bootstrap().then(function(changed){if(changed)restore();}).catch(function(){/* El siguiente envio comprobara la sesion. */});
        }
        var debugRecords = [];
        var debugEnabled = false;
        function diagnostic(values) {
            var safe = {};
            var allowed = ['request_message_count', 'published_metadata_visible', 'requested_model_id', 'profile_base_model_id', 'base_model_visible', 'profile_knowledge_count',
                'published_knowledge_count', 'published_builtin_tools_enabled', 'published_knowledge_tools_enabled',
                'effective_prompt_verified', 'effective_tools_verified', 'revision', 'request', 'phase', 'profile_read', 'profile_prompt_present',
                'configured_model_matches_profile', 'profile_is_preset', 'profile_parameters_visibility',
                'credential_kind', 'poll_interval_ms', 'snapshots_received', 'progressive_updates',
                'updates_before_done', 'transport_stage', 'http_status', 'exception_type',
                'profile_parameters', 'parameter_overrides', 'system_messages_added', 'user_message_changed',
                'engine_effective_parameters', 'transport', 'elapsed_ms', 'first_text_ms', 'live_text_updates',
                'events_received', 'knowledge_calls', 'file_reads', 'tool_results', 'saved', 'code',
                'network_chunks', 'browser_first_text_ms', 'browser_elapsed_ms', 'messages_restored', 'pending'];
            allowed.forEach(function (key) { if (Object.prototype.hasOwnProperty.call(values, key)) safe[key] = values[key]; });
            if (debugRecords.length >= 60) debugRecords.shift();
            debugRecords.push(safe);
            if (debugEnabled && window.console && console.info) console.info('[SlimAIA]', JSON.stringify(safe));
        }
        window.SlimAIADebug = {
            snapshot: function () { return JSON.parse(JSON.stringify(debugRecords)); },
            clear: function () { debugRecords.length = 0; },
            setEnabled: function (value) { debugEnabled = Boolean(value); }
        };
        diagnostic({revision: PROTOCOL, phase: 'widget_loaded'});
        function render($target, text) {
            if (typeof marked === 'undefined' || !marked.parse) {
                $target.text(text).css('white-space', 'pre-wrap');
                return;
            }
            var template = document.createElement('template');
            template.innerHTML = marked.parse(text);
            var allowed = ['P', 'BR', 'STRONG', 'EM', 'B', 'I', 'UL', 'OL', 'LI', 'BLOCKQUOTE',
                'PRE', 'CODE', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'TABLE', 'THEAD', 'TBODY', 'TR', 'TH', 'TD', 'HR', 'A'];
            function clean(node, parent) {
                if (node.nodeType === 3) {
                    parent.appendChild(document.createTextNode(node.textContent));
                    return;
                }
                if (node.nodeType !== 1) return;
                if (['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'SVG', 'MATH', 'FORM', 'IMG'].indexOf(node.tagName) !== -1) return;
                var destination = parent;
                if (allowed.indexOf(node.tagName) !== -1) {
                    destination = document.createElement(node.tagName.toLowerCase());
                    if (node.tagName === 'A') {
                        var href = node.getAttribute('href') || '';
                        try {
                            var url = new URL(href, window.location.href);
                            if (['http:', 'https:', 'mailto:'].indexOf(url.protocol) !== -1) {
                                destination.setAttribute('href', url.href);
                                destination.setAttribute('rel', 'noopener noreferrer');
                            }
                        } catch (ignore) { /* enlace invalido: conservar solo el texto */ }
                    }
                    parent.appendChild(destination);
                }
                Array.prototype.forEach.call(node.childNodes, function (child) { clean(child, destination); });
            }
            var fragment = document.createDocumentFragment();
            Array.prototype.forEach.call(template.content.childNodes, function (node) { clean(node, fragment); });
            $target.empty().append(fragment);
        }

        function bubble(text, role) {
            var $element=$('<div>').addClass('ow-msg '+(role==='user'?'ow-msg-user':'ow-msg-bot'));
            if(role==='user')$element.text(text);else render($element,text);
            $messages.append($element);scroll();return $element;
        }
        // Parsear Markdown una vez por bloque, nunca una vez por caracter.
        // Cada frame cambia solo nodos de texto ya saneados (maximo 20 FPS).
        function reveal($target) {
            var nodes=[],total=0,shown=0,frame=null,lastFrame=0,raw='',resolveFinish=null;
            var reduced=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            function draw(limit) {
                var remaining=limit;
                nodes.forEach(function(entry){var n=Math.max(0,Math.min(entry.parts.length,remaining));entry.node.nodeValue=entry.parts.slice(0,n).join('');remaining-=n;});
                scroll();
            }
            function complete() {
                if(frame!==null)window.cancelAnimationFrame(frame);frame=null;
                shown=total;draw(total);if(resolveFinish){var resolve=resolveFinish;resolveFinish=null;resolve();}
            }
            function tick(now) {
                if(document.hidden || $modal.hasClass('ow-hidden') || reduced || total>30000){complete();return;}
                if(now-lastFrame>=50){
                    var dt=lastFrame ? Math.min(100,now-lastFrame) : 50;lastFrame=now;
                    shown=Math.min(total,shown+Math.max(8,Math.ceil((total-shown)*dt/110),Math.ceil(600*dt/1000)));
                    draw(shown);
                }
                if(shown<total)frame=window.requestAnimationFrame(tick);else complete();
            }
            return {
                update:function(text){
                    var keep=text.indexOf(raw)===0?shown:0;raw=text;
                    if(frame!==null)window.cancelAnimationFrame(frame);frame=null;
                    render($target,text);nodes=[];total=0;
                    var walker=document.createTreeWalker($target[0],4,null,false),node;
                    while((node=walker.nextNode())){var parts=Array.from(node.nodeValue);nodes.push({node:node,parts:parts});total+=parts.length;}
                    shown=Math.min(keep,total);lastFrame=0;
                    if(reduced || document.hidden || $modal.hasClass('ow-hidden') || total>30000){complete();return;}
                    draw(shown);frame=window.requestAnimationFrame(tick);
                },
                finish:function(){return new Promise(function(resolve){if(shown>=total)resolve();else resolveFinish=resolve;});},
                cancel:function(){if(frame!==null)window.cancelAnimationFrame(frame);frame=null;if(resolveFinish){resolveFinish();resolveFinish=null;}}
            };
        }
        async function restore(silent) {
            var sequence=++restoreSequence, selectedAgent=agent;
            window.clearTimeout(pendingTimer);ready=false;controls();
            if(!token){expire();return;}
            if(!agents[agent]){$messages.empty();$notice.text(tr('Soporte todavía no está disponible. Puedes hablar con Ventas.','Support is not available yet. You can talk to Sales.'));return;}
            $notice.text(tr('Recuperando conversación…','Restoring conversation…'));
            try {
                var response=await fetch('/website_chat/state?agent='+encodeURIComponent(selectedAgent),{credentials:'same-origin',cache:'no-store',headers:headers()});
                if(sequence!==restoreSequence)return;
                if(response.status===409){expire();return;}
                if(!response.ok)throw new Error(await response.text());
                var state=await response.json();if(sequence!==restoreSequence)return;
                if(state.revision!==PROTOCOL)throw new Error(tr('Actualiza el módulo y recarga: las versiones no coinciden.','Update the module and reload: versions do not match.'));
                if(!Array.isArray(state.messages))throw new Error('Invalid chat state');
                conversation=state.conversation_id;expiresAt=state.expires_at;idleSeconds=state.idle_seconds;identity(state.authenticated);
                $messages.empty();state.messages.forEach(function(message){bubble(message.error?publicError(message.content):message.content,message.role);});
                if(silent!==true)diagnostic({phase:'history_restored',messages_restored:state.messages.length,pending:state.pending});
                cache();armExpiry();
                if(state.pending){$notice.text(tr('SlimAIA está pensando…','SlimAIA is thinking…'));pendingTimer=window.setTimeout(function(){if(sequence===restoreSequence)restore(true);},5000);return;}
                ready=true;$notice.text(state.association_pending?tr('Tu cuenta está iniciada. La vinculación del chat está pendiente.','You are signed in. Linking your chat is still pending.'):(state.messages.length?'':tr('Escribe tu consulta para empezar.','Type your question to get started.')));
            } catch(error) {
                if(sequence!==restoreSequence)return;
                $notice.empty().text(publicError(error.message)).append($('<button type="button" class="ow-retry">').text(tr('Reintentar','Retry')).on('click',function(){restore();}));
            } finally {if(sequence===restoreSequence)controls();}
        }
        async function send() {
            var text=$('#ow-chat-input').val();if(!text.trim() || busy || !ready)return;
            if(Date.now()>=expiresAt*1000){expire();return;}
            busy=true;controls();$('#ow-chat-input').val('');bubble(text,'user');
            var $answer=bubble(tr('SlimAIA está pensando…','SlimAIA is thinking…'),'assistant');
            var answer='',complete=false,reader,started=performance.now(),firstText=null,chunks=0;
            animation=reveal($answer);diagnostic({phase:'request_started'});$notice.empty();
            try {
                var form=new FormData();form.append('message',text);form.append('agent',agent);form.append('conversation_id',conversation);form.append('protocol',PROTOCOL);
                var response=await fetch('/website_chat/stream_message',{method:'POST',body:form,credentials:'same-origin',cache:'no-store',headers:headers()});
                if(!response.ok)throw new Error(await response.text());
                if(response.headers.get('X-OpenWebUI-Protocol')!==PROTOCOL)throw new Error(tr('Actualiza el controlador y recarga la web.','Update the controller and reload the website.'));
                if(!response.body)throw new Error(tr('El navegador no permite leer la respuesta progresiva.','Your browser cannot read the progressive response.'));
                reader=response.body.getReader();var decoder=new TextDecoder('utf-8'),buffer='';
                function process(line){
                    if(!line.trim())return;var event=JSON.parse(line);
                    if(event.type==='diagnostic'){diagnostic(event);return;}
                    if(event.type==='heartbeat')return;
                    if(event.type==='error')throw new Error(event.text);
                    if(event.type==='status'&&!answer)$answer.text(tr('SlimAIA está pensando…','SlimAIA is thinking…'));
                    if(event.type==='delta'||event.type==='replace'){
                        if(firstText===null&&event.text)firstText=Math.round(performance.now()-started);
                        answer=event.type==='replace'?event.text:answer+event.text;animation.update(answer);
                    }
                    if(event.type==='done'){complete=true;if(!event.saved)$notice.text(tr('No se pudo guardar la respuesta.','The response could not be saved.'));}
                }
                while(true){var part=await reader.read();if(!part.done)chunks++;buffer+=decoder.decode(part.value||new Uint8Array(),{stream:!part.done});var newline;
                    while((newline=buffer.indexOf('\n'))!==-1){process(buffer.slice(0,newline));buffer=buffer.slice(newline+1);}if(part.done)break;}
                if(buffer.trim())process(buffer);if(!complete)throw new Error(tr('La respuesta se interrumpió antes de terminar. Recarga para recuperar su estado.','The response was interrupted. Reload to recover its state.'));
                await animation.finish();diagnostic({phase:'browser_completed',network_chunks:chunks,browser_first_text_ms:firstText,browser_elapsed_ms:Math.round(performance.now()-started)});
                // Una peticion al terminar renueva la caducidad, sin otra generacion.
                try { if(await bootstrap()) await restore(); } catch(ignore) { /* No sustituir una respuesta terminada por un fallo de renovacion. */ }
            } catch(error){
                if(animation)animation.cancel();if(reader){try{await reader.cancel();}catch(ignore){}}
                $answer.text(publicError(error.message));diagnostic({phase:'browser_error',code:'request_failed',network_chunks:chunks,browser_first_text_ms:firstText,browser_elapsed_ms:Math.round(performance.now()-started)});
            } finally {animation=null;busy=false;controls();$('#ow-chat-input').focus();scroll();armExpiry();}
        }
        async function resetChat(){
            if(busy)return;
            var oldHeaders=headers();++restoreSequence;ready=false;conversation=null;
            window.clearTimeout(pendingTimer);window.clearTimeout(expiryTimer);
            $messages.empty();$('#ow-chat-input').val('');token=null;expiresAt=0;cache();controls();
            $notice.text(tr('Iniciando una conversación nueva…','Starting a new conversation…'));
            try {await fetch('/website_chat/end',{method:'POST',credentials:'same-origin',cache:'no-store',headers:oldHeaders});await bootstrap();await restore();}
            catch(error){showSessionError(error);}
        }
        $reset.on('click',resetChat);
        $selector.on('change',function(){if(busy){$selector.val(agent);return;}agent=$selector.val();$messages.empty();$('#ow-chat-input').val('');cache();restore();});
        $login.on('click',function(event){if(busy){event.preventDefault();return;}openPreference='1';cache();});
        $('#openwebui-chat-button, #ow-chat-close').on('click',function(event){event.preventDefault();$modal.toggleClass('ow-hidden');openPreference=$modal.hasClass('ow-hidden')?'0':'1';cache();$launcher.attr('aria-expanded',openPreference==='1'?'true':'false');if(openPreference==='1'&&token){if(Date.now()>=expiresAt*1000)expire();else touch();}});
        $launcher.on('keydown',function(event){if(event.key==='Enter'||event.key===' '){event.preventDefault();$(this).trigger('click');}});
        $('#ow-chat-input').on('keydown',function(event){if((event.key==='Enter'||event.keyCode===13)&&!event.shiftKey){event.preventDefault();send();}}).on('input',touch);
        $('#ow-chat-send').on('click',function(event){event.preventDefault();send();});
        // No conservar mensajes en una captura de pagina restaurable (bfcache).
        window.addEventListener('pagehide',function(){$messages.empty();$('#ow-chat-input').val('');});
        window.addEventListener('pageshow',function(event){if(event.persisted)restore(true);});
        window.addEventListener('focus',function(){if(token&&Date.now()-lastFocus>5000){lastFocus=Date.now();$messages.empty();restore(true);}});
        controls();
        fetch('/website_chat/agents',{credentials:'same-origin',cache:'no-store'})
            .then(function(response){if(!response.ok)throw new Error('Chat unavailable');return response.json();})
            .then(async function(available){agents=available;await bootstrap();await restore();})
            .catch(showSessionError);
    });
});
