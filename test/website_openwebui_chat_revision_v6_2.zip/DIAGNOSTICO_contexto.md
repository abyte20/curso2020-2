# Análisis del límite de contexto

El export confirma la causa del bloqueo: el motor rechazó 40.515 tokens con una capacidad disponible de 32.768. Esta es la capacidad efectiva de esa petición; no basta con el contexto máximo anunciado por el modelo o un valor global de configuración.

## Evidencia de la conversación

| Dato | Observado |
| --- | --- |
| Preguntas y respuestas visibles antes del primer fallo | Aproximadamente 16.650 caracteres |
| Fichas leídas en la consulta sobre Kymera | 7 |
| Contenido de esas siete lecturas | 30.078 caracteres |
| Turno siguiente, al pedir repetir la respuesta | Otras 7 llamadas a las mismas fichas |
| IDs de las llamadas repetidas | Nuevos, distintos de los anteriores |
| Contenido devuelto | Coincide con las siete fichas anteriores |
| Entrada de la primera llamada del turno que acaba fallando | 30.022 tokens según usage |
| Petición posterior tras recuperar las fichas | 40.515 tokens; rechazada |
| Límite comunicado por el motor | 32.768 tokens |

Caracteres y tokens son medidas diferentes. No se han estimado los tokens dividiendo caracteres: las cifras de tokens proceden de los errores o del campo de uso del export.

Hay resultados de herramientas guardados que no se ven como texto corriente del chat. En todo el export suman aproximadamente 90.364 caracteres de contenido, incluyendo lecturas anteriores y la repetición. La integración conserva esos resultados en Open WebUI; su flujo nativo reconstruye el contexto a partir del chat guardado.

No se aprecia una duplicación accidental de los mensajes por el widget: el turno que pide repetir contiene nuevas llamadas del modelo a las herramientas. Eso no elimina nuestra responsabilidad de acordar una política de contexto adecuada para conversaciones prolongadas: actualmente se conserva el historial y sus resultados.

Los siguientes intentos fallan con 40.529, 40.536, 40.543 y 40.550 tokens. Recargar no elimina las fichas ya guardadas; una conversación nueva comienza con un contexto distinto y por eso vuelve a funcionar.

Algunos campos `usage.input_tokens` de turnos con herramientas suman varias llamadas. No deben compararse como si siempre fueran el tamaño de una sola petición. El error explícito del motor sí da el tamaño rechazado.

## Qué se ha cambiado en v6.2

Solo se reconoce el error para mostrar un aviso útil y guardar una causa técnica concreta sin volcar contenido privado. No hay recorte, borrado, resumen o reintento automático; no se modifica el prompt.

## Opciones para decidir juntos

1. Revisar el contexto efectivo por secuencia/slot en llama.cpp y la concurrencia. Ampliarlo puede dar margen, pero requiere comprobar memoria y configuración reales; tampoco evita el crecimiento indefinido del historial.
2. Definir una política para conversaciones largas: resumen o retención acotada de resultados antiguos, preservando preferencias, preguntas recientes y las parejas de llamada/resultado. Sería un cambio funcional y queda pendiente de acuerdo.
3. Revisar por qué el perfil vuelve a consultar documentos al pedir repetir una respuesta. Una instrucción de reutilización puede ayudar, pero no garantiza por sí sola que el contexto nunca se desborde.

No hace falta cambiar la temperatura para corregir este límite. El mensaje de error no justifica atribuirlo a Cloudflare o al efecto visual.
