import sys
import types
import importlib.util
import unittest
from pathlib import Path
from lxml import etree

BASE = Path(__file__).parent
class Parent:
    def get_values(self): return {}
    def _get_classified_fields(self):
        return {'config':[('openwebui_active',module.TuxAIASettings.openwebui_active.config_parameter),('unrelated','another.module')], 'other':[]}
    def set_values(self):
        if any(name=='openwebui_active' for name,key in self._get_classified_fields()['config']):
            self.env.params.set_param('website_openwebui_chat.openwebui_active', self.openwebui_active)
    def ensure_one(self): pass
    def fields_view_get(self, **kw):
        return {'arch': self.arch, 'fields': {'unchanged': True}}
odoo = types.ModuleType('odoo')
odoo.models = types.SimpleNamespace(TransientModel=Parent)
odoo.fields = types.SimpleNamespace(Char=lambda **kw: types.SimpleNamespace(**kw), Boolean=lambda **kw: types.SimpleNamespace(**kw), Integer=lambda **kw: types.SimpleNamespace(**kw))
odoo._ = lambda s: s
odoo.api = types.SimpleNamespace(model=lambda f:f)
exc = types.ModuleType('odoo.exceptions'); exc.AccessError = type('AccessError',(Exception,),{}); exc.ValidationError = type('ValidationError',(Exception,),{})
sys.modules['odoo'] = odoo; sys.modules['odoo.exceptions'] = exc
spec=importlib.util.spec_from_file_location('settings', BASE/'slimaia_settings.py'); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

class SettingsTests(unittest.TestCase):
    def configured(self):
        class Params:
            def __init__(self): self.data={}
            def sudo(self):return self
            def get_param(self,key,default=None):return self.data.get(key) or default
            def set_param(self,key,value):
                if value is False or value is None:self.data.pop(key,None)
                else:self.data[key]=str(value)
        class Env:
            def __init__(self):self.params=Params();self.user=types.SimpleNamespace(has_group=lambda x:True)
            def __getitem__(self,key):return self.params
        obj=module.TuxAIASettings();obj.env=Env()
        obj.openwebui_active=True;obj.openwebui_url='https://ai.test'
        obj.tuxaia_cf_client_id='test.access';obj.tuxaia_cf_client_secret='secret-sentinel'
        obj.slimaia_debug_path='/tmp/test.log';obj.slimaia_idle_minutes=15
        obj.tuxaia_project_url='';obj.slimaia_sales_model_id='sales';obj.slimaia_support_model_id='support'
        obj.slimaia_debug_logging=False;obj.slimaia_debug_prompt=False
        return obj

    def test_activation_false_survives_both_save_screens(self):
        obj=self.configured()
        self.assertEqual(obj._get_classified_fields()['config'],[('unrelated','another.module')])
        self.assertIn('openwebui_active',obj._get_classified_fields()['other'])
        self.assertTrue(obj.get_values()['openwebui_active'])
        for save in [obj.set_values,obj.action_slimaia_save]:
            for active in [False,True,False]:
                obj.openwebui_active=active;save()
                self.assertEqual(obj.get_values()['openwebui_active'],active)
                self.assertEqual(obj.env.params.data['website_openwebui_chat.openwebui_active'],str(active))
        self.assertFalse(obj.get_values()['slimaia_debug_logging'])
        self.assertFalse(obj.get_values()['slimaia_debug_prompt'])

    def test_cloudflare_pair_https_and_admin_only_fields(self):
        obj=self.configured();obj.action_slimaia_save()
        self.assertEqual(obj.env.params.data['website_openwebui_chat.cf_client_secret'],'secret-sentinel')
        self.assertEqual(module.TuxAIASettings.tuxaia_cf_client_secret.groups,'base.group_system')
        for url,client,secret in [('http://ai.test','test.access','secret'),('https://ai.test','test.access',''),('https://ai.test','test.access','bad\nheader')]:
            obj.openwebui_url=url;obj.tuxaia_cf_client_id=client;obj.tuxaia_cf_client_secret=secret
            with self.assertRaises(exc.ValidationError):obj.action_slimaia_save()
        obj.tuxaia_cf_client_id='';obj.tuxaia_cf_client_secret='';obj.action_slimaia_save()
        self.assertEqual(obj.env.params.data['website_openwebui_chat.cf_client_secret'],'')

    def test_old_view_clarifies_fallback_hides_only_obsolete_prompt(self):
        obj=module.TuxAIASettings()
        obj._fields={name:types.SimpleNamespace(config_parameter=param) for name,param in {
            'old_model':'website_openwebui_chat.openwebui_model',
            'old_prompt':'website_openwebui_chat.sales_system_prompt',
            'debug_prompt':'website_openwebui_chat.debug_prompt',
            'another_prompt':'other_module.prompt',
        }.items()}
        obj.arch='<form><group><label for="old_model"/><field name="old_model"/><label for="old_prompt"/><field name="old_prompt" modifiers="{}"/><field name="debug_prompt"/><field name="another_prompt"/></group></form>'
        result=obj.fields_view_get();root=etree.fromstring(result['arch'])
        self.assertEqual(root.xpath('//field[@name="old_model"]')[0].get('string'),'Modelo de Ventas (respaldo)')
        self.assertIn('menu superior TuxAIA',root.xpath('//div')[0].text)
        for node in root.xpath('//*[@name="old_prompt" or @for="old_prompt"]'):
            self.assertEqual(node.get('invisible'),'1');self.assertIn('true',node.get('modifiers'))
        for name in ['debug_prompt','another_prompt']:
            self.assertIsNone(root.xpath('//field[@name="%s"]'%name)[0].get('invisible'))
        self.assertEqual(result['fields'],{'unchanged':True})
        self.assertEqual(obj.fields_view_get(view_type='tree')['arch'],obj.arch)

    def test_dedicated_view_is_not_changed(self):
        obj=module.TuxAIASettings();obj._fields={'sales':types.SimpleNamespace(config_parameter='website_openwebui_chat.openwebui_sales_model')}
        obj.arch='<form><field name="sales"/></form>'
        self.assertEqual(obj.fields_view_get()['arch'],obj.arch)

if __name__=='__main__':unittest.main(verbosity=2)
