import ast
import subprocess
import tempfile
from pathlib import Path
import unittest

PACKAGE = Path(__file__).resolve().parent


class InstallerTests(unittest.TestCase):
    def test_preserves_manifest_authors_and_existing_files_and_is_idempotent(self):
        with tempfile.TemporaryDirectory(prefix='slimaia_test_', dir='/tmp') as folder:
            root = Path(folder)/'addon'
            (root/'controllers').mkdir(parents=True)
            (root/'static/src/js').mkdir(parents=True)
            (root/'views').mkdir()
            (root/'views/templates.xml').write_text('<odoo><div id="ow-chat-messages">SlimAIA / SlimAI</div></odoo>')
            manifest = "# Existing author comment\n{'name':'Existing name','author':'Original Author','depends':['website'], 'data': [\n 'views/templates.xml'\n]}\n"
            (root/'__manifest__.py').write_text(manifest)
            (root/'__init__.py').write_text('from . import controllers\n')
            (root/'controllers/main.py').write_text('# old controller\n')
            (root/'static/src/js/chat_widget.js').write_text('// old widget\n')
            command = ['python3', str(PACKAGE/'instalar.py'), str(root)]
            first = subprocess.run(command, check=True, text=True, capture_output=True)
            backup = Path(first.stdout.split('Copia privada: ')[1].splitlines()[0])
            self.assertEqual((backup/'__manifest__.py').read_text(), manifest)
            updated = (root/'__manifest__.py').read_text()
            self.assertEqual(updated.replace("'views/slimaia_settings.xml', ", ''), manifest)
            values = ast.literal_eval(updated)
            self.assertEqual(values['author'], 'Original Author')
            self.assertEqual(values['data'], ['views/slimaia_settings.xml','views/templates.xml'])
            self.assertTrue((root/'static/src/img/agent_icon.png').is_file())
            self.assertEqual((root/'views/templates.xml').read_text(),'<odoo><div id="ow-chat-messages">TuxAIA / TuxAIA</div></odoo>')
            self.assertIn('SlimAIA',(backup/'views/templates.xml').read_text())
            self.assertTrue((root/'controllers/owui_websocket/__init__.py').is_file())
            subprocess.run(command, check=True, text=True, capture_output=True)
            self.assertEqual((root/'__manifest__.py').read_text(), updated)
            self.assertEqual((root/'__init__.py').read_text().count('from . import slimaia_settings'), 1)


if __name__ == '__main__': unittest.main(verbosity=2)
