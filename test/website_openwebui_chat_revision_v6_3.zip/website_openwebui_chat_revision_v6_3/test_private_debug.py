import importlib.util
import json
import multiprocessing
import os
from pathlib import Path
import stat
import tempfile
import types
import unittest
import test_native as native
m=native.m
from testaddon.private_debug import PrivateDebug


def worker(path,number):
    log=PrivateDebug(path,lambda:True,max_bytes=2048,backups=2)
    for i in range(40): log.write({'phase':'worker','request':'%s-%s'%(number,i)})


class DebugTests(unittest.TestCase):
    def test_disabled_rotation_permissions_and_unexpected_fields(self):
        with tempfile.TemporaryDirectory() as folder:
            path=str(Path(folder)/'debug.log');enabled=[False]
            log=PrivateDebug(path,lambda:enabled[0],max_bytes=512,backups=2)
            self.assertFalse(log.write({'phase':'test'}));self.assertFalse(os.path.exists(path))
            enabled[0]=True
            for i in range(40):self.assertTrue(log.write({'phase':'test','request':str(i),'api_key':'SECRET_KEY','messages':['PRIVATE_CUSTOMER']}))
            files=list(Path(folder).glob('debug.log*'))
            self.assertLessEqual(len(files),4)
            for file in files:
                self.assertEqual(stat.S_IMODE(file.stat().st_mode),0o600)
                text=file.read_text();self.assertNotIn('SECRET_KEY',text);self.assertNotIn('PRIVATE_CUSTOMER',text)
                if file.suffix!='.lock':
                    self.assertLessEqual(file.stat().st_size,512)
                    for line in text.splitlines():json.loads(line)
            size=os.stat(path).st_size;enabled[0]=False;self.assertFalse(log.write({'phase':'stopped'}));self.assertEqual(os.stat(path).st_size,size)

    def test_multiple_workers_do_not_corrupt_rotation(self):
        with tempfile.TemporaryDirectory() as folder:
            path=str(Path(folder)/'debug.log')
            workers=[multiprocessing.Process(target=worker,args=(path,n)) for n in range(4)]
            for p in workers:p.start()
            for p in workers:p.join(5);self.assertEqual(p.exitcode,0)
            for file in Path(folder).glob('debug.log*'):
                if file.suffix=='.lock':continue
                self.assertLessEqual(file.stat().st_size,2048)
                for line in file.read_text().splitlines():self.assertEqual(json.loads(line)['phase'],'worker')

    def test_symlink_refused(self):
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'target';target.write_text('untouched')
            path=Path(folder)/'debug.log';path.symlink_to(target)
            self.assertFalse(PrivateDebug(str(path),lambda:True).write({'phase':'test'}))
            self.assertEqual(target.read_text(),'untouched')

    def test_profile_snapshot_private_only_once_and_stop_during_turn(self):
        with tempfile.TemporaryDirectory() as folder:
            config=native.Config('http://test');path=str(Path(folder)/'debug.log')
            config.values.update({'website_openwebui_chat.debug_logging':'True','website_openwebui_chat.debug_prompt':'True','website_openwebui_chat.debug_log_path':path})
            env=native.Env('http://test');env.config=config;env.cr=types.SimpleNamespace(dbname='test_db')
            m.request=types.SimpleNamespace(env=env,session={})
            class Cursor:
                def __enter__(self):return self
                def __exit__(self,*args):pass
                def execute(self,*args):pass
                def fetchone(self):return (config.values['website_openwebui_chat.debug_logging'],)
            native.odoo.registry=lambda db:types.SimpleNamespace(cursor=lambda:Cursor())
            client=m.OpenWebUIClient('https://test','SECRET_CREDENTIAL','sales',cf_client_id='CLIENT_SENTINEL.access',cf_client_secret='CF_SECRET_SENTINEL')
            ctx={'trace':'trace','chat_id':'PRIVATE_CHAT_ID','profile':{'id':'sales','base_model_id':'base','write_access':True,'params':{'system':'PRIVATE_PROFILE SECRET_CREDENTIAL CLIENT_SENTINEL.access CF_SECRET_SENTINEL','temperature':.4},'meta':{}},'messages':[{'role':'user','content':'PRIVATE_CUSTOMER'}], 'chat':{'history':{'messages':{'a':{'output':[{'type':'function_call_output','content':'PRIVATE_DOCUMENT'}]}}}}}
            tab={'key':'test','agents':{}};active={};controller=m.OpenWebUIChatController()
            logger=controller._private_debug(client,ctx,'sales',active,tab)
            controller._private_debug(client,ctx,'sales',active,tab)
            text=Path(path).read_text();records=[json.loads(line) for line in text.splitlines()]
            self.assertEqual(sum(r['phase']=='profile_snapshot' for r in records),1)
            self.assertIn('PRIVATE_PROFILE',text)
            for secret in ('SECRET_CREDENTIAL','CLIENT_SENTINEL.access','CF_SECRET_SENTINEL','PRIVATE_CHAT_ID','PRIVATE_CUSTOMER','PRIVATE_DOCUMENT'):self.assertNotIn(secret,text)
            self.assertEqual(records[0]['engine_effective_parameters'],'not_reported_by_api')
            self.assertEqual(records[0]['profile_parameters']['temperature'],.4)
            # El cursor/env original ya no esta disponible al consumir el stream.
            m.request=None;config.values['website_openwebui_chat.debug_logging']='False'
            size=Path(path).stat().st_size;self.assertFalse(logger.write({'phase':'completed'}));self.assertEqual(Path(path).stat().st_size,size)


if __name__=='__main__':unittest.main(verbosity=2)
