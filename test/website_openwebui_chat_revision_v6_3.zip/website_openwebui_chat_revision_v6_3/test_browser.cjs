const {chromium}=require('playwright'),fs=require('fs'),assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.TUXAIA_TEST_CHROMIUM,headless:true,args:['--no-sandbox']});
 const markedPath=require.resolve('marked');
 const html=lang=>`<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>
 .ow-chat-header i{display:none!important}.ow-thinking span{display:none!important}body{margin:0;background:#eef2f6;font-family:Arial,sans-serif}*{box-sizing:border-box}
 @font-face{font-family:FontAwesome;src:url('/font.woff2')}.fa{font-family:FontAwesome;font-style:normal}.fa-linux:before{content:'\\f17c'}.fa-paper-plane:before{content:'\\f1d8'}
 </style></head><body><div id="openwebui-chat-button"></div><div id="openwebui-chat-modal" class="ow-chat-modal ow-hidden"><div class="ow-chat-header"><span></span><button id="ow-chat-close" class="ow-close-btn">&times;</button></div><div id="ow-chat-messages" class="ow-chat-body"></div><div class="ow-chat-footer"><input id="ow-chat-input"><button id="ow-chat-send"><i class="fa fa-paper-plane"></i></button></div></div></body></html>`;
 let page;const errors=[];
 async function load(lang,width,height){
  page=await browser.newPage({viewport:{width,height}});page.on('pageerror',e=>errors.push(e.message));
  let requests=[];
  await page.route('https://odoo.test/**',async route=>{
   const url=new URL(route.request().url());
   if(url.pathname==='/font.woff2')return route.fulfill({contentType:'font/woff2',body:fs.readFileSync('/tmp/slimaia-font.woff2')});
   if(url.pathname.endsWith('agent_icon.png'))return route.fulfill({contentType:'image/png',body:fs.readFileSync(__dirname+'/agent_icon.png')});
   if(url.pathname==='/website_chat/agents')return route.fulfill({json:{active:true,sales:true,support:true,project_url:'https://tuxaia.com'}});
   if(url.pathname==='/website_chat/session')return route.fulfill({json:{token:'b'.repeat(64),authenticated:false,idle_seconds:900,expires_at:Date.now()/1000+900}});
   if(url.pathname==='/website_chat/state'){
    requests.push(url.searchParams.get('agent'));
    const messages=url.searchParams.get('agent')==='sales'?[{role:'user',content:lang==='es'?'Hola, necesito ayuda para elegir un portátil.':'Hello, I need help choosing a laptop.'},{role:'assistant',content:lang==='es'?'¿Para qué lo utilizarás principalmente?':'What will you mainly use it for?'}]:[];
    return route.fulfill({json:{revision:'native-profile-v6',conversation_id:'test-'+url.searchParams.get('agent'),pending:false,authenticated:false,idle_seconds:900,expires_at:Date.now()/1000+900,messages}});
   }
   return route.fulfill({contentType:'text/html',body:html(lang)});
  });
  await page.goto('https://odoo.test/');await page.addStyleTag({path:__dirname+'/chat_widget.css'});await page.addScriptTag({path:'/tmp/odoo13-jquery.js'});await page.addScriptTag({path:markedPath.replace(/lib\/marked\.(cjs|esm.js)$/, 'lib/marked.umd.js')});
  await page.evaluate(()=>{window.odoo={define:(name,factory)=>factory(()=>{})};});await page.addScriptTag({path:__dirname+'/chat_widget.js'});
  await page.waitForFunction(()=>window.TuxAIADebug&&!document.getElementById('ow-chat-send').disabled);
  await page.locator('#openwebui-chat-button').click();await page.evaluate(()=>document.fonts.ready);
  assert.notEqual(await page.locator('.ow-header-penguin').evaluate(e=>getComputedStyle(e).display),'none');
  assert((await page.locator('.ow-header-penguin').boundingBox()).width>0);
  assert.equal(await page.locator('.ow-header-penguin').evaluate(e=>getComputedStyle(e).color),'rgb(255, 255, 255)');
  assert.equal(await page.locator('.ow-chat-header').evaluate(e=>getComputedStyle(e).backgroundColor),'rgb(0, 86, 179)');
  assert.equal(await page.locator('#ow-chat-send').evaluate(e=>getComputedStyle(e).backgroundColor),'rgb(0, 86, 179)');
  assert.equal(await page.locator('.ow-msg-user').evaluate(e=>getComputedStyle(e).backgroundColor),'rgb(57, 132, 198)');
  const bounds=await page.locator('#openwebui-chat-modal').boundingBox();assert(bounds.x>=0&&bounds.x+bounds.width<=width);assert(bounds.y>=0&&bounds.y+bounds.height<=height);
  for(const selector of ['.ow-account-column','.ow-chat-footer','.ow-agent-bar','.ow-disclaimer']){
   assert(await page.locator(selector).evaluate(e=>e.scrollWidth<=e.clientWidth+1),selector+' overflow');
  }
  await page.locator('#openwebui-chat-modal').screenshot({path:__dirname+'/interfaz_'+lang+(width<500?'_movil':'')+'.png'});
  await page.locator('#ow-chat-agent').selectOption('support');await page.waitForFunction(()=>!document.getElementById('ow-chat-send').disabled&&document.querySelectorAll('.ow-msg').length===0);
  assert.deepEqual(requests,['sales','support']);
  // Una respuesta controlada entrega fragmentos con un segundo de separacion.
  await page.evaluate(()=>{
   const originalFetch=window.fetch;window.streamCalls=0;
   window.fetch=(url,options)=>{
    if(url!=='/website_chat/stream_message')return originalFetch(url,options);
    window.streamCalls++;window.sentText=options.body.get('message');
    return Promise.resolve(new Response(new ReadableStream({start(c){window.streamController=c;}}),{headers:{'X-OpenWebUI-Protocol':'native-profile-v6'}}));
   };
   window.emit=event=>window.streamController.enqueue(new TextEncoder().encode(JSON.stringify(event)+'\n'));
  });
  const firstLine=lang==='es'?'Consulta de prueba':'Test question';
  await page.locator('#ow-chat-input').fill(firstLine);
  await page.locator('#ow-chat-input').press('Shift+Enter');
  await page.locator('#ow-chat-input').pressSequentially('CPU y bateria');
  assert.equal(await page.evaluate(()=>window.streamCalls),0);
  assert.equal(await page.locator('#ow-chat-input').inputValue(),firstLine+'\nCPU y bateria');
  await page.locator('#ow-chat-input').press('Enter');
  await page.waitForFunction(()=>window.streamController);
  assert.equal(await page.evaluate(()=>window.sentText),firstLine+'\nCPU y bateria');
  assert.equal(await page.locator('.ow-msg-user').last().evaluate(e=>getComputedStyle(e).whiteSpace),'pre-wrap');
  assert.equal(await page.locator('.ow-thinking-dot').count(),3);
  for(const dot of await page.locator('.ow-thinking-dot').all()){const b=await dot.boundingBox();assert(b.width>=4&&b.height>=4);}
  assert.equal(await page.locator('.ow-powered a').getAttribute('href'),'https://tuxaia.com/');
  assert.equal(await page.locator('.ow-header-title strong').innerText(),'TuxAIA');
  assert.equal(await page.locator('.ow-thinking-dot').first().evaluate(e=>getComputedStyle(e).animationName),'ow-thinking-pulse');
  await page.locator('#openwebui-chat-modal').screenshot({path:__dirname+'/pensando_'+lang+'.png'});
  await page.evaluate(()=>window.emit({type:'delta',text:'Primer párrafo **estable**.\n\nSegundo párrafo'}));
  await page.waitForFunction(()=>document.querySelector('.ow-msg-bot')?.textContent.includes('Segundo'));
  assert.equal(await page.locator('.ow-thinking-dot').count(),0);
  assert.equal(await page.locator('#ow-chat-send').isDisabled(),true,'Debe mostrarse antes de finalizar');
  await page.waitForTimeout(1000);
  await page.evaluate(()=>{window.stableParagraph=document.querySelector('.ow-msg-bot p');window.emit({type:'delta',text:' con texto nuevo y un [enlace](https://slimbook.com).\n\n- Uno\n- Dos'});});
  await page.waitForFunction(()=>document.querySelector('.ow-msg-bot')?.textContent.includes('Dos'));
  assert(await page.evaluate(()=>window.stableParagraph===document.querySelector('.ow-msg-bot p')),'Parrafo anterior conservado');
  assert.equal(await page.locator('.ow-msg-bot p').first().evaluate(e=>getComputedStyle(e).animationName),'none');
  // Congelar el efecto para inspeccionar clip-path y opacidad a mitad.
  const effects=await page.evaluate(()=>{
   const nodes=Array.from(document.querySelectorAll('.ow-reveal-fragment'));
   return nodes.map(n=>{const a=n.getAnimations()[0];if(a){a.pause();a.currentTime=300;}return {tag:n.tagName,clip:getComputedStyle(n).clipPath,opacity:getComputedStyle(n).opacity};});
  });
  assert(effects.length>0);
  assert.equal(await page.locator('.ow-reveal-fragment').first().evaluate(e=>getComputedStyle(e).animationDuration),'0.8s');assert(effects.some(e=>e.clip!=='none'&&Number(e.opacity)<1));
  await page.locator('#openwebui-chat-modal').screenshot({path:__dirname+'/revelado_'+lang+(width<500?'_movil':'')+'.png'});
  await page.evaluate(()=>document.querySelectorAll('.ow-reveal-fragment').forEach(n=>n.getAnimations().forEach(a=>a.play())));
  await page.waitForTimeout(850);
  assert.equal(await page.locator('.ow-reveal-fragment').count(),0);
  assert.equal(await page.locator('[data-ow-reveal-wrap]').count(),0);
  await page.emulateMedia({reducedMotion:'reduce'});
  await page.evaluate(()=>window.emit({type:'delta',text:'\n\nÚltimo texto sin animación.'}));
  await page.waitForFunction(()=>document.querySelector('.ow-msg-bot').textContent.includes('Último'));
  assert.equal(await page.locator('.ow-reveal-fragment').count(),0);
  await page.evaluate(()=>{window.emit({type:'done',saved:true});window.streamController.close();});
  await page.waitForFunction(()=>!document.getElementById('ow-chat-send').disabled);
  assert.equal(await page.evaluate(()=>window.streamCalls),1);
  await page.locator('#ow-chat-close').click();
  assert.equal(await page.locator('#openwebui-chat-button img').evaluate(i=>i.naturalWidth),128);
  await page.locator('#openwebui-chat-button').screenshot({path:__dirname+'/boton_'+lang+'.png'});
  await page.close();
 }
 await load('es',1200,900);await load('es',375,720);await load('en',375,720);
 assert.deepEqual(errors,[]);await browser.close();console.log('OK Chromium: diseño real a 375/1200px, ES/EN, colores, icono blanco, selector, launcher e imagen, stream incremental, nodos anteriores conservados, cortina CSS, puntos y movimiento reducido. API simulada.');
})().catch(e=>{console.error(e);process.exit(1)});
