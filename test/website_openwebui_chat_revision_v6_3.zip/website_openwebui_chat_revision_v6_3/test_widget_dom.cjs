const assert=require('node:assert/strict'),fs=require('fs');
const {JSDOM}=require('/tmp/ow-widget-test/node_modules/jsdom');
(async()=>{
 const {marked}=await import(require.resolve('marked'));
 const A='a'.repeat(64);let next=1,authenticated=false,expiry=900;
 const server=new Map([[A,{sales:[{role:'user',content:'Pregunta anterior'},{role:'assistant',content:'Respuesta guardada'}],support:[]}]]);
 const archive=[];let stored=JSON.stringify({token:A,agent:'sales',open:'1',expires_at:Date.now()/1000+900});
 async function wait(check){for(let i=0;i<300;i++){if(check())return;await new Promise(r=>setTimeout(r,10));}throw Error('timeout');}
 async function load(lang='es',reduce=false,active=true){
  const dom=new JSDOM('<!doctype html><html><body><div id="openwebui-chat-button"></div><div id="openwebui-chat-modal" class="ow-hidden"><div class="ow-chat-header"><span>Old</span><button id="ow-chat-close">×</button></div><div id="ow-chat-messages"></div><div class="ow-chat-footer"><input id="ow-chat-input"><button id="ow-chat-send">Send</button></div></div></body></html>',{url:'https://odoo.test/shop',runScripts:'outside-only',pretendToBeVisual:true});
  const w=dom.window;w.document.documentElement.lang=lang;w.console.info=()=>{};
  w.matchMedia=()=>({matches:reduce});w.eval(fs.readFileSync('/tmp/odoo13-jquery.js','utf8'));
  w.parseCount=0;w.marked={parse:text=>{w.parseCount++;return marked.parse(text);}};
  w.TextDecoder=TextDecoder;w.TextEncoder=TextEncoder;w.odoo={define:(name,factory)=>factory(()=>{})};w.sent=[];
  if(stored)w.sessionStorage.setItem('slimaia_session_v6',stored);
  w.sessionStorage.setItem('slimbook_chat_v5_sales',JSON.stringify({messages:['OLD_PRIVATE_CACHE']}));
  w.fetch=async(url,options={})=>{
   if(url==='/website_chat/agents')return new Response(JSON.stringify({active,sales:true,support:true,project_url:lang==='es'?'https://tuxaia.com':''}));
   assert(active,'No session or history when disabled');
   assert.equal(options.headers['X-Requested-With'],'XMLHttpRequest');
   let token=options.headers['X-SlimAIA-Session'];
   if(url==='/website_chat/session'){
    if(!server.has(token)){token=(next++).toString(16).padStart(64,'0');server.set(token,{sales:[],support:[]});}
    w.token=token;return new Response(JSON.stringify({token,authenticated,idle_seconds:900,expires_at:Date.now()/1000+expiry}));
   }
   if(url==='/website_chat/end'){if(server.has(token)){archive.push(server.get(token));server.delete(token);}return new Response('{}');}
   assert(server.has(token));
   if(url.startsWith('/website_chat/state?')){
    const agent=new URL('https://odoo.test'+url).searchParams.get('agent');
    return new Response(JSON.stringify({revision:'native-profile-v6',conversation_id:token+'-'+agent,messages:server.get(token)[agent],pending:false,authenticated,idle_seconds:900,expires_at:Date.now()/1000+expiry}));
   }
   assert.equal(url,'/website_chat/stream_message');w.sent.push(Object.fromEntries(options.body.entries()));
   return new Response(new ReadableStream({start(controller){w.controller=controller;}}),{headers:{'X-OpenWebUI-Protocol':'native-profile-v6'}});
  };
  w.currentAnswer='';
  w.frame=event=>{
   if(event.type==='delta')w.currentAnswer+=event.text;
   if(event.type==='replace')w.currentAnswer=event.text;
   if(event.type==='done'){
    const s=w.sent.at(-1);server.get(w.token)[s.agent].push({role:'user',content:s.message},{role:'assistant',content:w.currentAnswer});w.currentAnswer='';
   }
   const bytes=new TextEncoder().encode(JSON.stringify(event)+'\n');for(const b of bytes)w.controller.enqueue(new Uint8Array([b]));
  };
  w.eval(fs.readFileSync(__dirname+'/chat_widget.js','utf8'));
  if(!active){await new Promise(r=>setTimeout(r,100));return w;}
  await wait(()=>w.token&&!w.$('#ow-chat-send').prop('disabled'));
  return w;
 }
 let disabled=await load('es',false,false);assert.equal(disabled.token,undefined);assert.equal(disabled.$('.ow-enabled').length,0);disabled.close();
 let w=await load();
 assert.equal(w.$('.ow-chat-header .fa-linux').length,1);assert.equal(w.$('.ow-header-penguin').text(),'');
 assert.equal(w.$('.ow-launcher-label').text(),'Hola');assert.equal(w.$('.ow-agent-bar').prev().attr('class'),'ow-chat-footer');
 assert.equal(w.$('.ow-chat-footer').prev().attr('role'),'status');
 assert.equal(w.$('.ow-powered a').attr('href'),'https://tuxaia.com/');
 assert.equal(w.$('.ow-disclaimer').closest('.ow-agent-bar').length,1);
 assert.match(w.$('.ow-account-column').text(),/vincular esta conversación contigo/);
 assert.equal(w.$('.ow-legal a').attr('href'),'https://slimbook.com/legal');
 assert.equal(w.$('.ow-legal a').attr('rel'),'noopener noreferrer');
 assert.equal(w.sessionStorage.getItem('slimbook_chat_v5_sales'),null);
 assert.equal(w.$('.ow-msg').length,2);assert.equal(w.$('#openwebui-chat-modal').hasClass('ow-hidden'),false);
 assert.equal(w.$('#ow-chat-input')[0].tagName,'TEXTAREA');
 w.$('#ow-chat-input').val('CPU Creative\nBatería 🔋\n\nPrecio <script>');
 const shift=w.$.Event('keydown',{key:'Enter',keyCode:13,shiftKey:true});w.$('#ow-chat-input').trigger(shift);
 assert.equal(shift.isDefaultPrevented(),false);assert.equal(w.sent.length,0);
 const composing=w.$.Event('keydown',{key:'Enter',keyCode:13,isComposing:true});w.$('#ow-chat-input').trigger(composing);assert.equal(w.sent.length,0);
 w.$('#ow-chat-input').trigger(w.$.Event('keydown',{key:'Enter',keyCode:13}));await wait(()=>w.controller);
 assert.equal(w.sent[0].message,'CPU Creative\nBatería 🔋\n\nPrecio <script>');
 assert.equal(w.$('.ow-msg-user').last().text(),w.sent[0].message);
 assert.equal(w.$('#ow-chat-reset').prop('disabled'),true);assert.equal(w.$('#ow-chat-agent').prop('disabled'),true);
 let previousParses=w.parseCount;
 w.frame({type:'delta',text:'## CPU\n**Ryzen AI 9 365**. Batería 🔋 '+ 'dato '.repeat(70)});
 await wait(()=>w.$('.ow-msg-bot').last().text().includes('Batería 🔋'));
 assert.equal(w.$('#ow-chat-send').prop('disabled'),true);
 assert.equal(w.parseCount-previousParses,1,'No parsear Markdown por caracter');
 w.frame({type:'replace',text:'Respuesta **final** 🔋 <img src=x onerror="window.injected=1"><a href="javascript:alert(1)">link</a>'});
 for(let i=0;i<70;i++)w.frame({type:'diagnostic',phase:'test',api_key:'SECRET_KEY',profile_prompt:'SECRET_PROMPT',message:'SECRET_MESSAGE'});
 w.frame({type:'done',saved:true});w.controller.close();await wait(()=>!w.$('#ow-chat-send').prop('disabled'));
 assert.match(w.$('.ow-msg-bot').last().text(),/Respuesta final 🔋/);assert.equal(w.$('.ow-msg img').length,0);assert.equal(w.$('.ow-msg a[href^="javascript:"]').length,0);
 assert.equal(w.injected,undefined);assert.equal(w.TuxAIADebug.snapshot().length,60);
 const diagnostic=JSON.stringify(w.TuxAIADebug.snapshot());for(const secret of ['SECRET_KEY','SECRET_PROMPT','SECRET_MESSAGE'])assert(!diagnostic.includes(secret));
 stored=w.sessionStorage.getItem('slimaia_session_v6');assert(!stored.includes('Creative'));assert(!stored.includes('messages'));assert(!stored.includes('Respuesta'));
 w.close();w=await load();assert.equal(w.$('.ow-msg').length,4);
 assert.equal(w.$('.ow-msg-user').last().text(),'CPU Creative\nBatería 🔋\n\nPrecio <script>');
 assert.equal(w.$('#openwebui-chat-modal').hasClass('ow-hidden'),false);
 w.$('#ow-chat-agent').val('support').trigger('change');await wait(()=>!w.$('#ow-chat-send').prop('disabled')&&w.$('.ow-msg').length===0);
 w.$('#ow-chat-agent').val('sales').trigger('change');await wait(()=>w.$('.ow-msg').length===4&&!w.$('#ow-chat-send').prop('disabled'));
 const oldToken=w.token;w.$('#ow-chat-reset').trigger('click');await wait(()=>w.token!==oldToken&&!w.$('#ow-chat-send').prop('disabled'));
 assert.equal(w.$('.ow-msg').length,0);assert.equal(server.has(oldToken),false);assert.equal(archive[0].sales.length,4);
 stored=w.sessionStorage.getItem('slimaia_session_v6');w.close();
 authenticated=true;w=await load('en',true);assert.equal(w.$('.ow-login-message').css('display'),'none');
 assert.equal(w.$('.ow-launcher-label').text(),'Hello');assert.equal(w.$('.ow-legal a').text(),'Legal notice');assert.equal(w.$('#ow-chat-agent option[value=support]').text(),'Support');
 w.$('#ow-chat-input').val('Hello');w.$('#ow-chat-send').trigger('click');await wait(()=>w.controller);
 assert.equal(w.$('.ow-powered').css('display'),'none');
 w.frame({type:'delta',text:'Immediate text under reduced motion'});await wait(()=>w.$('.ow-msg-bot').last().text().trim()==='Immediate text under reduced motion');
 w.frame({type:'error',code:'context_limit',text:'private raw upstream error'});
 w.controller.close();await wait(()=>!w.$('#ow-chat-send').prop('disabled'));
 assert.match(w.$('.ow-msg-bot').last().text(),/exceeds the model context limit/);
 assert(!JSON.stringify(server.get(w.token)).includes('Immediate text'));
 w.close();
 authenticated=false;stored=null;expiry=.15;w=await load();await wait(()=>w.$('.ow-chat-notice').text().includes('ha terminado por seguridad'));
 assert.equal(w.$('.ow-msg').length,0);assert.equal(w.$('#ow-chat-send').prop('disabled'),true);assert.equal(w.sessionStorage.getItem('slimaia_session_v6'),null);w.close();
 console.log('OK DOM Odoo 13: diseño y textos ES/EN, icono monocromo, enlace legal, animación sin parseo por carácter, reduced-motion, UTF-8, Markdown seguro, recarga, dos agentes, reset sin borrar remoto, caducidad y almacenamiento sin mensajes.');
})().catch(e=>{console.error(e);process.exit(1);});
