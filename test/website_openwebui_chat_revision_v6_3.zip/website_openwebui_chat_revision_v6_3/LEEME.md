# TuxAIA · revisión v6.3 · Odoo 13 / Open WebUI 0.11.4

## Instalar sin desinstalar el addon

Descomprime todo el ZIP en una carpeta. Desde ella:

```bash
python3 instalar.py /home/od/odoo/slimbook/website_openwebui_chat
```

Después reinicia Odoo, **actualiza `website_openwebui_chat` desde Aplicaciones** y recarga la web con Ctrl+F5. No desinstales el módulo. El instalador conserva los archivos anteriores en una carpeta privada `/tmp/website_openwebui_chat_backup_v63_…` y respeta el manifiesto y la autoría existentes.

En la consola del navegador:

```javascript
JSON.stringify(TuxAIADebug.snapshot(), null, 2)
```

El evento `widget_loaded` debe mostrar `widget_revision: "tuxaia-v6.3"`. El protocolo permanece `native-profile-v6` para conservar la compatibilidad y las sesiones existentes.

## Cambios de v6.3

- Service Token de Cloudflare opcional en Ajustes → TuxAIA: Client ID y Client Secret. La API Key de Open WebUI se mantiene.
- Credenciales solo en peticiones del servidor al destino configurado, por HTTPS. Cabeceras incluidas en HTTP, WebSocket y polling. No se siguen redirecciones. No se entregan al navegador del visitante ni se incluyen en los registros del chat. El campo secreto es visible solo para administradores y se muestra enmascarado; se almacena en parámetros de Odoo como la clave API, no en un almacén cifrado independiente.
- Casilla de activación corregida, tanto en los ajustes originales del sitio web como en TuxAIA. Al guardar desactivado conserva ese estado; al recargar la web no se muestra el chat ni se crea su sesión. También se bloquean peticiones nuevas al servidor. Una generación ya iniciada no se cancela con esta casilla.
- Enter envía; Shift+Enter añade un salto. Campo de dos líneas ampliable. Se conservan saltos, líneas en blanco y caracteres Unicode al enviar y recuperar el historial. La composición de texto con un teclado IME no envía accidentalmente el mensaje.
- Se conservan la animación de 800 ms, los tres puntos, los títulos, los dos agentes, el prompt y parámetros del perfil, y la gestión del historial.

## Configurar Cloudflare

1. En Zero Trust → Access controls → Service credentials → Service Tokens, crea un token para Odoo. Guarda Client ID y Client Secret; el secreto se muestra al generarlo. Si no lo conservas, genera otro o rota el secreto.
2. En la aplicación Access de `ai.slimbook.com`, añade una política **Service Auth**, con **Include → Service Token → el token de Odoo**. Conserva el acceso por correo de las personas.
3. En los ajustes del sitio web, usa `https://ai.slimbook.com` como URL Open WebUI. En Ajustes → TuxAIA introduce ambos valores, sin los prefijos `CF-Access-Client-Id:` ni `CF-Access-Client-Secret:`. Guarda. No sustituyas la API Key de Open WebUI.
4. Para comprobar que realmente autentica con el token, desactiva temporalmente el Bypass de la IP de Odoo y prueba el chat. Si falla, puedes restaurar ese Bypass mientras revisas la política; si funciona, déjalo desactivado.

La revisión no modifica tu cuenta Cloudflare ni prueba tus credenciales reales. Ambos campos vacíos conservan el funcionamiento anterior sin Service Token. No es un API Token de administración de Cloudflare.

## Funciones conservadas de v6.2

- TuxAIA en la cabecera, avisos, accesibilidad, consola, formulario y menú de Ajustes. El instalador actualiza también los textos iniciales de las plantillas existentes que contienen el chat. No cambia respuestas antiguas ni el prompt del perfil de Open WebUI: si el modelo se presenta con el nombre anterior, hay que actualizar ese nombre en su perfil.
- Entrada del mensaje y botones encima de la franja «Hablar con», como en el boceto. En la columna derecha de esa franja quedan el acceso a la cuenta, el aviso de errores, Aviso legal y, opcionalmente, Powered by TuxAIA. Al iniciar sesión se oculta solo la invitación a entrar; los avisos siguen visibles.
- Cortina y opacidad de **800 ms** por fragmento nuevo. Los fragmentos recibidos juntos se animan a la vez, no se suman 800 ms por párrafo. Se mantienen las actualizaciones durante la generación y no se espera a la respuesta completa.
- Tres círculos CSS pulsantes junto a «TuxAIA está pensando». Tienen tamaño fijo y reglas limitadas al widget para resistir estilos del tema que oculten spans. Las animaciones respetan movimiento reducido; en ese caso los puntos permanecen estáticos.
- Títulos identificativos corregidos, sin modificar los mensajes.
- El error de contexto se reconoce y se muestra en español o inglés, también al restaurar el historial. Ya no recomienda recargar como solución a ese error concreto. El diagnóstico añade causa, fase y, si el motor los comunica en ese formato, tokens solicitados y límite.

## Powered by TuxAIA

En **Ajustes → TuxAIA**, rellena **URL del proyecto TuxAIA** con:

```text
https://tuxaia.com
```

Guarda y recarga la web. Con el campo vacío no aparece el crédito. Se aceptan direcciones absolutas HTTP/HTTPS sin credenciales; el navegador vuelve a comprobarlas antes de crear el enlace. El ajuste se guarda en `website_openwebui_chat.project_url`.

El enlace de Aviso legal sigue apuntando a https://slimbook.com/legal. No hay cambios de configuración de Cloudflare Access en esta entrega.

## Por qué los chats acababan llamándose «Hola»

El código de Open WebUI 0.11.4 trata de forma distinta omitir `title_generation` y enviarlo con valor `false`: con la clave presente, aunque esté desactivada la generación mediante el modelo, puede usar el primer mensaje como título al terminar el primer turno.

La revisión omite esa clave. Mantiene desactivadas las tareas auxiliares de etiquetas y seguimiento. No añade instrucciones al modelo para conseguir el título.

- Cliente autenticado: `Ventas · correo` o `Soporte · correo`.
- Invitado: `Ventas · día-mes-año_hora:minuto:segundo_123`, con el prefijo de su agente y tres cifras aleatorias.
- El identificador de invitado se conserva durante la conversación; no se regenera en cada mensaje.
- Iniciar sesión mantiene los chats de ambos agentes y los identifica con el correo autenticado de Odoo.
- Al recuperar un chat activo con título incorrecto se corrige mediante una actualización parcial del título. Para invitados antiguos se toma la fecha del primer mensaje y se asignan una vez las tres cifras, porque el sufijo original no se conservaba en v6.1.

No se recorren ni renombran en masa los chats archivados que ya no están asociados a una sesión activa. Los cambios de título o asociación no sobrescriben el historial ni crean otra generación.

## Error de contexto: qué se corrige y qué queda pendiente

El export analizado confirma una petición de **40.515 tokens frente a un límite efectivo de 32.768**. No es un fallo de animación ni de autenticación con Cloudflare. Los resultados de herramientas forman parte del contexto además de las preguntas y respuestas visibles.

En la secuencia analizada, el modelo leyó siete fichas y volvió a solicitar las mismas siete en el turno siguiente, con IDs nuevos de llamada. La segunda lectura añadió unos 30.000 caracteres de documentación. Los resultados quedaron guardados, por lo que recargar la web no redujo el contexto. Empezar otra conversación sí lo hizo.

La revisión presenta un aviso específico y registra `reason_code: context_limit`, `requested_tokens` y `context_limit`. **No recorta, resume ni borra el historial, no cambia el contexto del servidor, ni modifica temperatura, herramientas o prompt.** La política de contexto debe acordarse antes de implementarla. Ver `DIAGNOSTICO_contexto.md` para las cifras y las opciones.

## Ajustes y compatibilidad

Ventas y Soporte siguen teniendo IDs de perfil independientes. El modelo general antiguo solo sirve como respaldo cuando el ID de Ventas está vacío. La URL y la clave permanecen en el bloque original; la activación también se muestra en TuxAIA. El bloque original aclara el modelo de respaldo y oculta el campo antiguo de prompt que no utiliza este controlador.

El cambio de marca es visible. Los IDs técnicos de campos/vistas, el nombre del addon, las cabeceras de sesión, las claves de almacenamiento y la ruta predeterminada del log se conservan para no perder configuraciones o conversaciones. `SlimAIADebug` y `SlimAIACompare` siguen disponibles como alias de compatibilidad; las herramientas visibles nuevas se llaman `TuxAIADebug` y `TuxAIACompare`.

Se conserva el mecanismo de conversaciones de v6: credencial por pestaña en sessionStorage, 15 minutos de inactividad por defecto, agente y apertura restaurados al recargar. ↻ revoca los chats asociados a esa pestaña para ambos agentes sin borrarlos en Open WebUI. Los navegadores pueden restaurar pestañas tras cerrarse: para un equipo compartido sigue siendo necesario terminar la conversación y cerrar la cuenta Odoo.

## Registro privado

Los ajustes existentes se conservan. Desactivado por defecto; se puede activar y parar desde Ajustes → TuxAIA. Ruta predeterminada: `/var/log/odoo/slimaia_debug.log`; se admite otra ruta absoluta acabada en `.log`, por ejemplo `/tmp/tuxaia_debug.log`, si Odoo puede crear y rotar archivos en esa carpeta.

Permisos 0600, rotación de 5 MiB y tres copias. No guarda preguntas, respuestas, resultados de herramientas, cookies o claves API. El texto del prompt solo se añade si se activa la opción correspondiente **y la API permite leerlo**. `hidden_read_only` y `profile_prompt_present: null` indican que esa API no lo revela; no demuestran ausencia de prompt ni permiten afirmar cuál fue la petición efectiva al proveedor.

La consola conserva un máximo de 60 entradas sin contenido. La impresión automática sigue desactivada; puede habilitarse temporalmente con `TuxAIADebug.setEnabled(true)`.

## Validación y límites

- 21 pruebas de controlador con servidor API/modelo simulado y Socket.IO real local: continuidad, agentes, permisos, asociación al iniciar sesión, títulos, error de contexto y URL opcional.
- Reproducido el renombrado a «Hola» ejecutando la función de Open WebUI 0.11.4; probado que omitir la clave evita ese renombrado.
- La extracción del historial para el modelo produce exactamente el mismo resultado que v6.1 sobre el export aportado.
- Comprobadas las pruebas de registro privado, vista de Ajustes e instalador, además del comparador de peticiones.
- Widget probado con jQuery de Odoo 13 y DOM simulado: continuidad, Markdown seguro, UTF-8, pie, crédito opcional y error de contexto localizado.
- Chromium real en español e inglés, móvil y escritorio: disposición, puntos visibles, animaciones CSS de 800 ms, recepción incremental antes del final y preferencia de movimiento reducido.

Las nuevas pruebas comprueban cabeceras de Access, rechazo de pares incompletos y HTTP sin cifrar, desactivación, persistencia de la casilla, redacción de secretos, Shift+Enter y restauración multilínea. Las dependencias de prueba no se instalan en tu servidor.

No se ha desplegado en tu instalación ni se ha ejecutado una instancia completa de Odoo 13 o tu modelo. No se incluyen conversaciones privadas ni credenciales en el ZIP.

## Revertir

La copia indicada por el instalador contiene `archivos.json`. Restaura los archivos con `existed: true` y retira los que figuren como nuevos; luego reinicia Odoo y actualiza el módulo. No borres los chats de Open WebUI. El campo de proyecto opcional no cambia los datos anteriores.
