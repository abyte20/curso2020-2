{
    'name': 'Website Open WebUI Chatbot',
    'summary': 'Chatbot flotante informativo de ventas conectado a Open WebUI',
    'category': 'Website',
    'version': '13.0.2.0.2',
    'depends': ['website'],
    'data': ['views/slimaia_settings.xml', 
        'views/res_config_settings_views.xml',
        'views/templates.xml',
        'views/snippets.xml',
    ],
    'installable': True,
    'application': False,
}
