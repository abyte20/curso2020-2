odoo.define('website_openwebui_chat.presentation', function () {
    'use strict';
    // Presentation owns DOM placement only. Sessions, messages and transport stay in widget.js.
    var $modal, $launcher, $expand, $close, config={}, active=null, agent='sales', full=false;
    var started=false, home, next, oldOverflow='', previousFocus, tr, resume, timer=null;
    var initialized=false, editing=null, typeNode=null, typeOriginal=null, resizeObserver;
    var iconExpand='<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 3H3v5m0-5 7 7m6-7h5v5m0-5-7 7M3 16v5h5m-5 0 7-7m11 2v5h-5m5 0-7-7"/></svg>';
    var iconReduce='<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 3l7 7m0-5v5H5M21 3l-7 7m5 0h-5V5M3 21l7-7m-5 0h5v5m11 2-7-7m0 5v-5h5"/></svg>';
    function isEditing(){
        if(editing!==null)return editing;
        return /(?:\?|&)(?:enable_editor|edit_translations)=1(?:&|$)/.test(location.search) || document.body.classList.contains('editor_enable');
    }
    function mounts(settings){
        return $('.s_tuxaia_support').filter(function(){
            if(!settings.active || !settings.support)return false;
            return $(this).closest('[data-tuxaia-auto]').length ? settings.support_embedded : settings.support_blocks;
        }).toArray();
    }
    function stopTyping(){
        window.clearTimeout(timer);timer=null;
        if(typeNode)typeNode.remove();
        if(typeOriginal)typeOriginal.classList.remove('tuxaia-typing-source');
        typeNode=typeOriginal=null;
    }
    function greeting(){
        stopTyping();
        if(!active || started || isEditing() || window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
        try{if(sessionStorage.getItem('tuxaia_intro_seen_v66'))return;sessionStorage.setItem('tuxaia_intro_seen_v66','1');}catch(ignore){}
        typeOriginal=active.querySelector('.tuxaia-greeting');if(!typeOriginal)return;
        var text=Array.from(typeOriginal.textContent.trim()),index=0;
        typeNode=document.createElement('span');typeNode.className='tuxaia-greeting-animation';typeNode.setAttribute('aria-hidden','true');
        typeOriginal.classList.add('tuxaia-typing-source');typeOriginal.parentNode.appendChild(typeNode);
        typeNode.style.top=typeOriginal.offsetTop+'px';typeNode.style.left=typeOriginal.offsetLeft+'px';typeNode.style.width=typeOriginal.offsetWidth+'px';
        function tick(){
            if(!typeNode || isEditing())return;
            typeNode.textContent=text.slice(0,++index).join('');
            if(index<text.length)timer=window.setTimeout(tick,22);else stopTyping();
        }
        tick();
    }
    function layout(){
        if(!$modal || !active || full || isEditing())return;
        var compact=!started && agent==='support';
        $modal.toggleClass('ow-compact',compact);
        $(active).toggleClass('tuxaia-started',!compact);
        var height;
        if(compact){
            height=2;
            $modal.children('.ow-chat-footer,.ow-agent-bar,.ow-chat-notice').each(function(){height+=$(this).outerHeight(true);});
        }else height=Math.max(420,Math.min(550,window.innerHeight*.8));
        $modal[0].style.setProperty('--tuxaia-height',Math.ceil(height)+'px');
    }
    function paintControls(){
        if(!$modal)return;
        // Keep the existing configuration key so enabled installations retain their setting.
        var permitted=Boolean(config.support_expand);
        var compact=Boolean(active && !started && agent==='support' && !full && !isEditing());
        if(compact)$expand.appendTo($(active).find('.tuxaia-speech').first());
        else $expand.insertBefore($close);
        $expand.prop('hidden',!permitted).attr({'aria-expanded':full?'true':'false','aria-label':full?tr('Reducir chat','Reduce chat'):tr('Ampliar chat','Expand chat')})
            .html((full?iconReduce:iconExpand)+'<span>'+ (full?tr('Reducir','Reduce'):tr('Ampliar','Expand'))+'</span>');
        $close.prop('hidden',Boolean(active && !full)).attr('aria-label',active?tr('Volver al chat incrustado','Back to embedded chat'):tr('Cerrar ventana del chat','Close chat window'));
        // Compact mode still has a visible maximize button above the composer.
        $expand.toggleClass('ow-expand-compact',compact);
        $launcher.toggleClass('ow-launcher-suppressed',Boolean(active || full || isEditing() || !$modal.hasClass('ow-hidden')));
    }
    function moveModal(parent, before){
        // Reparenting can restart CSS animations. Keep each response fragment at its current time.
        var snapshots=[];
        if($modal[0].getAnimations)$modal[0].getAnimations({subtree:true}).forEach(function(a){
            var target=a.effect && a.effect.target;
            if(a.animationName==='ow-block-reveal' && target)snapshots.push({target:target,time:a.currentTime,finished:a.playState==='finished'});
        });
        if(before && before.parentNode===parent)parent.insertBefore($modal[0],before);else parent.appendChild($modal[0]);
        snapshots.forEach(function(saved){
            saved.target.getAnimations().forEach(function(a){
                if(a.animationName!=='ow-block-reveal')return;
                if(saved.finished)a.finish();else if(saved.time!==null)a.currentTime=saved.time;
            });
        });
    }
    function expand(value){
        if(!$modal || isEditing() || (value && !config.support_expand) || value===full)return;
        full=value;stopTyping();
        if(full){
            previousFocus=document.activeElement;home=$modal[0].parentNode;next=$modal[0].nextSibling;
            oldOverflow=document.body.style.overflow;
            moveModal(document.body);$modal.removeClass('ow-hidden ow-compact').addClass('ow-fullscreen');
            document.body.style.overflow='hidden';
            $modal.attr({'role':'dialog','aria-modal':'true','aria-label':'TuxAIA'});
        }else{
            $modal.removeClass('ow-fullscreen').removeAttr('aria-modal').attr('role','region');
            document.body.style.overflow=oldOverflow;
            if(home && document.documentElement.contains(home)){
                moveModal(home,next);
            }else moveModal(document.body);
        }
        paintControls();layout();
        var target=full ? $('#ow-chat-input')[0] : previousFocus;
        if(target && document.documentElement.contains(target))target.focus({preventScroll:true});
    }
    function activate(section){
        if(isEditing() || mounts(config).indexOf(section)<0)return;
        if(full)expand(false);
        if(active)$(active).removeClass('tuxaia-active tuxaia-started');
        active=section;
        moveModal($(active).find('.tuxaia-support-mount').first()[0]);$modal.addClass('ow-embedded').removeClass('ow-hidden');
        $(active).addClass('tuxaia-active');
        paintControls();layout();greeting();
    }
    function clean(){
        stopTyping();
        if(!$modal)return;
        // Runs on Odoo's public-widget destroy BEFORE the editor reads/saves HTML.
        if(full){full=false;document.body.style.overflow=oldOverflow;}
        $modal.appendTo(document.body).removeClass('ow-embedded ow-fullscreen ow-compact').removeAttr('aria-modal').addClass('ow-editor-suspended');
        $modal[0].style.removeProperty('--tuxaia-height');
        $launcher.addClass('ow-editor-suspended');
        $('.s_tuxaia_support').removeClass('tuxaia-ready tuxaia-active tuxaia-started tuxaia-disabled');
        $('[data-tuxaia-auto]').removeClass('tuxaia-auto-ready');
        active=null;$expand.insertBefore($close);
    }
    function refresh(){
        if(!initialized || isEditing())return;
        $modal.removeClass('ow-editor-suspended');$launcher.removeClass('ow-editor-suspended');
        var eligible=mounts(config);
        $('.s_tuxaia_support').each(function(){
            var allowed=eligible.indexOf(this)>=0;
            $(this).toggleClass('tuxaia-ready',allowed).toggleClass('tuxaia-disabled',!allowed);
            $(this).closest('[data-tuxaia-auto]').toggleClass('tuxaia-auto-ready',allowed);
        });
        if(eligible.length)activate(active && eligible.indexOf(active)>=0?active:eligible[0]);
        else {active=null;paintControls();}
    }
    return {
        isEditing:isEditing,
        hasMount:function(settings){return mounts(settings).length>0;},
        setEditing:function(value){
            if(value===false && editing===null && isEditing())return;
            var previous=isEditing();editing=Boolean(value);
            if(editing)clean();
            else if(initialized){refresh();if(previous && resume)resume();}
        },
        init:function(options){
            config=options.config;agent=options.agent;tr=options.tr;resume=options.resume;
            $modal=$('#openwebui-chat-modal');$launcher=$('#openwebui-chat-button');$close=$('#ow-chat-close');
            $modal.attr({'role':'region','aria-label':'TuxAIA'});
            $expand=$('<button type="button" id="ow-chat-expand" class="ow-expand-control"/>').insertBefore($close).on('click',function(){expand(!full);});
            initialized=true;
            $(document).on('click.tuxaia','.s_tuxaia_support .tuxaia-start-chat',function(event){
                event.preventDefault();if(isEditing())return;activate($(this).closest('.s_tuxaia_support')[0]);$('#ow-chat-input').trigger('focus');
            });
            new MutationObserver(paintControls).observe($modal[0],{attributes:true,attributeFilter:['class']});
            if(window.ResizeObserver){
                resizeObserver=new ResizeObserver(layout);
                $modal.children('.ow-chat-footer,.ow-agent-bar,.ow-chat-notice').each(function(){resizeObserver.observe(this);});
            }
            window.addEventListener('resize',layout);
            document.addEventListener('keydown',function(event){
                if(!full || isEditing())return;
                if(event.key==='Escape'){event.preventDefault();expand(false);return;}
                if(event.key!=='Tab')return;
                var list=$modal.find('button,select,textarea,a[href],input').filter(':visible:not(:disabled)').toArray();
                if(!list.length)return;
                var first=list[0],last=list[list.length-1],current=document.activeElement;
                if(event.shiftKey && (current===first || !$modal[0].contains(current))){event.preventDefault();last.focus();}
                else if(!event.shiftKey && (current===last || !$modal[0].contains(current))){event.preventDefault();first.focus();}
            });
            window.addEventListener('pagehide',function(){stopTyping();if(full)expand(false);});
            if(isEditing())clean();else refresh();paintControls();
        },
        setAgent:function(value){agent=value;stopTyping();paintControls();layout();},
        conversation:function(value){started=Boolean(value);if(started)stopTyping();paintControls();layout();},
        handleClose:function(id){if(id!=='ow-chat-close')return false;if(full){expand(false);if(active)return true;}return Boolean(active);},
        status:function(){return {revision:'tuxaia-v6.6.1-ui',agent:agent,embedded:Boolean(active),fullscreen:full,expand_enabled:Boolean(config.support_expand),expand_visible:Boolean($expand && !$expand.prop('hidden')),editor:isEditing()};}
    };
});
