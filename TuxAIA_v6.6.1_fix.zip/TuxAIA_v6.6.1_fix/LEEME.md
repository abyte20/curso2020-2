# TuxAIA 6.6.1 · Corrección sobre 6.6 · Odoo 13

Este ZIP corrige los archivos de la versión 6.6 que ya has copiado al servidor, aunque su actualización en Odoo haya fallado. Es un parche de siete archivos sobre los dos módulos existentes; no es un módulo nuevo.

## Causa y corrección

El catálogo español de `website_openwebui_chat` carecía de las marcas `#. module: website_openwebui_chat` en sus 50 entradas. En `helpdesk_mgmt_custom` faltaban en dos entradas nuevas. El lector `PoFileReader` de Odoo 13 exige esas marcas y fallaba con:

```text
AttributeError: 'NoneType' object has no attribute 'groups'
```

El error se ha reproducido con el lector oficial de Odoo 13. Los dos catálogos corregidos pasan ese mismo lector. El fallo impedía completar la actualización del módulo, necesaria también para crear el campo `tuxaia_support_blocks` que faltaba en Ajustes.

Esta revisión permite **Ampliar / Reducir tanto Ventas como Soporte**. Mantiene el nombre técnico del campo y la clave de configuración para conservar el valor ya guardado. El texto visible cambia a **Permitir ampliar los chats de Ventas y Soporte**, dentro de **Presentación del chat**. Al cambiar de perfil con la ventana ampliada se mantiene ese tamaño; cada perfil conserva su conversación mediante el funcionamiento existente.

Se mantienen los archivos del icono original de Alejandro, la cabecera, la animación de respuestas, los bloques y textos editables, los controladores y el protocolo con Open WebUI. Los adjuntos del chatbot siguen fuera de esta versión.

Versiones técnicas: `website_openwebui_chat` → `13.0.2.0.2`; `helpdesk_mgmt_custom` → `13.0.1.0.2`.

## Instalar

Conserva una copia de seguridad de la base de datos antes de actualizar los módulos. Sube `TuxAIA_v6.6.1_fix.zip` a `/home/od/`.

Como usuario `od`:

```bash
cd /home/od
unzip TuxAIA_v6.6.1_fix.zip
cd TuxAIA_v6.6.1_fix
python3 instalar.py --check /home/od/odoo/slimbook
```

La comprobación debe indicar **7 archivos pendientes** sobre una 6.6 sin modificar. Si ya están corregidos, puede indicar menos o cero. `--check` no modifica los módulos ni la base de datos. Si detecta archivos ajenos a la versión revisada, se detiene sin sobrescribirlos; conserva la salida para revisarla.

**Detén Odoo mediante el procedimiento que usas habitualmente.** Con Odoo detenido, aplica:

```bash
python3 instalar.py /home/od/odoo/slimbook
```

El instalador crea una copia en `copias/tuxaia_v661_backup_...`, junto al instalador, e imprime su ruta absoluta. Se puede elegir otra carpeta con `--backup-dir /ruta/de/copias`. No borres esa copia. El instalador solo sustituye archivos, conserva sus permisos y comprueba la integridad del paquete; no modifica la base de datos ni reinicia servicios.

**Arranca Odoo** para que todos los procesos carguen el Python actualizado. A continuación, en **Aplicaciones**, quita el filtro «Aplicaciones», busca por nombre técnico y pulsa **Actualizar** en:

1. `website_openwebui_chat`
2. `helpdesk_mgmt_custom`

Actualizar la lista de aplicaciones o reiniciar el servicio no sustituye la actualización de cada módulo. Espera a que termine cada actualización antes de pasar a la siguiente. Si alguna falla, conserva la traza completa y revisa ese fallo antes de continuar.

Tras completar ambas, recarga la web con `Ctrl+F5` y guarda los ajustes de TuxAIA. En **Presentación del chat**, activa **Permitir ampliar los chats de Ventas y Soporte** si estaba desactivado. El botón debe aparecer con cualquiera de los dos perfiles. Ventas puede ampliarse también si no hay un perfil de Soporte configurado.

## Comprobación breve

- Los dos módulos se actualizan sin el error de traducciones.
- Los ajustes se guardan sin el error de columna ausente.
- El flotante muestra Ampliar tanto en Ventas como en Soporte cuando el ajuste está activo.
- Ampliar y reducir conserva conversación y borrador. Escape reduce la ventana.
- El icono del flotante cerrado sigue siendo tu imagen original.

Si no aparece el botón, ejecuta en la consola del navegador:

```javascript
TuxAIADebug.presentation()
```

La revisión nueva muestra `revision: "tuxaia-v6.6.1-ui"`; con el ajuste activo, `expand_enabled` y `expand_visible` deben ser `true`. Una revisión anterior indica que siguen cargándose los assets antiguos. La información de este diagnóstico no contiene conversaciones ni credenciales.

## Restaurar los archivos

Con Odoo detenido, sustituye el marcador por la ruta real impresa al instalar:

```bash
python3 instalar.py --restore /ruta/real/tuxaia_v661_backup_XXXX /home/od/odoo/slimbook
```

Después arranca Odoo. La restauración devuelve exactamente los archivos previos: **si eran los de la 6.6, recupera también sus traducciones defectuosas**. No vuelvas a intentar actualizar esos módulos con los catálogos defectuosos. Este mecanismo revierte archivos; no revierte cambios de la base de datos ni ediciones del contenido web.

## Verificación realizada

- Reproducción del mismo `AttributeError` en ambos catálogos de la 6.6 mediante el `PoFileReader` oficial de Odoo 13.
- Lectura correcta de los catálogos corregidos: 50 entradas del chat → 51 registros Odoo; 75 entradas de Helpdesk → 84 registros Odoo. Una entrada puede referirse a más de una vista.
- El instalador rechaza las marcas de módulo incorrectas antes de copiar archivos, además de comprobar hashes y sintaxis Python/XML.
- Instalación sobre una copia completa de la 6.6, repetición sin cambios, rechazo de modificaciones posteriores y restauración exacta de los archivos.
- Chromium: escritorio/móvil, español/inglés, chat incrustado y flotante, ampliación de ambos perfiles, Ventas sin Soporte configurado, cambio de perfil en pantalla completa, borrador, foco, mensajes progresivos y retirada de la conversación del contenido editable.
- Comparación de archivos: icono, controladores, transporte, sesiones, animación y contenido editable sin cambios respecto a 6.6.

Se ha ejecutado el lector real de traducciones de forma aislada, sin conectar a una base de datos. Las pruebas de navegador usan transporte simulado. **Falta comprobar la actualización completa en vuestro Odoo 13 y la conexión real con Open WebUI.**

Se incluye `verificar_traducciones.py` para repetir, opcionalmente, la lectura aislada con vuestro `odoo/tools/translate.py`. Requiere el mismo entorno Python de Odoo, con `polib`; no requiere conexión a la base de datos y no forma parte de los pasos normales de instalación.

Fuente utilizada: https://raw.githubusercontent.com/odoo/odoo/13.0/odoo/tools/translate.py

SHA256 de la fuente utilizada en la prueba: `685aaf2df08fac514ef0dcfb87c36d0cd10cebb8ad500ec28eddb13511cbc074`.
