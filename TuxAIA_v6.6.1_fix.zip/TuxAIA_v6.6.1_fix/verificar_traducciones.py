#!/usr/bin/env python3
"""Read the package catalogues with an installed Odoo 13 PoFileReader, without a database.

Use the same Python environment as Odoo (it supplies polib).
Only the unmodified PoFileReader class is loaded from the supplied source file.
"""
import argparse
import ast
import logging
from pathlib import Path
import re


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('odoo_translate', type=Path,
                        help='Ruta a odoo/tools/translate.py de Odoo 13')
    parser.add_argument('--payload', type=Path,
                        default=Path(__file__).resolve().parent/'payload')
    args = parser.parse_args()
    try:
        import polib
    except ImportError:
        parser.error('Ejecuta con el Python de Odoo; esta comprobación necesita polib.')
    source = ast.parse(args.odoo_translate.read_text(encoding='utf-8'))
    reader = next(n for n in source.body
                  if isinstance(n, ast.ClassDef) and n.name == 'PoFileReader')
    namespace = {'polib': polib, 'Path': Path, 're': re,
                 '_logger': logging.getLogger('odoo13.translation_check')}
    exec(compile(ast.Module(body=[reader], type_ignores=[]),
                 str(args.odoo_translate), 'exec'), namespace)
    files = sorted(args.payload.glob('*/i18n/*.po'))
    if not files:
        parser.error('No se encontraron catálogos en el payload indicado.')
    for path in files:
        with path.open('rb') as stream:
            rows = list(namespace['PoFileReader'](stream))
        if not rows or any(row['module'] != path.parent.parent.name for row in rows):
            raise ValueError('Catálogo vacío o módulo incorrecto: ' + str(path))
        print('OK: %s (%d registros de traducción)' % (path, len(rows)))
    print('Comprobación completada; no se ha conectado a ninguna base de datos.')


if __name__ == '__main__':
    main()
