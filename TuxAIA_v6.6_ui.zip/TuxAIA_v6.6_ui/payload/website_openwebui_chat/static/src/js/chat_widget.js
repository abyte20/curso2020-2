odoo.define('website_openwebui_chat.widget', function (require) {
    'use strict';
    var PROTOCOL = 'native-profile-v6';
    var WIDGET_REVISION = 'tuxaia-v6.6-ui';
    var presentation = require('website_openwebui_chat.presentation');
    $(document).ready(async function () {
        if (!document.getElementById('ow-chat-messages')) return;
        // No crear sesion ni recuperar historial si el administrador lo desactiva.
        var available;
        try {
            var configuration = await fetch('/website_chat/agents',{credentials:'same-origin',cache:'no-store'});
            if (!configuration.ok) return;
            available = await configuration.json();
            if (available.active !== true) return;
        } catch (ignore) { return; }
        var embedded = presentation.hasMount(available);
        var english = /^en([_-]|$)/i.test(document.documentElement.lang || 'es');
        function tr(es, en) { return english ? en : es; }
        var conversation = null, token = null, agent = 'sales', authenticated = false;
        var agents = {sales:true, support:false}, busy = false, ready = false, pending = false;
        var openPreference = '0', expiresAt = 0, idleSeconds = 900;
        var restoreSequence = 0, expiryTimer = null, pendingTimer = null, animation = null;
        var lastTouch = 0, lastFocus = 0, sessionPromise = null;
        var $modal = $('#openwebui-chat-modal'), $messages = $('#ow-chat-messages');
        try {
            var stored = JSON.parse(sessionStorage.getItem('slimaia_session_v6') || 'null');
            if (stored && stored.expires_at > Date.now()/1000) {
                token = stored.token; agent = stored.agent === 'support' ? 'support' : 'sales';
                openPreference = stored.open === '1' ? '1' : '0'; expiresAt = stored.expires_at;
            }
            // Retirar las copias de mensajes que guardaban versiones anteriores.
            ['slimbook_chat_v4','slimbook_chat_v5_sales','slimbook_chat_v5_support','slimaia_agent','slimaia_open_v4'].forEach(function(k){sessionStorage.removeItem(k);});
        } catch (ignore) {}
        if (embedded) agent = 'support';
        $messages.empty();
        if (openPreference === '1') $modal.removeClass('ow-hidden');
        $('.ow-chat-header span').first().empty()
            .append($('<img class="ow-header-penguin" alt="">').attr('src','/website_openwebui_chat/static/src/img/tuxaia_penguin.svg'))
            .append($('<span class="ow-header-title">').append($('<strong>').text('TuxAIA'))
                .append($('<small>').text(tr('Asistente Inteligencia Artificial','Artificial Intelligence Assistant'))));
        var $launcher = $('#openwebui-chat-button').empty()
            .append($('<img>').attr({src:'/website_openwebui_chat/static/src/img/agent_icon.png',alt:''}))
            .append($('<span class="ow-launcher-label">').text(tr('Hola','Hello')))
            .attr({role:'button',tabindex:'0','aria-label':tr('Hola. Abre el chat con TuxAIA','Hello. Open TuxAIA chat'),'aria-controls':'openwebui-chat-modal'});
        $('#ow-chat-close').attr('aria-label',tr('Cerrar ventana del chat','Close chat window'));
        $('#ow-chat-send').attr({type:'button','aria-label':tr('Enviar mensaje','Send message'),title:tr('Enviar mensaje','Send message')});
        var $input = $('#ow-chat-input');
        if (!$input.is('textarea')) {
            var $multiline = $('<textarea id="ow-chat-input" rows="2" autocomplete="off">').val($input.val());
            $multiline.attr('class', $input.attr('class') || '');
            $input.replaceWith($multiline);
        }
        $('#ow-chat-input').attr({rows:2,placeholder:tr('Escribe tu consulta…','Type your question…'),
            'aria-label':tr('Tu mensaje. Enter envía; Mayús+Enter añade una línea.','Your message. Enter sends; Shift+Enter adds a line.'),
            title:tr('Enter: enviar · Mayús+Enter: salto de línea','Enter: send · Shift+Enter: new line')});
        // Readonly conserva el foco del textarea durante la espera.
        $input = $('#ow-chat-input');
        var inputPlaceholder = $input.attr('placeholder');
        $input.wrap('<div class="ow-input-wrap"></div>');
        var $inputWaiting = $('<div class="ow-input-waiting" role="status">').hide()
            .append($('<span>').text(tr('TuxAIA está pensando', 'TuxAIA is thinking')))
            .appendTo($input.parent());
        var $inputDots = $('<span class="ow-thinking-dots" aria-hidden="true">').appendTo($inputWaiting);
        for (var dot=0;dot<3;dot++) $inputDots.append($('<span class="ow-thinking-dot">'));
        var $selector = $('<select id="ow-chat-agent">').attr('aria-label',tr('Hablar con','Talk to'))
            .append($('<option value="sales">').text(tr('Ventas','Sales')))
            .append($('<option value="support">').text(tr('Soporte','Support'))).val(agent);
        var $bar = $('<div class="ow-agent-bar">');
        var $department = $('<div class="ow-agent-column">').append($('<label for="ow-chat-agent">').text(tr('Hablar con','Talk to'))).append($selector);
        var $login = $('<a class="ow-login-link">').text(tr('Entra en tu cuenta','Sign in to your account'));
        var redirect = window.location.pathname + window.location.search + '#slimaia';
        $login.attr('href','/web/login?redirect=' + encodeURIComponent(redirect));
        var $loginMessage = $('<div class="ow-login-message">').append($login)
            .append(document.createTextNode(tr(' para vincular esta conversación contigo.',' to link this conversation to you.')));
        var $account = $('<div class="ow-account-column">').append($loginMessage);
        $bar.append($department).append($account);
        var $footer = $('.ow-chat-footer');
        if (!$footer.length) $footer = $('#ow-chat-input').parent();
        $footer.after($bar);
        var $reset = $('<button id="ow-chat-reset" type="button">').text('↻').attr({
            'aria-label':tr('Nueva conversación: finalizar los chats actuales','New conversation: end the current chats'),
            title:tr('Nueva conversación','New conversation')});
        $('#ow-chat-send').before($reset);
        var $notice = $('<div class="ow-chat-notice" role="status">');
        $footer.before($notice);
        var $disclaimer = $('<div class="ow-disclaimer">')
            .append(document.createTextNode(tr('La IA puede cometer errores. Comprueba la información importante.','AI can make mistakes. Check important information.')))
            .append($('<span class="ow-legal">').append(document.createTextNode(tr('Lee el ','Read the ')))
                .append($('<a>').attr({href:'https://slimbook.com/legal',target:'_blank',rel:'noopener noreferrer'}).text(tr('Aviso legal','Legal notice')))
                .append(document.createTextNode(tr(' aquí.',' here.')))).appendTo($account);
        var $powered = $('<span class="ow-powered">').hide().appendTo($disclaimer.find('.ow-legal'));
        function branding(value) {
            $powered.empty().hide();
            if (!value) return;
            try {
                var url = new URL(value);
                if (!/^https?:$/.test(url.protocol) || url.username || url.password) return;
                $powered.append(document.createTextNode(' Powered by '))
                    .append($('<a>').attr({href:url.href,target:'_blank',rel:'noopener noreferrer'}).text('TuxAIA')).show();
            } catch(ignore) {}
        }
        function publicError(message, code) {
            if(code==='context_limit')return tr(
                'Esta conversación supera la capacidad de contexto del modelo. Usa ↻ para iniciar otra; la anterior sigue guardada. Recargar la página no resuelve este límite.',
                'This conversation exceeds the model context limit. Use ↻ to start another; the previous chat remains saved. Reloading the page will not resolve this limit.');
            return english ? 'The request could not be completed. Reload to check the saved conversation before trying again.' : (message || 'No se pudo completar la consulta.');
        }
        function headers() { var h={'X-Requested-With':'XMLHttpRequest'}; if(token)h['X-SlimAIA-Session']=token; return h; }
        function cache() {
            try {
                if(token) sessionStorage.setItem('slimaia_session_v6',JSON.stringify({token:token,agent:agent,open:openPreference,expires_at:expiresAt}));
                else sessionStorage.removeItem('slimaia_session_v6');
            } catch(ignore) {}
        }
        function controls() {
            var waiting = busy || pending;
            $('#ow-chat-send').prop('disabled',busy || !ready);
            $input.prop('disabled',false).prop('readOnly',busy || !ready)
                .attr({'aria-disabled':busy || !ready ? 'true' : 'false', 'aria-busy':waiting ? 'true' : 'false',
                    placeholder:waiting ? '' : inputPlaceholder});
            $inputWaiting.toggle(waiting);
            $input.parent().toggleClass('ow-input-is-waiting',waiting);
            $selector.prop('disabled',busy); $reset.prop('disabled',busy);
            $login.attr('aria-disabled', busy ? 'true' : 'false');
        }
        function scroll() { var e=$messages[0];e.scrollTop=e.scrollHeight; }
        function identity(value) {authenticated=Boolean(value);$loginMessage.toggle(!authenticated);$bar.toggleClass('ow-authenticated',authenticated);}
        function armExpiry() {
            window.clearTimeout(expiryTimer);
            if(!expiresAt)return;
            expiryTimer=window.setTimeout(function(){
                if(busy){expiryTimer=window.setTimeout(armExpiry,1000);return;}
                expire();
            },Math.max(100,expiresAt*1000-Date.now()));
        }
        function expire() {
            ++restoreSequence;ready=false;pending=false;conversation=null;token=null;expiresAt=0;
            window.clearTimeout(pendingTimer);window.clearTimeout(expiryTimer);
            if(animation)animation.cancel();
            $messages.empty();$('#ow-chat-input').val('');cache();controls();
            $notice.empty().text(tr('La sesión del chat ha terminado por seguridad. ','The chat session has ended for your privacy. '))
                .append($('<button type="button" class="ow-retry">').text(tr('Empezar de nuevo','Start again')).on('click',function(){bootstrap().then(function(){restore();}).catch(showSessionError);}));
        }
        function showSessionError(error) {$notice.text(publicError(error.message));controls();}
        async function bootstrap() {
            if(presentation.isEditing())return false;
            if(sessionPromise)return sessionPromise;
            sessionPromise=(async function(){
                var oldToken=token;
                var r=await fetch('/website_chat/session',{method:'POST',credentials:'same-origin',cache:'no-store',headers:headers()});
                if(!r.ok)throw new Error(await r.text());
                var state=await r.json();token=state.token;expiresAt=state.expires_at;idleSeconds=state.idle_seconds;
                identity(state.authenticated);lastTouch=Date.now();cache();armExpiry();
                if(oldToken && oldToken!==token){$messages.empty();conversation=null;ready=false;}
                return oldToken!==token;
            })();
            try{return await sessionPromise;}finally{sessionPromise=null;}
        }
        function touch() {
            if(presentation.isEditing())return;
            if(!token || busy || Date.now()-lastTouch<60000)return;
            bootstrap().then(function(changed){if(changed)restore();}).catch(function(){/* El siguiente envio comprobara la sesion. */});
        }
        var debugRecords = [];
        var debugEnabled = false;
        function diagnostic(values) {
            var safe = {};
            var allowed = ['request_message_count', 'published_metadata_visible', 'requested_model_id', 'profile_base_model_id', 'base_model_visible', 'profile_knowledge_count',
                'published_knowledge_count', 'published_builtin_tools_enabled', 'published_knowledge_tools_enabled',
                'effective_prompt_verified', 'effective_tools_verified', 'widget_revision', 'revision', 'request', 'phase', 'profile_read', 'profile_prompt_present',
                'configured_model_matches_profile', 'profile_is_preset', 'profile_parameters_visibility',
                'reason_code', 'requested_tokens', 'context_limit', 'credential_kind', 'poll_interval_ms', 'snapshots_received', 'progressive_updates',
                'updates_before_done', 'transport_stage', 'http_status', 'exception_type',
                'profile_parameters', 'parameter_overrides', 'system_messages_added', 'user_message_changed',
                'engine_effective_parameters', 'transport', 'elapsed_ms', 'first_text_ms', 'live_text_updates',
                'events_received', 'knowledge_calls', 'file_reads', 'tool_results', 'saved', 'code',
                'network_chunks', 'browser_first_text_ms', 'browser_elapsed_ms', 'messages_restored', 'pending'];
            allowed.forEach(function (key) { if (Object.prototype.hasOwnProperty.call(values, key)) safe[key] = values[key]; });
            if (debugRecords.length >= 60) debugRecords.shift();
            debugRecords.push(safe);
            if (debugEnabled && window.console && console.info) console.info('[TuxAIA]', JSON.stringify(safe));
        }
        window.TuxAIADebug = {
            presentation: function () { return presentation.status(); },
            snapshot: function () { return JSON.parse(JSON.stringify(debugRecords)); },
            clear: function () { debugRecords.length = 0; },
            setEnabled: function (value) { debugEnabled = Boolean(value); }
        };
        window.SlimAIADebug = window.TuxAIADebug; // Alias compatible con diagnosticos anteriores.
        diagnostic({revision: PROTOCOL, widget_revision: WIDGET_REVISION, phase: 'widget_loaded'});
        function render($target, text) {
            if (typeof marked === 'undefined' || !marked.parse) {
                $target.text(text).css('white-space', 'pre-wrap');
                return;
            }
            var template = document.createElement('template');
            template.innerHTML = marked.parse(text);
            var allowed = ['P', 'BR', 'STRONG', 'EM', 'B', 'I', 'UL', 'OL', 'LI', 'BLOCKQUOTE',
                'PRE', 'CODE', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'TABLE', 'THEAD', 'TBODY', 'TR', 'TH', 'TD', 'HR', 'A'];
            function clean(node, parent) {
                if (node.nodeType === 3) {
                    parent.appendChild(document.createTextNode(node.textContent));
                    return;
                }
                if (node.nodeType !== 1) return;
                if (['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'SVG', 'MATH', 'FORM', 'IMG'].indexOf(node.tagName) !== -1) return;
                var destination = parent;
                if (allowed.indexOf(node.tagName) !== -1) {
                    destination = document.createElement(node.tagName.toLowerCase());
                    if (node.tagName === 'A') {
                        var href = node.getAttribute('href') || '';
                        try {
                            var url = new URL(href, window.location.href);
                            if (['http:', 'https:', 'mailto:'].indexOf(url.protocol) !== -1) {
                                destination.setAttribute('href', url.href);
                                destination.setAttribute('rel', 'noopener noreferrer');
                            }
                        } catch (ignore) { /* enlace invalido: conservar solo el texto */ }
                    }
                    parent.appendChild(destination);
                }
                Array.prototype.forEach.call(node.childNodes, function (child) { clean(child, destination); });
            }
            var fragment = document.createDocumentFragment();
            Array.prototype.forEach.call(template.content.childNodes, function (node) { clean(node, fragment); });
            $target.empty().append(fragment);
        }

        function bubble(text, role) {
            var $element=$('<div>').addClass('ow-msg '+(role==='user'?'ow-msg-user':'ow-msg-bot'));
            if(role==='user')$element.text(text);else render($element,text);
            $messages.append($element);scroll();return $element;
        }
        function thinking($target) {
            // Los eventos de estado no reinician la animacion de puntos.
            if ($target.find('.ow-thinking').length) return;
            var $dots = $('<span class="ow-thinking-dots" aria-hidden="true">');
            for (var i=0;i<3;i++) $dots.append($('<span class="ow-thinking-dot">'));
            $target.empty().append($('<span class="ow-thinking" role="status">')
                .append(document.createTextNode(tr('TuxAIA está pensando','TuxAIA is thinking'))).append($dots));
        }
        // Cada bloque recibido se sanea una vez. Se conservan los nodos ya
        // mostrados y CSS revela solo los nuevos, sin bucles por caracter/frame.
        function reveal($target) {
            var raw=null;
            function clearEffects() {
                $target.find('.ow-reveal-fragment').removeClass('ow-reveal-fragment');
                $target.find('[data-ow-reveal-wrap]').each(function(){
                    var parent=this.parentNode;
                    while(this.firstChild)parent.insertBefore(this.firstChild,this);
                    parent.removeChild(this);parent.normalize();
                });
            }
            function animated(node, enabled) {
                if (!enabled || !node.textContent.trim()) return node;
                if (node.nodeType===3) {
                    var wrapper=document.createElement('span');
                    wrapper.setAttribute('data-ow-reveal-wrap','');wrapper.appendChild(node);node=wrapper;
                }
                if(node.nodeType===1)node.classList.add('ow-reveal-fragment');
                return node;
            }
            function compatible(a,b) {
                if(a.nodeType!==b.nodeType)return false;
                if(a.nodeType===3)return true;
                if(a.nodeType!==1 || a.tagName!==b.tagName || a.attributes.length!==b.attributes.length)return false;
                return Array.prototype.every.call(b.attributes,function(attr){return a.getAttribute(attr.name)===attr.value;});
            }
            function merge(parent,fresh,enabled) {
                var oldNodes=Array.from(parent.childNodes),newNodes=Array.from(fresh.childNodes);
                newNodes.forEach(function(node,index){
                    var old=oldNodes[index];
                    if(!old){parent.appendChild(animated(node.cloneNode(true),enabled));return;}
                    if(old.isEqualNode(node))return;
                    if(!compatible(old,node)){
                        parent.replaceChild(animated(node.cloneNode(true),enabled),old);return;
                    }
                    if(node.nodeType===3){
                        if(node.nodeValue.indexOf(old.nodeValue)===0){
                            var added=document.createTextNode(node.nodeValue.slice(old.nodeValue.length));
                            parent.insertBefore(animated(added,enabled),old.nextSibling);
                        } else {
                            // Markdown incompleto puede reinterpretarse al llegar
                            // su cierre. Corregirlo sin volver a animar texto viejo.
                            old.nodeValue=node.nodeValue;
                        }
                    } else merge(old,node,enabled);
                });
                oldNodes.slice(newNodes.length).forEach(function(node){parent.removeChild(node);});
            }
            $target.on('animationend.owReveal',function(event){
                var node=event.target;
                if(!node.classList || !node.classList.contains('ow-reveal-fragment'))return;
                node.classList.remove('ow-reveal-fragment');
                // Una clase vacia alteraria las comparaciones de atributos.
                if(!node.className)node.removeAttribute('class');
                if(node.hasAttribute('data-ow-reveal-wrap')){
                    var parent=node.parentNode;
                    while(node.firstChild)parent.insertBefore(node.firstChild,node);
                    parent.removeChild(node);parent.normalize();
                }
            });
            return {
                update:function(text){
                    if(text===raw)return;
                    clearEffects();
                    // Limpiar clases vacias dejadas por clearEffects.
                    $target.find('[class=""]').removeAttr('class');
                    if(raw===null)$target.empty();raw=text;
                    var fresh=$('<div>');render(fresh,text);
                    $target.css('white-space',fresh[0].style.whiteSpace || '');
                    var reduced=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                    merge($target[0],fresh[0],!reduced && !document.hidden && !$modal.hasClass('ow-hidden') && text.length<=30000);
                    scroll();
                },
                finish:function(){return Promise.resolve();},
                cancel:function(){clearEffects();$target.off('.owReveal');}
            };
        }
        async function restore(silent) {
            if (presentation.isEditing()) return;
            var sequence=++restoreSequence, selectedAgent=agent;
            window.clearTimeout(pendingTimer);ready=false;controls();
            if(!token){expire();return;}
            if(!agents[agent]){$messages.empty();$notice.text(tr('Soporte todavía no está disponible. Puedes hablar con Ventas.','Support is not available yet. You can talk to Sales.'));return;}
            $notice.text(tr('Recuperando conversación…','Restoring conversation…'));
            try {
                var response=await fetch('/website_chat/state?agent='+encodeURIComponent(selectedAgent),{credentials:'same-origin',cache:'no-store',headers:headers()});
                if(sequence!==restoreSequence)return;
                if(response.status===409){expire();return;}
                if(!response.ok)throw new Error(await response.text());
                var state=await response.json();if(sequence!==restoreSequence)return;
                if(state.revision!==PROTOCOL)throw new Error(tr('Actualiza el módulo y recarga: las versiones no coinciden.','Update the module and reload: versions do not match.'));
                if(!Array.isArray(state.messages))throw new Error('Invalid chat state');
                conversation=state.conversation_id;expiresAt=state.expires_at;idleSeconds=state.idle_seconds;identity(state.authenticated);
                $messages.empty();state.messages.forEach(function(message){bubble(message.error?publicError(message.content,message.error_code):message.content,message.role);});
                if(silent!==true)diagnostic({phase:'history_restored',messages_restored:state.messages.length,pending:state.pending});
                cache();armExpiry();
                pending=Boolean(state.pending);
                presentation.conversation(Boolean(state.messages.length || state.pending));
                if(state.pending){thinking($notice);pendingTimer=window.setTimeout(function(){if(sequence===restoreSequence)restore(true);},5000);return;}
                ready=true;$notice.text(state.association_pending?tr('Tu cuenta está iniciada. La vinculación del chat está pendiente.','You are signed in. Linking your chat is still pending.'):(state.messages.length?'':tr('Escribe tu consulta para empezar.','Type your question to get started.')));
            } catch(error) {
                if(sequence!==restoreSequence)return;
                $notice.empty().text(publicError(error.message)).append($('<button type="button" class="ow-retry">').text(tr('Reintentar','Retry')).on('click',function(){restore();}));
            } finally {if(sequence===restoreSequence)controls();}
        }
        async function send() {
            var text=$('#ow-chat-input').val();if(!text.trim() || busy || !ready || presentation.isEditing())return;
            if(Date.now()>=expiresAt*1000){expire();return;}
            $input[0].focus({preventScroll:true});
            presentation.conversation(true);
            busy=true;controls();$('#ow-chat-input').val('');bubble(text,'user');
            var $answer=bubble('','assistant');thinking($answer);
            var answer='',complete=false,reader,started=performance.now(),firstText=null,chunks=0;
            animation=reveal($answer);diagnostic({phase:'request_started'});$notice.empty();
            try {
                var form=new FormData();form.append('message',text);form.append('agent',agent);form.append('conversation_id',conversation);form.append('protocol',PROTOCOL);
                var response=await fetch('/website_chat/stream_message',{method:'POST',body:form,credentials:'same-origin',cache:'no-store',headers:headers()});
                if(!response.ok)throw new Error(await response.text());
                if(response.headers.get('X-OpenWebUI-Protocol')!==PROTOCOL)throw new Error(tr('Actualiza el controlador y recarga la web.','Update the controller and reload the website.'));
                if(!response.body)throw new Error(tr('El navegador no permite leer la respuesta progresiva.','Your browser cannot read the progressive response.'));
                reader=response.body.getReader();var decoder=new TextDecoder('utf-8'),buffer='';
                function process(line){
                    if(!line.trim())return;var event=JSON.parse(line);
                    if(event.type==='diagnostic'){diagnostic(event);return;}
                    if(event.type==='heartbeat')return;
                    if(event.type==='error'){var failure=new Error(event.text);failure.code=event.code;throw failure;}
                    if(event.type==='status'&&!answer)thinking($answer);
                    if(event.type==='delta'||event.type==='replace'){
                        if(firstText===null&&event.text)firstText=Math.round(performance.now()-started);
                        answer=event.type==='replace'?event.text:answer+event.text;animation.update(answer);
                    }
                    if(event.type==='done'){complete=true;if(!event.saved)$notice.text(tr('No se pudo guardar la respuesta.','The response could not be saved.'));}
                }
                while(true){var part=await reader.read();if(!part.done)chunks++;buffer+=decoder.decode(part.value||new Uint8Array(),{stream:!part.done});var newline;
                    while((newline=buffer.indexOf('\n'))!==-1){process(buffer.slice(0,newline));buffer=buffer.slice(newline+1);}if(part.done)break;}
                if(buffer.trim())process(buffer);if(!complete)throw new Error(tr('La respuesta se interrumpió antes de terminar. Recarga para recuperar su estado.','The response was interrupted. Reload to recover its state.'));
                await animation.finish();diagnostic({phase:'browser_completed',network_chunks:chunks,browser_first_text_ms:firstText,browser_elapsed_ms:Math.round(performance.now()-started)});
                // Una peticion al terminar renueva la caducidad, sin otra generacion.
                try { if(await bootstrap()) await restore(); } catch(ignore) { /* No sustituir una respuesta terminada por un fallo de renovacion. */ }
            } catch(error){
                if(animation)animation.cancel();if(reader){try{await reader.cancel();}catch(ignore){}}
                $answer.text(publicError(error.message,error.code));diagnostic({phase:'browser_error',code:'request_failed',network_chunks:chunks,browser_first_text_ms:firstText,browser_elapsed_ms:Math.round(performance.now()-started)});
            } finally {animation=null;busy=false;controls();scroll();armExpiry();}
        }
        async function resetChat(){
            if(busy || presentation.isEditing())return;
            var oldHeaders=headers();++restoreSequence;ready=false;pending=false;conversation=null;
            window.clearTimeout(pendingTimer);window.clearTimeout(expiryTimer);
            $messages.empty();$('#ow-chat-input').val('');token=null;expiresAt=0;cache();controls();
            $notice.text(tr('Iniciando una conversación nueva…','Starting a new conversation…'));
            try {await fetch('/website_chat/end',{method:'POST',credentials:'same-origin',cache:'no-store',headers:oldHeaders});await bootstrap();await restore();}
            catch(error){showSessionError(error);}
        }
        $reset.on('click',resetChat);
        $selector.on('change',function(){if(busy){$selector.val(agent);return;}agent=$selector.val();presentation.setAgent(agent);$messages.empty();$('#ow-chat-input').val('');cache();restore();});
        $login.on('click',function(event){if(busy){event.preventDefault();return;}openPreference='1';cache();});
        $('#openwebui-chat-button, #ow-chat-close').on('click',function(event){event.preventDefault();if(presentation.isEditing())return;if(presentation.handleClose(this.id))return;$modal.toggleClass('ow-hidden');openPreference=$modal.hasClass('ow-hidden')?'0':'1';cache();$launcher.attr('aria-expanded',openPreference==='1'?'true':'false');if(openPreference==='1'&&token){if(Date.now()>=expiresAt*1000)expire();else touch();}});
        $launcher.on('keydown',function(event){if(event.key==='Enter'||event.key===' '){event.preventDefault();$(this).trigger('click');}});
        $('#ow-chat-input').on('keydown',function(event){
            if(event.isComposing || (event.originalEvent && event.originalEvent.isComposing) || event.keyCode===229)return;
            if((event.key==='Enter'||event.keyCode===13)&&!event.shiftKey){event.preventDefault();send();}
        }).on('input',touch);
        $('#ow-chat-send').on('click',function(event){event.preventDefault();send();});
        // No conservar mensajes en una captura de pagina restaurable (bfcache).
        window.addEventListener('pagehide',function(){$messages.empty();$('#ow-chat-input').val('');});
        window.addEventListener('pageshow',function(event){if(event.persisted)restore(true);});
        window.addEventListener('focus',function(){if(token&&Date.now()-lastFocus>5000){lastFocus=Date.now();$messages.empty();restore(true);}});
        controls();
        $('#openwebui-chat-button, #openwebui-chat-modal').addClass('ow-enabled');
        agents=available;branding(available.project_url);
        presentation.init({config:available, agent:agent, tr:tr, resume:function(){bootstrap().then(function(){restore();}).catch(showSessionError);}});
        if(presentation.isEditing())return;
        try { await bootstrap();await restore(); } catch(error) { showSessionError(error); }
    });
});
