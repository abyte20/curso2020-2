odoo.define('website_openwebui_chat.editor_guard', function (require) {
    'use strict';
    var publicWidget = require('web.public.widget');
    require('website.content.snippets.animation');
    var presentation = require('website_openwebui_chat.presentation');
    publicWidget.registry.TuxAIAEditorGuard = publicWidget.Widget.extend({
        selector: '#wrapwrap',
        disabledInEditableMode: false,
        start: function () {
            presentation.setEditing(Boolean(this.editableMode));
            return this._super.apply(this, arguments);
        },
        destroy: function () {
            presentation.setEditing(true);
            return this._super.apply(this, arguments);
        }
    });
});
