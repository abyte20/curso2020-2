import hashlib
import json
import logging
import random
import secrets
import re
from datetime import datetime
import time
import uuid
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from odoo import http
from odoo.http import request
from werkzeug.wrappers import Response

_logger = logging.getLogger(__name__)
REVISION = 'native-profile-v6'

from .openwebui_transport import EventChannel, TransportError
from .private_debug import PrivateDebug


class IntegrationError(Exception):
    def __init__(self, message, status=502, code='integration_error', **diagnostic):
        super().__init__(message)
        self.status, self.code, self.diagnostic = status, code, diagnostic


def _turn_error(error):
    content = error.get('content', '') if isinstance(error, dict) else str(error or '')
    if not isinstance(content, str):
        content = str(content)
    match = re.search(r'request \((\d+) tokens\) exceeds the available context size \((\d+) tokens\)', content, re.I)
    if match:
        return IntegrationError('La conversación supera el contexto disponible del modelo. Inicia una nueva conversación con ↻; la anterior sigue guardada.',
                                code='context_limit', requested_tokens=int(match.group(1)), context_limit=int(match.group(2)))
    return IntegrationError('Open WebUI registró un error en este turno. Revisa su registro.', code='upstream_turn_error')


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _event(kind, **values):
    return (json.dumps(dict(type=kind, **values), ensure_ascii=False) + '\n').encode('utf-8')


def _output_text(output):
    parts = []
    for item in output or []:
        if not isinstance(item, dict) or item.get('type') != 'message':
            continue
        if item.get('role', 'assistant') != 'assistant':
            continue
        for part in item.get('content') or []:
            if isinstance(part, dict) and part.get('type') in ('output_text', 'text') and isinstance(part.get('text'), str):
                parts.append(part['text'])
    return '\n\n'.join(parts)


def _node_text(node):
    # En 0.11.4 el resultado final puede vivir solo en output.
    text = _output_text(node.get('output'))
    if text:
        return text
    if node.get('output') and node.get('done') is not True:
        return ''  # No publicar razonamiento o resultados de herramientas como respuesta.
    content = node.get('content')
    if isinstance(content, str) and content:
        return content
    if node.get('error'):
        return 'Open WebUI registró un error en este turno.'
    return ''


def _messages_from_chat(chat, for_model=False):
    history = chat.get('history') or {}
    nodes = history.get('messages') or {}
    current = history.get('currentId')
    result, seen = [], set()
    while current:
        if current in seen or current not in nodes:
            raise IntegrationError('El historial del chat está dañado.')
        seen.add(current)
        node = nodes[current]
        if node.get('role') in ('user', 'assistant'):
            text = _node_text(node)
            if text and not (for_model and node.get('error')):
                message = {'role': node['role'], 'content': text}
                if not for_model:
                    if node.get('error'):
                        message['error_code'] = _turn_error(node['error']).code
                    message.update(id=current, error=bool(node.get('error')),
                                   done=node.get('done', node['role'] == 'user'))
                result.append(message)
        current = node.get('parentId')
    return list(reversed(result))


class LiveOutput:
    """Reconstruye eventos de texto/instantaneas sin mostrar razonamiento ni herramientas."""
    def __init__(self):
        self.items = []
        self.text = ''
        self.done = False
        self.error = False
        self.events = 0
        self.knowledge_calls = set()
        self.file_reads = set()
        self.tool_outputs = set()

    def _item(self, index):
        while len(self.items) <= index:
            self.items.append({})
        return self.items[index]

    def apply(self, event):
        self.events += 1
        kind = event.get('type')
        data = event.get('data') or {}
        if not isinstance(data, dict):
            return self.text
        if kind == 'chat:message:error' or data.get('error'):
            self.error = True
        if kind in ('chat:completion', 'response:completion'):
            event_type = data.get('type', '')
            if isinstance(data.get('output'), list):
                self.items = data['output']
                self.text = _output_text(self.items)
            elif event_type.startswith('response.'):
                index = data.get('output_index', 0)
                if not isinstance(index, int) or index < 0 or index > 10000:
                    return self.text
                if event_type in ('response.output_item.added', 'response.output_item.done'):
                    self._item(index)
                    self.items[index] = data.get('item') or {}
                elif event_type in ('response.content_part.added', 'response.content_part.done',
                                    'response.output_text.delta', 'response.output_text.done'):
                    item = self._item(index)
                    item.setdefault('type', 'message')
                    item.setdefault('role', 'assistant')
                    parts = item.setdefault('content', [])
                    part_index = data.get('content_index', 0)
                    if not isinstance(part_index, int) or part_index < 0 or part_index > 10000:
                        return self.text
                    while len(parts) <= part_index:
                        parts.append({'type': 'output_text', 'text': ''})
                    if event_type.endswith('output_text.delta'):
                        parts[part_index]['text'] = parts[part_index].get('text', '') + data.get('delta', '')
                    elif event_type.endswith('output_text.done'):
                        parts[part_index]['text'] = data.get('text', parts[part_index].get('text', ''))
                    else:
                        parts[part_index] = data.get('part') or parts[part_index]
                elif event_type == 'response.completed' and isinstance((data.get('response') or {}).get('output'), list):
                    self.items = data['response']['output']
                # response.completed puede cerrar una ronda de herramientas.
                # Solo data.done en chat:completion finaliza el turno completo.
                self.text = _output_text(self.items)
            elif isinstance(data.get('content'), str):
                self.text = data['content']
            elif data.get('choices'):
                choice = data['choices'][0]
                value = (choice.get('delta') or choice.get('message') or {}).get('content')
                if isinstance(value, str):
                    self.text += value
            if data.get('done') is True:
                self.done = True
        elif kind in ('message', 'replace') and isinstance(data.get('content'), str):
            self.text = data['content'] if kind == 'replace' else self.text + data['content']
        for index, item in enumerate(self.items):
            if not isinstance(item, dict):
                continue
            identifier = item.get('call_id') or item.get('id') or str(index)
            if item.get('type') == 'function_call':
                if item.get('name') in ('search_knowledge_files', 'query_knowledge_files', 'query_knowledge_bases'):
                    self.knowledge_calls.add(identifier)
                if item.get('name') in ('view_file', 'view_knowledge_file'):
                    self.file_reads.add(identifier)
            elif item.get('type') == 'function_call_output':
                self.tool_outputs.add(identifier)
        return self.text

    def stats(self):
        return {'events_received': self.events, 'knowledge_calls': len(self.knowledge_calls),
                'file_reads': len(self.file_reads), 'tool_results': len(self.tool_outputs)}


class OpenWebUIClient:
    def __init__(self, url, api_key, model, timeout=150, cf_client_id='', cf_client_secret=''):
        self.url, self.model, self.timeout = url.rstrip('/'), model, timeout
        self.headers = {'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'}
        if bool(cf_client_id) != bool(cf_client_secret):
            raise IntegrationError('Configura los dos valores de Cloudflare Access en Ajustes > TuxAIA.', 503)
        if cf_client_id:
            if urlsplit(url).scheme != 'https' or any(ord(c) < 33 or ord(c) > 126 for c in cf_client_id + cf_client_secret):
                raise IntegrationError('Revisa la URL HTTPS y las credenciales de Cloudflare Access.', 503)
            self.headers.update({'CF-Access-Client-Id': cf_client_id, 'CF-Access-Client-Secret': cf_client_secret})
        self.opener = build_opener(NoRedirect())

    def _open(self, method, path, payload=None, timeout=25):
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8') if payload is not None else None
        req = Request(self.url + path, data=data, headers=self.headers, method=method)
        try:
            return self.opener.open(req, timeout=max(1, timeout))
        except HTTPError as exc:
            raise IntegrationError('Open WebUI: HTTP %s en %s' % (exc.code, path), exc.code, code='upstream_http', http_status=exc.code) from None
        except (URLError, OSError):
            raise IntegrationError('No se pudo conectar con Open WebUI.', code='upstream_connection') from None

    def _json(self, method, path, payload=None, timeout=25):
        with self._open(method, path, payload, timeout) as response:
            if 'text/event-stream' in response.headers.get('Content-Type', ''):
                raise IntegrationError('Open WebUI devolvió un formato inesperado.')
            try:
                return json.load(response)
            except ValueError:
                raise IntegrationError('Open WebUI devolvió un JSON inválido.') from None

    def _folder_id(self):
        name = getattr(self, 'folder_name', None)
        if not name:
            return None
        folders = self._json('GET', '/api/v1/folders/')
        if not isinstance(folders, list):
            raise IntegrationError('Open WebUI no devolvió una lista de carpetas válida.', 503)
        matches = [f for f in folders if isinstance(f, dict) and f.get('name') == name]
        if not matches:
            shared = self._json('GET', '/api/v1/folders/shared')
            if not isinstance(shared, list):
                raise IntegrationError('Open WebUI no devolvió una lista de carpetas compartidas válida.', 503)
            matches = [f for f in shared if isinstance(f, dict) and f.get('name') == name]
            if len(matches) == 1 and matches[0].get('permission') != 'write':
                raise IntegrationError('La clave API necesita permiso de escritura en la carpeta %s.' % name, 503)
        if len(matches) != 1 or not isinstance(matches[0].get('id'), str) or not matches[0]['id']:
            raise IntegrationError('Debe existir una única carpeta %s accesible para la clave API de Open WebUI.' % name, 503)
        return matches[0]['id']

    def _assign_folder(self, chat_id, record, folder_id):
        if folder_id and record.get('folder_id') != folder_id:
            result = self._json('POST', '/api/v1/chats/' + quote(chat_id, safe='') + '/folder',
                                {'folder_id': folder_id})
            if not isinstance(result, dict) or result.get('folder_id') != folder_id:
                raise IntegrationError('Open WebUI no confirmó la carpeta de la conversación.', 503)

    def prepare(self, reference, question, title):
        """Se ejecuta antes de enviar HTTP para que Odoo pueda guardar su sesion."""
        profile = self._json('GET', '/api/v1/models/model?' + urlencode({'id': self.model}))
        if profile.get('id') != self.model or not profile.get('base_model_id'):
            raise IntegrationError('Configura el ID exacto del perfil de Open WebUI, no el modelo base.', 503)
        # La web de Open WebUI carga esta lista; permite contrastar el perfil
        # publicado para ESTA credencial. Nunca enviar model_item.direct.
        published = self._json('GET', '/api/models')
        models = published.get('data', [])
        resolved = next((item for item in models if item.get('id') == self.model), None)
        if resolved is None:
            raise IntegrationError('El perfil configurado no está disponible para la clave API.', 503)
        folder_id = self._folder_id()
        chat_id = reference.get('chat_id') if reference else None
        chat = None
        if chat_id:
            try:
                record = self._json('GET', '/api/v1/chats/' + quote(chat_id, safe=''))
                chat = record.get('chat')
            except IntegrationError as exc:
                if exc.status != 404:
                    raise
                chat_id = None
            if chat_id:
                tasks = self._json('GET', '/api/tasks/chat/' + quote(chat_id, safe=''))
                current = ((chat.get('history') or {}).get('messages') or {}).get((chat.get('history') or {}).get('currentId')) or {}
                pending = current.get('done') is not True and current.get('odoo_pending_until', 0) > time.time()
                if tasks.get('task_ids') or pending:
                    raise IntegrationError('La respuesta anterior todavía está en curso.', 409)
        if not chat_id:
            chat = {'title': title, 'models': [self.model],
                    'history': {'currentId': None, 'messages': {}}, 'messages': []}
        if not isinstance(chat, dict):
            raise IntegrationError('Open WebUI no devolvió un chat válido.')
        # Asignar antes de añadir nodos pendientes: un fallo no deja un turno atascado.
        if chat_id:
            self._assign_folder(chat_id, record, folder_id)
        # El titulo identificativo no es una instruccion ni parte del historial.
        chat['title'] = title
        messages = _messages_from_chat(chat, for_model=True)
        messages.append({'role': 'user', 'content': question})
        history = chat.setdefault('history', {'currentId': None, 'messages': {}})
        nodes = history.setdefault('messages', {})
        previous = history.get('currentId')
        user_id, assistant_id = str(uuid.uuid4()), str(uuid.uuid4())
        now = int(time.time())
        user_node = {'id': user_id, 'parentId': previous, 'childrenIds': [assistant_id],
                     'role': 'user', 'content': question, 'models': [self.model], 'timestamp': now}
        assistant = {'id': assistant_id, 'parentId': user_id, 'childrenIds': [], 'role': 'assistant',
                     'content': '', 'model': self.model, 'modelName': self.model, 'modelIdx': 0,
                     'done': False, 'timestamp': now, 'odoo_pending_until': now + self.timeout + 60}
        if previous:
            nodes[previous].setdefault('childrenIds', []).append(user_id)
        nodes[user_id], nodes[assistant_id] = user_node, assistant
        history['currentId'] = assistant_id
        chat['messages'] = list(nodes.values())
        if chat_id:
            self._json('POST', '/api/v1/chats/' + quote(chat_id, safe=''), {'chat': chat})
        else:
            payload = {'chat': chat}
            if folder_id:
                payload['folder_id'] = folder_id
            created = self._json('POST', '/api/v1/chats/new', payload)
            chat_id = created.get('id')
            if not isinstance(chat_id, str) or not chat_id:
                raise IntegrationError('Open WebUI no devolvió el identificador del chat.')
        return {'chat_id': chat_id, 'assistant_id': assistant_id, 'user_node': user_node,
                'chat': chat, 'messages': messages, 'profile': profile, 'resolved_model': resolved, 'model_ids': [m.get('id') for m in models], 'trace': uuid.uuid4().hex[:12]}

    def _profile_diagnostic(self, ctx):
        params = ctx['profile'].get('params') or {}
        write_access = ctx['profile'].get('write_access')
        visibility = 'hidden_read_only' if write_access is False else ('visible' if write_access is True else 'not_confirmed')
        prompt_present = bool(params.get('system')) if write_access is True or params.get('system') else None
        names = ('temperature', 'top_k', 'top_p', 'min_p', 'max_tokens', 'num_ctx', 'seed',
                 'repeat_penalty', 'presence_penalty', 'frequency_penalty', 'stream_response',
                 'stream_delta_chunk_size')
        observed = {key: params[key] for key in names if isinstance(params.get(key), (int, float, bool))}
        if params.get('function_calling') in ('native', 'legacy'):
            observed['function_calling'] = params['function_calling']
        meta = ctx['profile'].get('meta') or {}
        runtime_meta = ((ctx.get('resolved_model') or {}).get('info') or {}).get('meta') or {}
        return {'revision': REVISION, 'request': ctx['trace'], 'phase': 'profile_read',
                'requested_model_id': self.model,
                'request_message_count': len(ctx['messages']),
                'published_metadata_visible': bool(runtime_meta),
                'profile_base_model_id': ctx['profile'].get('base_model_id'),
                'base_model_visible': ctx['profile'].get('base_model_id') in ctx.get('model_ids', []),
                'profile_knowledge_count': len(meta.get('knowledge') or []),
                'published_knowledge_count': len(runtime_meta.get('knowledge') or []) if runtime_meta else None,
                'published_builtin_tools_enabled': (runtime_meta.get('capabilities') or {}).get('builtin_tools', True),
                'published_knowledge_tools_enabled': (runtime_meta.get('builtinTools') or {}).get('knowledge', True),
                'effective_prompt_verified': False,
                'effective_tools_verified': False,
                'profile_read': True, 'profile_prompt_present': prompt_present,
                'profile_parameters_visibility': visibility,
                'configured_model_matches_profile': ctx['profile'].get('id') == self.model,
                'profile_is_preset': bool(ctx['profile'].get('base_model_id')),
                'profile_parameters': observed, 'parameter_overrides': [],
                'system_messages_added': 0, 'user_message_changed': False,
                'engine_effective_parameters': 'not_reported_by_api'}

    def _payload(self, ctx, session_id):
        # No params, system, tools ni modificacion de la pregunta.
        # Open WebUI 0.11.4 mezcla sus defaults con el perfil en main.py y
        # recupera del chat el historial y las salidas de herramientas.
        payload = {'model': self.model, 'messages': ctx['messages'], 'stream': True,
                   'chat_id': ctx['chat_id'], 'id': ctx['assistant_id'],
                   'user_message': ctx['user_node'], 'session_id': session_id,
                   'background_tasks': {'tags_generation': False,
                                        'follow_up_generation': False}}
        # Omitir title_generation: en 0.11.4 False aun renombra con la primera pregunta.
        # Usar la metadata publicada, como la UI: incluye defaults heredados
        # que el endpoint de edicion del perfil puede no contener.
        meta = ((ctx.get('resolved_model') or {}).get('info') or {}).get('meta')
        if not isinstance(meta, dict):
            meta = ctx['profile'].get('meta') or {}
        capabilities = meta.get('capabilities') or {}
        defaults = meta.get('defaultFeatureIds') or []
        payload['features'] = {key: key in defaults and capabilities.get(key, True)
                               for key in ('web_search', 'image_generation', 'code_interpreter', 'memory')}
        for source, destination in (('toolIds', 'tool_ids'), ('skillIds', 'skill_ids'),
                                    ('defaultFilterIds', 'filter_ids')):
            if meta.get(source):
                payload[destination] = meta[source]
        if meta.get('terminalId') and capabilities.get('terminal', True):
            payload['terminal_id'] = meta['terminalId']
        return payload

    def _chat(self, ctx):
        record = self._json('GET', '/api/v1/chats/' + quote(ctx['chat_id'], safe=''))
        chat = record.get('chat') or {}
        node = ((chat.get('history') or {}).get('messages') or {}).get(ctx['assistant_id']) or {}
        return chat, node

    def _mark_before_submission_error(self, ctx):
        # Solo se usa si no se ha solicitado generacion. Nunca sustituye una
        # respuesta del modelo por un error local de lectura de fuentes.
        chat, node = self._chat(ctx)
        if not node:
            return
        node.update(done=True, content='No se pudo iniciar la respuesta en Open WebUI.',
                    error={'content': 'turn_not_started'})
        chat['messages'] = list(chat['history']['messages'].values())
        self._json('POST', '/api/v1/chats/' + quote(ctx['chat_id'], safe=''), {'chat': chat})

    def _stream_snapshots(self, ctx):
        """La API HTTP admite claves API; overlay_response_streams publica texto en curso."""
        started = time.monotonic()
        deadline = started + self.timeout
        state = LiveOutput()
        displayed = ''
        first_text_ms = None
        updates, before_done, snapshots = 0, 0, 0
        diagnostic = self._profile_diagnostic(ctx)
        yield _event('status', text='TuxAIA está pensando…')
        yield _event('diagnostic', **diagnostic)
        yield _event('diagnostic', request=ctx['trace'], phase='transport_selected',
                     transport='http_live_snapshots', credential_kind='api_key', poll_interval_ms=1000)
        submitted = False
        stage = 'generation_submit'
        try:
            # session_id no autentica un socket: activa el flujo nativo HTTP.
            # La autorizacion de esta peticion sigue siendo la clave API.
            session_id = 'odoo-api-' + uuid.uuid4().hex
            submitted = True
            try:
                accepted = self._json('POST', '/api/chat/completions', self._payload(ctx, session_id))
            except IntegrationError as exc:
                if exc.status in (400, 401, 403, 404, 422):
                    submitted = False
                raise
            if not isinstance(accepted, dict) or accepted.get('status') is not True:
                submitted = False
                raise IntegrationError('Open WebUI no confirmó el inicio del turno.')
            yield _event('diagnostic', request=ctx['trace'], phase='generation_accepted')
            last_heartbeat = time.monotonic()
            while time.monotonic() < deadline:
                stage = 'chat_snapshot'
                _, node = self._chat(ctx)
                snapshots += 1
                if not node:
                    raise IntegrationError('Open WebUI no devolvió el turno solicitado.')
                if node.get('error'):
                    stage = 'model_response'
                    raise _turn_error(node['error'])
                if isinstance(node.get('output'), list) and node['output']:
                    state.apply({'type': 'chat:completion', 'data': {'output': node['output']}})
                text = _node_text(node)
                if text != displayed:
                    if first_text_ms is None and text:
                        first_text_ms = round((time.monotonic() - started) * 1000)
                        yield _event('diagnostic', request=ctx['trace'], phase='first_text', elapsed_ms=first_text_ms)
                    updates += 1
                    if node.get('done') is not True:
                        before_done += 1
                    if text.startswith(displayed):
                        yield _event('delta', text=text[len(displayed):])
                    else:
                        yield _event('replace', text=text)
                    displayed = text
                if node.get('done') is True:
                    stats = state.stats()
                    stats.pop('events_received', None)
                    yield _event('diagnostic', request=ctx['trace'], phase='completed',
                                 transport='http_live_snapshots', snapshots_received=snapshots,
                                 progressive_updates=updates, updates_before_done=before_done,
                                 first_text_ms=first_text_ms,
                                 elapsed_ms=round((time.monotonic() - started) * 1000), saved=True, **stats)
                    _logger.info('%s request=%s transport=http_live_snapshots snapshots=%s updates_before_done=%s',
                                 REVISION, ctx['trace'], snapshots, before_done)
                    yield _event('done', saved=True)
                    return
                if time.monotonic() - last_heartbeat > 5:
                    yield _event('heartbeat')
                    last_heartbeat = time.monotonic()
                # Una lectura a la vez, como maximo una por segundo. No hay
                # sondeo cuando termina el turno ni nuevas generaciones.
                time.sleep(1)
            raise IntegrationError('Se agotó el tiempo de espera. Recarga para recuperar el turno; no reenvíes todavía la pregunta.')
        except GeneratorExit:
            raise
        except Exception as exc:
            if not submitted:
                try:
                    self._mark_before_submission_error(ctx)
                except Exception:
                    pass
            _logger.warning('%s request=%s failure=%s', REVISION, ctx['trace'], type(exc).__name__)
            yield _event('diagnostic', request=ctx['trace'], phase='error', code='http_turn_failed',
                         transport='http_live_snapshots', exception_type=type(exc).__name__,
                         transport_stage=stage, reason_code=getattr(exc, 'code', 'internal_error'),
                         **getattr(exc, 'diagnostic', {}))
            yield _event('error', code=getattr(exc, 'code', 'internal_error'), text=str(exc) if isinstance(exc, IntegrationError) else 'Se interrumpió la consulta HTTP a Open WebUI.')

    def stream(self, ctx):
        credential = self.headers['Authorization'][7:]
        if credential.count('.') != 2:
            yield from self._stream_snapshots(ctx)
            return
        yield from self._stream_socket(ctx)

    def _stream_socket(self, ctx):

        started = time.monotonic()
        deadline = started + self.timeout
        channel = EventChannel(self, self.timeout)
        channel.chat_id, channel.message_id = ctx['chat_id'], ctx['assistant_id']
        state = LiveOutput()
        displayed = ''
        submitted = False
        first_text_ms = None
        text_updates = 0
        last_check = started
        try:
            yield _event('status', text='TuxAIA está pensando…')
            yield _event('diagnostic', **self._profile_diagnostic(ctx))
            channel.connect()
            yield _event('diagnostic', request=ctx['trace'], phase='events_connected', transport=channel.kind)
            submitted = True
            try:
                accepted = self._json('POST', '/api/chat/completions', self._payload(ctx, channel.session_id))
            except IntegrationError as exc:
                if exc.status in (400, 401, 403, 404, 422):
                    submitted = False
                raise
            if not isinstance(accepted, dict) or accepted.get('status') is not True:
                submitted = False
                raise IntegrationError('Open WebUI no confirmó el inicio del turno.')
            yield _event('diagnostic', request=ctx['trace'], phase='generation_accepted')
            while time.monotonic() < deadline:
                event = channel.get(timeout=1)
                if event and event.get('transport_error'):
                    # Recuperar una respuesta ya terminada es posible; no se
                    # presenta como streaming ni se vuelve a generar el turno.
                    _, node = self._chat(ctx)
                    if node.get('done') and not node.get('error'):
                        final = _node_text(node)
                        if final != displayed:
                            yield _event('replace', text=final)
                        yield _event('diagnostic', request=ctx['trace'], phase='recovered_after_disconnect',
                                     live_text_updates=text_updates)
                        yield _event('done', saved=True)
                        return
                    raise IntegrationError('Se interrumpió el canal de respuesta. Recarga para recuperar el turno guardado; no hace falta reenviar la pregunta.')
                if event and event.get('chat_id') == ctx['chat_id'] and event.get('message_id') == ctx['assistant_id'] and not event.get('internal'):
                    state.apply(event.get('data') or {})
                    if state.error:
                        raise _turn_error(state.error)
                    if state.text != displayed:
                        if first_text_ms is None and state.text:
                            first_text_ms = round((time.monotonic() - started) * 1000)
                            yield _event('diagnostic', request=ctx['trace'], phase='first_text', elapsed_ms=first_text_ms)
                        text_updates += 1
                        if state.text.startswith(displayed):
                            yield _event('delta', text=state.text[len(displayed):])
                        else:
                            yield _event('replace', text=state.text)
                        displayed = state.text
                    if state.done:
                        break
                if time.monotonic() - last_check > 5:
                    yield _event('heartbeat')
                    last_check = time.monotonic()
                    # Respaldo de finalizacion, no sondeo de tokens.
                    _, node = self._chat(ctx)
                    if node.get('error'):
                        raise _turn_error(node['error'])
                    if node.get('done'):
                        final = _node_text(node)
                        if final != displayed:
                            yield _event('replace', text=final)
                            displayed = final
                        break
            else:
                raise IntegrationError('Se agotó el tiempo de espera. El turno puede seguir en Open WebUI; recarga para recuperar su estado.')
            _, node = self._chat(ctx)
            if node.get('error'):
                raise _turn_error(node['error'])
            # Leer la forma persistida; no escribir ni sustituir el resultado.
            if node.get('done'):
                final = _node_text(node)
                if final != displayed:
                    yield _event('replace', text=final)
                    displayed = final
            diagnostic = dict(state.stats(), request=ctx['trace'], phase='completed',
                              first_text_ms=first_text_ms, live_text_updates=text_updates,
                              elapsed_ms=round((time.monotonic() - started) * 1000),
                              saved=bool(node.get('done')))
            _logger.info('%s request=%s events=%s updates=%s first_text_ms=%s knowledge_calls=%s file_reads=%s',
                         REVISION, ctx['trace'], state.events, text_updates, first_text_ms,
                         len(state.knowledge_calls), len(state.file_reads))
            yield _event('diagnostic', **diagnostic)
            yield _event('done', saved=bool(node.get('done')))
        except GeneratorExit:
            # Cerrar o recargar la web no cancela ni borra el turno remoto.
            raise
        except Exception as exc:
            public = str(exc) if isinstance(exc, IntegrationError) else 'No se pudo conectar con el canal de eventos de Open WebUI.'
            _logger.warning('%s request=%s failure=%s', REVISION, ctx['trace'], type(exc).__name__)
            if not submitted:
                try:
                    self._mark_before_submission_error(ctx)
                except Exception:
                    pass
            yield _event('diagnostic', request=ctx['trace'], phase='error',
                         code=exc.code if isinstance(exc, TransportError) else 'turn_failed',
                         transport_stage=getattr(exc, 'stage', None),
                         http_status=getattr(exc, 'http_status', None) or getattr(exc, 'diagnostic', {}).get('http_status'),
                         exception_type=getattr(exc, 'exception_type', type(exc).__name__),
                         reason_code=getattr(exc, 'code', 'internal_error'),
                         **dict(state.stats(), **{k: v for k, v in getattr(exc, 'diagnostic', {}).items() if k != 'http_status'}))
            yield _event('error', code=getattr(exc, 'code', 'internal_error'), text=public)
        finally:
            channel.close()


class OpenWebUIChatController(http.Controller):
    def _settings(self, agent='sales'):
        if agent not in ('sales', 'support'):
            raise IntegrationError('Agente inválido.', 400)
        ICP = request.env['ir.config_parameter'].sudo()
        if ICP.get_param('website_openwebui_chat.openwebui_active', 'True') not in ['True', 'true', '1']:
            raise IntegrationError('Chat desactivado.', 503)
        url = (ICP.get_param('website_openwebui_chat.openwebui_url', 'http://95.120.141.203:8036') or '').strip()
        key = (ICP.get_param('website_openwebui_chat.openwebui_api_key', '') or '').strip()
        model = (ICP.get_param('website_openwebui_chat.openwebui_sales_model', '') or ICP.get_param('website_openwebui_chat.openwebui_model', 'ventas-clone') or '').strip()
        if agent == 'support':
            model = (ICP.get_param('website_openwebui_chat.openwebui_support_model', '') or '').strip()
        parsed = urlsplit(url)
        if not key or not model or parsed.scheme not in ('http', 'https') or not parsed.netloc or parsed.username:
            raise IntegrationError('Revisa la URL, la clave y el modelo configurados en Odoo.', 503)
        try:
            timeout = max(30, int(ICP.get_param('website_openwebui_chat.openwebui_timeout', '240')))
        except (ValueError, TypeError):
            timeout = 240
        # La identidad se comprueba tambien tras iniciar/cerrar sesion: nunca
        # se restaura el chat de otra identidad a partir de datos del navegador.
        identity = '%s:%s' % (request.env.uid, request.website.id)
        signature = hashlib.sha256(('\0'.join((url, model, key, identity))).encode('utf-8')).hexdigest()
        client = OpenWebUIClient(url, key, model, timeout,
            cf_client_id=(ICP.get_param('website_openwebui_chat.cf_client_id', '') or '').strip(),
            cf_client_secret=(ICP.get_param('website_openwebui_chat.cf_client_secret', '') or '').strip())
        client.folder_name = 'Sales-folder' if agent == 'sales' else 'Support-folder'
        client.config_signature = hashlib.sha256(('\0'.join((url, model, key, str(request.website.id)))).encode('utf-8')).hexdigest()
        return client, signature

    def _idle_seconds(self):
        value = request.env['ir.config_parameter'].sudo().get_param('website_openwebui_chat.session_idle_minutes', '15')
        try:
            return max(5, min(120, int(value))) * 60
        except (TypeError, ValueError):
            return 900

    def _owner(self):
        return None if request.env.user._is_public() else request.env.uid

    def _token(self):
        token = request.httprequest.headers.get('X-SlimAIA-Session', '')
        return token if re.fullmatch(r'[a-f0-9]{64}', token) else None

    def _guard(self):
        # Los formularios de otros sitios no pueden poner esta cabecera.
        headers = request.httprequest.headers
        if headers.get('X-Requested-With') != 'XMLHttpRequest':
            raise IntegrationError('Peticion de chat no valida.', 403)
        origin = headers.get('Origin')
        if origin and urlsplit(origin).netloc.lower() != request.httprequest.host.lower():
            raise IntegrationError('Origen no permitido.', 403)

    def _store_tab(self, tab):
        tabs = dict(request.session.get('slimaia_tabs_v6') or {})
        tabs[tab['key']] = tab
        request.session['slimaia_tabs_v6'] = tabs

    def _tab(self, create=False, touch=False):
        self._guard()
        now = time.time()
        owner = self._owner()
        token = self._token()
        key = hashlib.sha256(token.encode('ascii')).hexdigest() if token else None
        tabs = dict(request.session.get('slimaia_tabs_v6') or {})
        tab = tabs.get(key)
        valid = bool(tab and tab.get('website_id') == request.website.id and
                     now - tab.get('last_activity', 0) < self._idle_seconds() and
                     (tab.get('owner_uid') == owner or tab.get('owner_uid') is None and owner is not None))
        if not valid:
            if key in tabs:
                tabs.pop(key)
                request.session['slimaia_tabs_v6'] = tabs
            if not create:
                raise IntegrationError('La sesion del chat ha terminado. Inicia una nueva conversacion.', 409)
            token = secrets.token_hex(32)
            key = hashlib.sha256(token.encode('ascii')).hexdigest()
            tabs = {k: v for k, v in tabs.items() if now - v.get('last_activity', 0) < self._idle_seconds()}
            while len(tabs) >= 12:
                tabs.pop(min(tabs, key=lambda k: tabs[k].get('last_activity', 0)))
            tab = {'key': key, 'website_id': request.website.id, 'owner_uid': owner,
                   'last_activity': now, 'agents': {}}
            request.session['slimaia_tabs_v6'] = tabs
        elif tab.get('owner_uid') is None and owner is not None:
            tab = dict(tab, owner_uid=owner, agents={a: dict(v, needs_association=True) for a, v in tab.get('agents', {}).items()})
        if touch:
            tab = dict(tab, last_activity=now)
        self._store_tab(tab)
        return tab, token

    def _active(self, signature, agent, tab, client):
        active = (tab.get('agents') or {}).get(agent) or {}
        if active.get('signature') != signature:
            if active.get('needs_association') and active.get('config_signature') == client.config_signature:
                active = dict(active, signature=signature)
            else:
                active = {'id': str(uuid.uuid4()), 'signature': signature,
                          'config_signature': client.config_signature}
        self._save_active(tab, agent, active)
        return active

    def _save_active(self, tab, agent, active):
        tab['agents'] = dict(tab.get('agents') or {}, **{agent: active})
        self._store_tab(tab)

    def _associate(self, tab):
        if self._owner() is None:
            return
        for agent, old in list(tab.get('agents', {}).items()):
            if not old.get('needs_association'):
                continue
            active = dict(old)
            reference = active.get('reference')
            if reference:
                try:
                    client, signature = self._settings(agent)
                    if active.get('config_signature') != client.config_signature:
                        continue
                    contact = {'user_id': request.env.uid, 'partner_id': request.env.user.partner_id.id,
                               'website_id': request.website.id, 'email': request.env.user.partner_id.email or ''}
                    # La API fusiona estas propiedades; no enviamos history ni
                    # messages y no sobrescribimos un turno que siga generando.
                    client._json('POST', '/api/v1/chats/' + quote(reference['chat_id'], safe=''),
                                 {'chat': {'title': self._desired_title(agent, active),
                                           'odoo_contact': contact}})
                    active['signature'] = signature
                except IntegrationError:
                    _logger.warning('%s account_association_pending agent=%s', REVISION, agent)
                    continue
            active.pop('needs_association', None)
            self._save_active(tab, agent, active)

    def _private_debug(self, client, ctx, agent, active, tab):
        ICP = request.env['ir.config_parameter'].sudo()
        if ICP.get_param('website_openwebui_chat.debug_logging', 'False') not in ('True', 'true', '1'):
            return None
        path = ICP.get_param('website_openwebui_chat.debug_log_path', '/var/log/odoo/slimaia_debug.log')
        dbname = request.env.cr.dbname
        def enabled():
            # El generador se ejecuta cuando el cursor de la peticion puede
            # estar cerrado. Cursor propio y sin cache para poder apagarlo.
            from odoo import registry
            with registry(dbname).cursor() as cr:
                cr.execute('SELECT value FROM ir_config_parameter WHERE key=%s', ('website_openwebui_chat.debug_logging',))
                row = cr.fetchone()
                return bool(row and row[0] in ('True', 'true', '1'))
        logger = PrivateDebug(path, enabled)
        params = ctx['profile'].get('params') or {}
        prompt = params.get('system') if isinstance(params.get('system'), str) else None
        include_prompt = ICP.get_param('website_openwebui_chat.debug_prompt', 'False') in ('True', 'true', '1')
        snapshot = client._profile_diagnostic(ctx)
        snapshot.update(agent=agent, chat_ref=hashlib.sha256(ctx['chat_id'].encode('utf-8')).hexdigest()[:20],
                        profile_source='OpenWebUI profile API; not provider request',
                        prompt_sha256=hashlib.sha256(prompt.encode('utf-8')).hexdigest() if prompt is not None else None,
                        prompt_characters=len(prompt) if prompt is not None else None)
        fingerprint = hashlib.sha256(json.dumps([params, include_prompt], sort_keys=True).encode('utf-8')).hexdigest()
        if active.get('debug_profile_hash') != fingerprint:
            snapshot['phase'] = 'profile_snapshot'
            if include_prompt and prompt is not None:
                redacted = prompt.replace(client.headers['Authorization'][7:], '[REDACTED_API_KEY]')
                for header in ('CF-Access-Client-Id', 'CF-Access-Client-Secret'):
                    if client.headers.get(header):
                        redacted = redacted.replace(client.headers[header], '[REDACTED_CLOUDFLARE]')
                snapshot.update(profile_prompt=redacted[:65536], prompt_truncated=len(redacted) > 65536,
                                prompt_redacted=redacted != prompt)
            if logger.write(snapshot):
                active['debug_profile_hash'] = fingerprint
                self._save_active(tab, agent, active)
        nodes = ((ctx['chat'].get('history') or {}).get('messages') or {}).values()
        output = [item for node in nodes for item in (node.get('output') or []) if isinstance(item, dict)]
        logger.write({'revision': REVISION, 'request': ctx['trace'], 'phase': 'turn_started', 'agent': agent,
                      'request_message_count': len(ctx['messages']),
                      'request_characters': sum(len(m.get('content', '')) for m in ctx['messages']),
                      'stored_tool_calls': sum(i.get('type') == 'function_call' for i in output),
                      'stored_tool_results': sum(i.get('type') == 'function_call_output' for i in output),
                      'system_messages_added': 0, 'parameter_overrides': [],
                      'engine_effective_parameters': 'not_reported_by_api'})
        return logger

    def _logged_stream(self, client, ctx, logger):
        for raw in client.stream(ctx):
            if logger and b'"type": "diagnostic"' in raw[:80]:
                event = json.loads(raw.decode('utf-8'))
                if event.get('phase') != 'profile_read':
                    logger.write(event)
            yield raw

    def _desired_title(self, agent, active, chat=None):
        if self._owner() is not None:
            active['title'] = self._title()
        elif not active.get('title'):
            nodes = ((chat or {}).get('history') or {}).get('messages') or {}
            timestamps = [n.get('timestamp') for n in nodes.values()
                          if n.get('role') == 'user' and isinstance(n.get('timestamp'), (int, float))]
            active['title'] = self._title(min(timestamps) if timestamps else None)
        # Migrar el título de sesiones v6.3 sin regenerar fecha ni sufijo.
        if self._owner() is None:
            for prefix in ('Ventas · ', 'Soporte · '):
                if active['title'].startswith(prefix):
                    active['title'] = active['title'][len(prefix):]
                    break
        return active['title']

    def _title(self, created_at=None):
        user = request.env.user
        if not user._is_public():
            return (user.partner_id.email or user.login or user.name).strip()
        import pytz  # Dependencia de Odoo 13.
        zone = request.env['ir.config_parameter'].sudo().get_param(
            'website_openwebui_chat.openwebui_timezone', 'Europe/Madrid')
        try:
            timezone = pytz.timezone(zone)
        except pytz.UnknownTimeZoneError:
            timezone = pytz.timezone('Europe/Madrid')
        moment = datetime.fromtimestamp(created_at, timezone) if created_at is not None else datetime.now(timezone)
        return moment.strftime('%d-%m-%Y_%H:%M:%S') + '_%03d' % random.SystemRandom().randrange(1000)

    def _error(self, exc):
        return Response(str(exc), status=exc.status if exc.status in (400, 401, 403, 409, 503) else 502,
                        content_type='text/plain; charset=utf-8', headers={'Cache-Control': 'no-store'})

    @http.route('/website_chat/is_active', type='json', auth='public', website=True, csrf=False)
    def is_active(self):
        ICP = request.env['ir.config_parameter'].sudo()
        return {'active': ICP.get_param('website_openwebui_chat.openwebui_active', 'True') in ['True', 'true', '1']}

    @http.route('/website_chat/agents', type='http', auth='public', website=True, methods=['GET'])
    def agents(self, **kwargs):
        ICP = request.env['ir.config_parameter'].sudo()
        active = ICP.get_param('website_openwebui_chat.openwebui_active', 'True') in ('True', 'true', '1')
        if not active:
            return Response(json.dumps({'active': False}), content_type='application/json', headers={'Cache-Control': 'no-store'})
        data = {'active': True, 'sales': bool((ICP.get_param('website_openwebui_chat.openwebui_sales_model', '') or ICP.get_param('website_openwebui_chat.openwebui_model', 'ventas-clone') or '').strip()),
                'support': bool((ICP.get_param('website_openwebui_chat.openwebui_support_model', '') or '').strip())}
        data['support_embedded'] = ICP.get_param('website_openwebui_chat.support_embedded', 'False') in ('True', 'true', '1')
        data['support_blocks'] = ICP.get_param('website_openwebui_chat.support_blocks', 'False') in ('True', 'true', '1')
        data['support_expand'] = ICP.get_param('website_openwebui_chat.support_expand', 'False') in ('True', 'true', '1')
        project_url = (ICP.get_param('website_openwebui_chat.project_url', '') or '').strip()
        try:
            parsed = urlsplit(project_url)
            if parsed.scheme in ('http', 'https') and parsed.hostname and not parsed.username and not parsed.password:
                data['project_url'] = project_url
        except ValueError:
            pass
        return Response(json.dumps(data), content_type='application/json', headers={'Cache-Control': 'no-store'})

    @http.route('/website_chat/session', type='http', auth='public', website=True, csrf=False, methods=['POST'])
    def chat_session(self, **kwargs):
        try:
            if not self.is_active()['active']:
                raise IntegrationError('Chat desactivado.', 503)
            tab, token = self._tab(create=True, touch=True)
            self._associate(tab)
            data = {'token': token, 'authenticated': self._owner() is not None,
                    'idle_seconds': self._idle_seconds(), 'expires_at': tab['last_activity'] + self._idle_seconds()}
            return Response(json.dumps(data), content_type='application/json', headers={'Cache-Control': 'no-store'})
        except IntegrationError as exc:
            return self._error(exc)

    @http.route('/website_chat/end', type='http', auth='public', website=True, csrf=False, methods=['POST'])
    def end_chat(self, **kwargs):
        try:
            self._guard()
            token = self._token()
            tabs = dict(request.session.get('slimaia_tabs_v6') or {})
            if token:
                tabs.pop(hashlib.sha256(token.encode('ascii')).hexdigest(), None)
            request.session['slimaia_tabs_v6'] = tabs
            return Response('{}', content_type='application/json', headers={'Cache-Control': 'no-store'})
        except IntegrationError as exc:
            return self._error(exc)

    @http.route('/website_chat/state', type='http', auth='public', website=True, methods=['GET'])
    def state(self, **kwargs):
        try:
            agent = kwargs.get('agent', 'sales')
            tab, token = self._tab()
            self._associate(tab)
            client, signature = self._settings(agent)
            active = self._active(signature, agent, tab, client)
            reference = active.get('reference')
            messages, pending = [], False
            if reference:
                try:
                    record = client._json('GET', '/api/v1/chats/' + quote(reference['chat_id'], safe=''))
                    chat = record.get('chat')
                    if not isinstance(chat, dict):
                        raise IntegrationError('No se pudo recuperar el historial.')
                    folder_ready = False
                    try:
                        client._assign_folder(reference['chat_id'], record, client._folder_id())
                        folder_ready = True
                    except IntegrationError:
                        _logger.warning('%s folder_assignment_pending agent=%s', REVISION, agent)
                    desired = self._desired_title(agent, active, chat)
                    if folder_ready and chat.get('title') != desired:
                        try:
                            client._json('POST', '/api/v1/chats/' + quote(reference['chat_id'], safe=''), {'chat': {'title': desired}})
                        except IntegrationError:
                            _logger.warning('%s title_update_pending agent=%s', REVISION, agent)
                    self._save_active(tab, agent, active)
                    messages = _messages_from_chat(chat)
                    nodes = (chat.get('history') or {}).get('messages') or {}
                    current = nodes.get((chat.get('history') or {}).get('currentId')) or {}
                    tasks = client._json('GET', '/api/tasks/chat/' + quote(reference['chat_id'], safe=''))
                    pending = bool(tasks.get('task_ids')) or (current.get('done') is not True and current.get('odoo_pending_until', 0) > time.time())
                except IntegrationError as exc:
                    if exc.status != 404:
                        raise
                    active = dict(active)
                    active.pop('reference', None)
                    self._save_active(tab, agent, active)
            data = {'conversation_id': active['id'], 'messages': messages, 'pending': pending, 'revision': REVISION, 'agent': agent,
                    'authenticated': self._owner() is not None, 'idle_seconds': self._idle_seconds(),
                    'expires_at': tab['last_activity'] + self._idle_seconds(),
                    'association_pending': any(a.get('needs_association') for a in tab['agents'].values())}
            return Response(json.dumps(data, ensure_ascii=False), content_type='application/json; charset=utf-8',
                            headers={'Cache-Control': 'no-store'})
        except IntegrationError as exc:
            return self._error(exc)

    @http.route('/website_chat/stream_message', type='http', auth='public', website=True, csrf=False, methods=['POST'])
    def stream_message(self, **post):
        params = dict(post, **request.params)
        if params.get('protocol') != REVISION:
            return Response('Actualiza el widget y recarga la página: versiones de controlador y widget distintas.', status=409)
        question = params.get('message')
        if not isinstance(question, str) or not question.strip():
            return Response('Mensaje vacío.', status=400)
        if len(question) > 16000:
            return Response('El mensaje es demasiado largo.', status=400)
        try:
            agent = params.get('agent', 'sales')
            tab, token = self._tab(touch=True)
            self._associate(tab)
            client, signature = self._settings(agent)
            active = self._active(signature, agent, tab, client)
            if params.get('conversation_id') != active['id']:
                raise IntegrationError('La sesión ha cambiado. Recarga la página para recuperar tu conversación.', 409)
            ctx = client.prepare(active.get('reference'), question, self._desired_title(agent, active))
        except IntegrationError as exc:
            _logger.error('%s preparación fallida: %s', REVISION, exc)
            return self._error(exc)
        active = dict(active, reference={'chat_id': ctx['chat_id']})
        # Guardar antes de crear la respuesta iterable: Odoo persiste su sesion
        # al cerrar la peticion, antes de consumir el generador de streaming.
        self._save_active(tab, agent, active)
        try:
            logger = self._private_debug(client, ctx, agent, active, tab)
        except Exception as exc:
            logger = None
            _logger.warning('%s private_debug_unavailable type=%s', REVISION, type(exc).__name__)
        return Response(self._logged_stream(client, ctx, logger), headers={
            'Cache-Control': 'no-cache, no-store, must-revalidate', 'X-Accel-Buffering': 'no',
            'X-OpenWebUI-Protocol': REVISION,
        }, content_type='application/x-ndjson; charset=utf-8', direct_passthrough=True)
