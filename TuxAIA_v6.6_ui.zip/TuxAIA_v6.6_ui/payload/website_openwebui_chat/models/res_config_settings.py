from odoo import fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    openwebui_active = fields.Boolean(
        string='Enable website chatbot',
        config_parameter='website_openwebui_chat.openwebui_active',
        default=True
    )
    openwebui_url = fields.Char(
        string='Open WebUI URL',
        config_parameter='website_openwebui_chat.openwebui_url',
        default="http://localhost:3000"
    )
    openwebui_api_key = fields.Char(
        string='Open WebUI API key',
        config_parameter='website_openwebui_chat.openwebui_api_key'
    )
    openwebui_model = fields.Char(
        string='Open WebUI model',
        config_parameter='website_openwebui_chat.openwebui_model',
        default="llama3"
    )
    openwebui_system_prompt = fields.Char(
        string='System prompt (Sales)',
        config_parameter='website_openwebui_chat.openwebui_system_prompt',
        default="Eres un asistente comercial cordial para nuestro ecommerce. Responde dudas sobre productos de forma breve y amable. No gestiones dinero ni inventes información."
    )
