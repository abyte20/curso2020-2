{
    "name": "Helpdesk MGMT Custom",
    "summary": "Slimbook Helpdesk MGMT Custom",
    "version": "13.0.1.0.1",
    "category": "Custom",
    "author": "Slimbook",
    "license": "AGPL-3",
    "website": "https://slimbook.com",
    "depends": [
        "helpdesk_mgmt",
    ],
    "data": [
        "views/support_content.xml",
        "views/helpdesk_ticket_templates.xml",
        "views/helpdesk_ticket_views.xml",
        "views/helpdesk_ticket_stage_views.xml",
        "views/res_config_settings_views.xml",
        "views/assets.xml"
    ],
    "installable": True
}