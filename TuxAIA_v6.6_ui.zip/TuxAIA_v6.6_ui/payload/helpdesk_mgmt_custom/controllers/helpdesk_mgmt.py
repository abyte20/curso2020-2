import base64
import logging

import werkzeug

import odoo.http as http
from odoo import _
from odoo.http import request
from odoo.tools import plaintext2html
from odoo.addons.helpdesk_mgmt.controllers.main import HelpdeskTicketController
from odoo.addons.portal.controllers.mail import PortalChatter, _message_post_helper
from odoo.osv import expression
from datetime import datetime

class HelpdeskPortalChatter(PortalChatter):
    @http.route(['/mail/chatter_post'], type='http', methods=['POST'], auth='public', website=True)
    def portal_chatter_post(self, res_model, res_id, message, redirect=None, attachment_ids='', attachment_tokens='', **kw):
        """Create a new `mail.message` with the given `message` and/or
        `attachment_ids` and redirect the user to the newly created message.

        The message will be associated to the record `res_id` of the model
        `res_model`. The user must have access rights on this target document or
        must provide valid identifiers through `kw`. See `_message_post_helper`.
        """

        url = redirect or (request.httprequest.referrer and request.httprequest.referrer + "#discussion") or '/my'

        res_id = int(res_id)

        attachment_ids = [int(attachment_id) for attachment_id in attachment_ids.split(',') if attachment_id]
        attachment_tokens = [attachment_token for attachment_token in attachment_tokens.split(',') if attachment_token]
        self._portal_post_check_attachments(attachment_ids, attachment_tokens)

        if message or attachment_ids:
            # message is received in plaintext and saved in html
            if message:
                message = plaintext2html(message)
            post_values = {
                'res_model': res_model,
                'res_id': res_id,
                'message': message,
                'send_after_commit': False,
                'attachment_ids': attachment_ids,
            }
            post_values.update((fname, kw.get(fname)) for fname in self._portal_post_filter_params())
            post_values['_hash'] = kw.get('hash')

            message = _message_post_helper(**post_values)

            if(res_model == 'helpdesk.ticket'):
                Ticket = request.env['helpdesk.ticket'].sudo().search([('id', '=', res_id)])
                Stage = request.env['helpdesk.ticket.stage'].sudo().search([('user_stage_changeable', '=', True)])

                if Ticket.stage_id in Stage:
                    Ticket.stage_id = request.env['helpdesk.ticket.stage'].sudo().search(["|", ('name', '=', "Awaiting"), ('name', '=', "En espera")]).id         

        return request.redirect(url)


class CustomHelpdeskTicketController(HelpdeskTicketController):

    @http.route(['/support', '/new/ticket'], type="http", auth="public", website=True)
    def create_new_ticket(self, **kw):
        res = super().create_new_ticket(**kw)
        res.qcontext.update({'page_name': 'new_ticket'})
        return res

        # categories = http.request.env["helpdesk.ticket.category"].search(
        #     [("active", "=", True)]
        # )
        # email = http.request.env.user.email
        # name = http.request.env.user.name

        # user_orders = request.env['sale.order'].sudo().search([('partner_id', '=', request.env.user.partner_id.id), ('invoice_status', '=', 'invoiced')])
        # user_orders = request.env['sale.order'].sudo().search([('partner_id', '=', request.env.user.partner_id.id)])

        # products = []
        # for record in user_orders:
        #     lines = record.order_line.mapped('product_template_id')
        #     for line in lines:
        #         products.append({'id':line.id, 'name':line.name})
        #         break

        # return http.request.render(
        #     "helpdesk_mgmt.portal_create_ticket",
        #     {
        #         "categories": categories,
        #         "teams": self._get_teams(),
        #         "email": email,
        #         "name": name,
        #         # "products": products
        #     },
        # )

    @http.route("/submitted/ticket", type="http", auth="user", website=True, csrf=True)
    def submit_ticket(self, **kw):
        category = http.request.env["helpdesk.ticket.category"].browse(
            int(kw.get("category"))
        )
        company = category.company_id or http.request.env.user.company_id
        
        order = kw.get('order')
        invoice = kw.get('invoice')
        lot = kw.get('lot')       

        vals = {
            "company_id": company.id,
            "category_id": category.id,
            #"description": plaintext2html(kw.get("description"))+"<br/>Nº de serie: "+plaintext2html(kw.get("serial"))+"<br/>" +plaintext2html(str(product.id)+" - "+product.name) ,
            "description": plaintext2html(kw.get("description")),
            "name": kw.get("subject"),
            "attachment_ids": False,
            "channel_id": request.env["helpdesk.ticket.channel"]
            .sudo()
            .search([("name", "=", "Web")])
            .id,
            "partner_id": request.env.user.partner_id.id,
            "partner_email": request.env.user.email,
            #"partner_name": company.name
            "partner_name": request.env.user.name,
            "priority": 0
        }
        if company.helpdesk_mgmt_portal_select_team:
            team = http.request.env["helpdesk.ticket.team"].search(
                [("id", "=", int(kw.get("team"))), ("show_in_portal", "=", True)]
            )
            vals.update({"team_id": team.id})

        if order:
            order_id = http.request.env['sale.order'].sudo().search([('name','=',order)])
            if order_id.id != False:
                vals.update({'order_id': order_id.id})
            else:
                vals.update({'order': order})

        if invoice:
            invoice_id = http.request.env['account.move'].sudo().search([('name','=',invoice)])
            if invoice_id.id != False:
                vals.update({'invoice_id': invoice_id.id})
            else:
                vals.update({'invoice': invoice})

        if lot:
            lot_id = http.request.env['stock.production.lot'].sudo().search([('name','=',lot)])
            if lot_id != False and len(lot_id) == 1:
                vals.update({'lot_id': lot_id.id})
            else:
                vals.update({'lot': lot})
        
        new_ticket = request.env["helpdesk.ticket"].sudo().create(vals)
        new_ticket.message_subscribe(partner_ids=request.env.user.partner_id.ids)
        if kw.get("attachment"):
            for c_file in request.httprequest.files.getlist("attachment"):
                data = c_file.read()
                if c_file.filename:
                    request.env["ir.attachment"].sudo().create(
                        {
                            "name": c_file.filename,
                            "datas": base64.b64encode(data),
                            "res_model": "helpdesk.ticket",
                            "res_id": new_ticket.id,
                        }
                    )
        return werkzeug.utils.redirect("/my/ticket/%s" % new_ticket.id)
