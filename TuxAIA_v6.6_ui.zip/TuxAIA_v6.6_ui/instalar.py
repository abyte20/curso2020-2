#!/usr/bin/env python3
"""Patch exact supplied Odoo modules, with preflight, backup and guarded restore."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import tempfile
from xml.etree import ElementTree

HERE = Path(__file__).resolve().parent
MODULES = ('helpdesk_mgmt_custom', 'website_openwebui_chat')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None

def target(root, rel):
    p = PurePosixPath(rel)
    if p.is_absolute() or '..' in p.parts or len(p.parts) < 2 or p.parts[0] not in MODULES:
        raise ValueError('Ruta no permitida: ' + rel)
    dst = root
    for part in p.parts:
        dst = dst / part
        if dst.is_symlink():
            raise ValueError('No se modifican enlaces simbólicos: ' + str(dst))
    if dst.exists() and not dst.is_file():
        raise ValueError('El destino no es un fichero: ' + str(dst))
    return dst

def atomic_write(dst, data, metadata):
    dst.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.tuxaia-', dir=str(dst.parent))
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        if os.geteuid() == 0:
            os.chown(name, metadata['uid'], metadata['gid'])
        os.chmod(name, metadata['mode'])
        os.replace(name, str(dst))
    finally:
        if os.path.exists(name):
            os.unlink(name)

def metadata(path):
    s = path.stat()
    return {'mode': stat.S_IMODE(s.st_mode), 'uid': s.st_uid, 'gid': s.st_gid}

def revert(root, backup, entries):
    for row in reversed(entries):
        dst = target(root, row['path'])
        if row['before'] is None:
            if dst.exists():
                dst.unlink()
        else:
            atomic_write(dst, (backup/'files'/row['path']).read_bytes(), row['metadata'])

def run():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', nargs='?', default='/home/od/odoo/slimbook')
    parser.add_argument('--check', action='store_true', help='Comprueba sin modificar nada')
    parser.add_argument('--restore', type=Path, help='Carpeta de copia impresa al instalar')
    args = parser.parse_args()
    root = Path(args.root).resolve(strict=True)
    if args.restore:
        backup = args.restore.resolve(strict=True)
        record = json.loads((backup/'backup.json').read_text())
        if record['root'] != str(root):
            raise ValueError('La copia corresponde a otra ruta')
        for row in record['files']:
            dst = target(root, row['path'])
            if digest(dst) not in (row['before'], row['after']):
                raise ValueError('Cambios posteriores; restauración cancelada: ' + row['path'])
            if row['before'] is not None and digest(backup/'files'/row['path']) != row['before']:
                raise ValueError('Copia incompleta o modificada: ' + row['path'])
        if not args.check:
            revert(root, backup, record['files'])
        print('Restauración comprobada.' if args.check else 'Ficheros restaurados. Reinicia Odoo y actualiza ambos módulos.')
        return
    manifest = json.loads((HERE/'manifest.json').read_text())
    for module in MODULES:
        if not (root/module/'__manifest__.py').is_file():
            raise ValueError('No se encuentra el módulo instalado: ' + module)
    pending = []
    for row in manifest['files']:
        dst = target(root, row['path'])
        src = target(HERE/'payload', row['path'])
        if digest(src) != row['after']:
            raise ValueError('Paquete incompleto o modificado: ' + row['path'])
        if src.suffix == '.py':
            ast.parse(src.read_text(encoding='utf-8'))
        elif src.suffix in ('.xml', '.svg'):
            ElementTree.parse(str(src))
        current = digest(dst)
        if current == row['after']:
            continue
        if current not in row['accepted_before']:
            raise ValueError('La versión instalada difiere de la revisada; no se sobrescribe: ' + row['path'])
        pending.append(dict(row, before=current))
    if args.check or not pending:
        print('Comprobación correcta. Ficheros pendientes: %d.' % len(pending))
        return
    backup = Path(tempfile.mkdtemp(prefix='tuxaia_v66_backup_'))
    record = {'root': str(root), 'files': []}
    for row in pending:
        dst = target(root, row['path'])
        info = dict(row)
        info['metadata'] = metadata(dst if dst.exists() else root/row['path'].split('/')[0])
        if not dst.exists():
            info['metadata']['mode'] = 0o644
        if row['before'] is not None:
            copy = backup/'files'/row['path']
            copy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(dst), str(copy))
        record['files'].append(info)
    (backup/'backup.json').write_text(json.dumps(record, indent=2))
    changed = []
    try:
        for row in record['files']:
            dst = target(root, row['path'])
            if digest(dst) != row['before']:
                raise ValueError('Cambio concurrente detectado: ' + row['path'])
            atomic_write(dst, (HERE/'payload'/row['path']).read_bytes(), row['metadata'])
            changed.append(row)
    except Exception:
        revert(root, backup, changed)
        raise
    print('Aplicados %d ficheros. Copia: %s' % (len(changed), backup))
    print('Reinicia Odoo y actualiza helpdesk_mgmt_custom y website_openwebui_chat.')
    print('Conserva la copia fuera de /tmp antes de que el servidor limpie temporales.')

if __name__ == '__main__':
    try:
        run()
    except Exception as exc:
        raise SystemExit('ERROR: ' + str(exc))
