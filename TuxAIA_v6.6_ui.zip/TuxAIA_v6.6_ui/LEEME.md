# TuxAIA 6.6-ui · Odoo 13

Actualización sobre los módulos facilitados, compatible con su versión original revisada (6.4) y con el parche 6.5-ui. Es un parche de archivos, no un módulo independiente. Mantiene la autoría y las licencias originales.

## Cambios

- Flotante cerrado: usa exactamente el `agent_icon.png` adjuntado por Alejandro. La cabecera conserva el pingüino de la versión anterior.
- Soporte incrustado: bienvenida compacta con imagen lateral, bocadillo y texto que aparece letra a letra una sola vez por pestaña. Se respeta la preferencia del navegador de reducir movimiento. Se puede escribir mientras aparece el saludo.
- Al enviar la primera consulta, el bloque despliega la conversación. Si ya hay mensajes en la sesión activa, se muestran directamente. Resetear vuelve a la bienvenida.
- Botón **Ampliar / Reducir**, con texto e icono SVG, visible al seleccionar **Soporte** y habilitarlo en los ajustes. No depende de FontAwesome. Funciona tanto en flotante como en incrustado; conserva borrador, conversación y estado de la animación al mover la ventana. Escape reduce la vista.
- Bloque nativo **TuxAIA · Soporte** en el editor del sitio web, categoría Funcionalidades. Se puede colocar en otras páginas. Si se colocan varios en una página, comparten un único chat que se mueve al bloque seleccionado; no se duplican conversaciones ni identificadores HTML.
- Aviso «Antes de abrir un ticket» visible, con una versión más breve del contenido anterior.
- Títulos, introducción y aviso separados en áreas editables de Odoo; su contenido inicial se carga una sola vez, para conservar las ediciones posteriores del administrador durante las actualizaciones. Los títulos iniciales se mantienen para que Alejandro los cambie.
- Controles públicos en español e inglés; ajustes y validaciones del backend con textos base ingleses y traducciones españolas.

La ampliación no crea una ruta nueva. Esta entrega no añade adjuntos al chatbot, no cambia el circuito de archivos de los tickets ni permite recuperar chats antiguos. El prompt, los parámetros de generación y el flujo de Open WebUI conservan la lógica de la 6.5.

## Instalación

Primero prueba en una copia de vuestro Odoo con su tema y vistas personalizados. Conserva una copia de seguridad de la base de datos antes de actualizar los módulos.

Sube el ZIP a `/home/od/`. Como usuario `od`:

```bash
cd /home/od
unzip TuxAIA_v6.6_ui.zip
cd TuxAIA_v6.6_ui
python3 instalar.py --check /home/od/odoo/slimbook
```

`--check` no modifica nada. Si detecta un archivo diferente de las versiones revisadas o un enlace simbólico en las rutas afectadas, se detiene. No fuerces la sobrescritura: compara primero ese cambio.

Con Odoo detenido mediante vuestro procedimiento habitual:

```bash
python3 instalar.py /home/od/odoo/slimbook
```

El instalador imprime la carpeta de copia `/tmp/tuxaia_v66_backup_...`. Conserva esa carpeta fuera de `/tmp`. El script solo cambia archivos; no reinicia Odoo ni modifica la base de datos.

Arranca Odoo y actualiza **ambos módulos** desde Aplicaciones:

- `website_openwebui_chat`
- `helpdesk_mgmt_custom`

Quita el filtro «Aplicaciones» para encontrarlos. No los desinstales. Después recarga el navegador sin caché. Esta actualización incorpora vistas, traducciones, assets y versiones nuevas en los manifiestos.

## Configurar y usar

En **Ajustes → TuxAIA → Presentación de Soporte**:

| Opción | Efecto |
| --- | --- |
| Mostrar Soporte en la página /support | Muestra u oculta el bloque automático de `/support` y su alias `/new/ticket`. No desactiva el flotante ni los bloques de otras páginas. |
| Activar los bloques de Soporte del editor | Activa los bloques que coloques manualmente en otras páginas. Nueva opción, desactivada inicialmente. |
| Permitir ampliar el chat de Soporte | Muestra Ampliar al seleccionar Soporte. No aparece al seleccionar Ventas. |

Las opciones existentes conservan su valor. El chat global debe estar activo y el ID de Soporte debe corresponder al perfil de Open WebUI. Si Open WebUI está detenido, ocultar un bloque no restablece la conexión del flotante: ambos utilizan ese servidor.

Para colocar el bloque: abre una página de Odoo, pulsa **Editar**, busca **TuxAIA · Soporte** en los bloques de Funcionalidades y arrástralo. Ajusta la bienvenida y guarda. Activa después la opción de bloques en Ajustes si todavía está apagada. En edición se muestra la estructura para editarla, incluso si está desactivada para visitantes.

Para editar títulos y el aviso de `/support`: entra como administrador del sitio web y pulsa **Editar**. Los encabezados y el aviso están en áreas de contenido separadas del formulario. Guarda los cambios y utiliza el modo de traducción de Odoo para el otro idioma. La bienvenida automática se edita en su plantilla compartida; los bloques arrastrados a otras páginas tienen su propia copia del texto.

El chat en ejecución se retira del área editable antes de que Odoo prepare o guarde la página: ni los mensajes ni el borrador se deben guardar como contenido web.

## Si no aparece Ampliar

1. Guarda «Permitir ampliar el chat de Soporte».
2. Selecciona **Soporte** en «Hablar con».
3. Comprueba que actualizaste ambos módulos y recarga sin caché.
4. Si persiste, abre la consola del navegador y ejecuta:

```javascript
TuxAIADebug.presentation()
```

Debe indicar `revision: "tuxaia-v6.6-ui"`, `agent: "support"`, `expand_enabled: true` y `expand_visible: true`. Este diagnóstico no contiene claves, tokens ni conversaciones. Permite distinguir una configuración desactivada o assets antiguos de un conflicto del tema. La causa concreta de la ausencia del botón en el servidor no se ha podido reproducir aquí; el nuevo control se ha comprobado también con una regla de tema que oculta los iconos de la cabecera.

## Restaurar

Con Odoo detenido, utiliza la ruta real de la copia:

```bash
python3 instalar.py --restore /ruta/a/tuxaia_v66_backup_XXXX /home/od/odoo/slimbook
```

Después arranca Odoo y actualiza ambos módulos. Se restauran los archivos originales y se eliminan los nuevos del parche. Si hay cambios posteriores, el script se detiene para no sobrescribirlos.

El instalador no revierte contenido que hayas editado en la base de datos: si has colocado bloques en páginas, retíralos antes de volver a una versión que no los admite, o restaura la copia de base de datos correspondiente. Las vistas de texto protegidas pueden permanecer en la base de datos sin ser utilizadas por la versión anterior.

## Pruebas y límites

Superado en este entorno:

- Sintaxis Python, JavaScript, XML/SVG y catálogos de traducción.
- XPath del formulario sobre la plantilla base OCA Helpdesk 13 y registro del bloque sobre el catálogo oficial de Odoo 13.
- Chromium: escritorio/móvil, español/inglés, invitado/cliente, compactación y expansión, campo de escritura, respuesta progresiva, foco, opciones independientes, historial de sesión ya existente y modo de movimiento reducido.
- Duplicación de bloques con un único chat y retirada del contenido dinámico al iniciar el ciclo de edición. Revisado contra los eventos reales de inicio/parada del editor de Odoo 13.
- Comparación del código: sesiones, autorización, historial y payload al perfil de Open WebUI no cambian. La cortinilla de 800 ms y el CSS original del widget se conservan. La imagen original se ha comparado byte a byte.
- Pruebas aisladas de sesión, propietario, sitio, caducidad, origen e identificadores manipulados.
- Instalador desde 6.4 y 6.5: comprobación, aplicación, repetición sin cambios, rechazo de modificaciones posteriores y restauración exacta de los archivos.

No se ha ejecutado una instancia real de vuestro Odoo ni una generación real de Open WebUI en este entorno. El editor completo, el envío de tickets y las traducciones importadas deben comprobarse en vuestra copia de pruebas antes de producción. Las capturas usan datos ficticios y una cabecera simplificada.

`Boceto_TuxAIA_v6.6.html` se abre directamente en un navegador. Es autónomo: anima la bienvenida, simula respuestas y permite ampliar; no conecta con Odoo ni envía tickets. La prueba no utiliza vuestra clave API.

Referencia del mecanismo de bloques: [documentación oficial de temas de Odoo 13](https://www.odoo.com/documentation/13.0/developer/howtos/themes.html).
