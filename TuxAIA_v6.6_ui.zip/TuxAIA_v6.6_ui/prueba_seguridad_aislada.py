"""Exercise actual controller methods in isolation; no Odoo or OpenWebUI server."""
import ast, hashlib, json, logging, re, secrets, time, uuid
from pathlib import Path
from types import SimpleNamespace as NS
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parent
source=ast.parse((ROOT/'payload/website_openwebui_chat/controllers/main.py').read_text())
cls=next(n for n in source.body if isinstance(n,ast.ClassDef) and n.name=='OpenWebUIChatController')
methods={'_owner','_token','_guard','_store_tab','_tab','_active','_save_active','stream_message'}
cls.bases=[];cls.body=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in methods]
for n in cls.body:n.decorator_list=[]
err=next(n for n in source.body if isinstance(n,ast.ClassDef) and n.name=='IntegrationError')
ns=globals();exec(compile(ast.fix_missing_locations(ast.Module(body=[err,cls],type_ignores=[])),'actual-controller','exec'),ns)
REVISION='native-profile-v6';_logger=logging.getLogger('test');_logger.disabled=True
c=OpenWebUIChatController();c._idle_seconds=lambda:900;c._associate=lambda tab:None
client=NS(config_signature='shared-config')
c._settings=lambda agent:(client,'shared-key-model-same-user')
c._error=lambda exc:exc
c._desired_title=lambda *a:'Test'
def req(session=None,uid=None,token='',site=1):
    global request
    request=NS(session={} if session is None else session,env=NS(uid=uid,user=NS(_is_public=lambda:uid is None)),website=NS(id=site),httprequest=NS(host='slimbook.test',headers={'X-Requested-With':'XMLHttpRequest','Origin':'https://slimbook.test','X-SlimAIA-Session':token}),params={})
    return request

def denied(fn,status=409):
    try:fn()
    except IntegrationError as e:assert e.status==status
    else:raise AssertionError('Request accepted')

# A stolen/guessed chat token without its Odoo session does not access a tab.
a=req();tab,token=c._tab(create=True);active=c._active('shared-key-model-same-user','support',tab,client)
req(token=token);denied(c._tab)
req(uid=5,token=token);denied(c._tab)
# Agent isolation even with the same API key/configuration signature.
req(a.session,token=token);tab,_=c._tab();sales=c._active('shared-key-model-same-user','sales',tab,client)
assert sales['id']!=active['id']
# Guest conversation may become associated only within the same Odoo session.
req(a.session,uid=5,token=token);tab,_=c._tab();assert tab['owner_uid']==5
assert tab['agents']['support']['needs_association']
# Account switch/logout/site change must not inherit the previous identity.
for uid,site in [(6,1),(None,1),(5,2)]:
    import copy
    req(copy.deepcopy(a.session),uid=uid,token=token,site=site);denied(c._tab)
req(a.session,uid=5,token=token);tab,_=c._tab();tab['last_activity']=time.time()-901;c._store_tab(tab);denied(c._tab)
# Cross-origin or missing AJAX header is rejected before session lookup.
req();request.httprequest.headers['Origin']='https://other.test';denied(lambda:c._tab(create=True),403)
req();request.httprequest.headers.pop('X-Requested-With');denied(lambda:c._tab(create=True),403)
# Client-supplied conversation and chat IDs never select a remote chat.
b=req(uid=7);tab,token=c._tab(create=True);request.httprequest.headers['X-SlimAIA-Session']=token
active=c._active('shared-key-model-same-user','support',tab,client)
active['reference']={'chat_id':'SERVER-OWNED'};c._save_active(tab,'support',active)
calls=[]
class StopPrepare(Exception):pass
def prepare(reference,*args):calls.append(reference);raise StopPrepare
client.prepare=prepare
p={'agent':'support','message':'Test','protocol':REVISION,'conversation_id':'FORGED','chat_id':'OTHER-USER'}
result=c.stream_message(**p);assert result.status==409 and not calls
p['conversation_id']=active['id']
try:c.stream_message(**p)
except StopPrepare:pass
else:raise AssertionError('Expected test boundary')
assert calls==[{'chat_id':'SERVER-OWNED'}]
# Chatter must validate/post using Odoo's helper before privileged stage access.
source=ast.parse((ROOT/'payload/helpdesk_mgmt_custom/controllers/helpdesk_mgmt.py').read_text())
m=source.body[next(i for i,n in enumerate(source.body) if isinstance(n,ast.ClassDef) and n.name=='HelpdeskPortalChatter')].body[0]
m.decorator_list=[]
exec(compile(ast.fix_missing_locations(ast.Module(body=[m],type_ignores=[])),'actual-chatter','exec'),ns)
checks=[]
class DenyEnv:
    def __getitem__(self,key):checks.append(key);raise AssertionError('Privileged access before authorization')
request=NS(env=DenyEnv(),httprequest=NS(referrer=None))
plaintext2html=lambda x:x
def _message_post_helper(**kw):raise PermissionError('denied')
self=NS(_portal_post_check_attachments=lambda *a:None,_portal_post_filter_params=lambda:[])
try:portal_chatter_post(self,'helpdesk.ticket',99,'Test')
except PermissionError:pass
else:raise AssertionError('Authorization failure was ignored')
assert not checks
print('PASS: session/identity/site/expiry/origin isolation, forged IDs, Support/Sales separation and chatter authorization ordering (isolated methods).')
