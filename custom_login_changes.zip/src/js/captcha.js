//REGISTER
$(".oe_signup_form").submit(function(event) {
    var recaptcha = $("#g-recaptcha-response").val();
    $('#err').hide();
    if (recaptcha === "") {
        event.preventDefault();
        $('#err').show();
     
        /*var $btn = $("form.oe_signup_form").find('.oe_login_buttons > button').eq(0);
        var interval = setInterval(() => {
            if ($("form").find('.oe_login_buttons > button > i').length) {
                $btn.enable();
                $btn.find('i').remove();
                clearInterval(interval)
            }
        }, 250);*/
     //$btn.enable();
     //$btn.find('i').remove();
     }
    else{
        return true;
    }
});

//LOGIN
$(".oe_login_form").submit(function(event) {
    var recaptcha = $("#g-recaptcha-response").val();
    if (recaptcha === "") {
        event.preventDefault();
        $("#err").show();
    }
    else{
        return true;
    }
});

//COMMON
function verifyRecaptchaCallback(response) {
    $('#err').hide();
    $('form button[type="submit"]').enable();
}
function expiredRecaptchaCallback(response) {
    $('#err').show();
}