Custom login
============
|

Slimbook Web Custom Login Screen
--------------------------------
|

Variants:
~~~~~~~~~
* Remove field labels
* Add warning text about to website renewal
* Add captcha (based on login_signup_captcha module for v12.0 by Cybrosys Technologies)