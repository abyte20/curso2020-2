odoo.define('website_openwebui_chat.widget', function (require) {
    'use strict';

    var ajax = require('web.ajax');
    var publicWidget = require('web.public_widget');

    publicWidget.registry.OpenWebUIChat = publicWidget.Widget.extend({
        selector: '#wrapwrap',
        events: {
            'click #openwebui-chat-button': '_toggleModal',
            'click #ow-chat-close': '_toggleModal',
            'click #ow-chat-send': '_sendMessage',
            'keypress #ow-chat-input': '_onKeyPress',
        },

        start: function () {
            var self = this;
            this.history = [];
            
            // Comprobar si está activo en la configuración
            ajax.jsonRpc('/website_chat/is_active', 'call', {}).then(function (data) {
                if (!data.active) {
                    $('#openwebui-chat-button').addClass('ow-hidden');
                }
            });

            return this._super.apply(this, arguments);
        },

        _toggleModal: function () {
            $('#openwebui-chat-modal').toggleClass('ow-hidden');
        },

        _onKeyPress: function (ev) {
            if (ev.which === 13) {
                this._sendMessage();
            }
        },

        _sendMessage: function () {
            var self = this;
            var $input = $('#ow-chat-input');
            var message = $input.val().trim();

            if (!message) return;

            $input.val('');
            this._appendMessage(message, 'user');

            var $messages = $('#ow-chat-messages');
            var $loadingMsg = $('<div class="ow-msg ow-msg-bot"><i>Pensando...</i></div>');
            $messages.append($loadingMsg);
            $messages.scrollTop($messages[0].scrollHeight);

            ajax.jsonRpc('/website_chat/send_message', 'call', {
                message: message,
                history: this.history
            }).then(function (data) {
                $loadingMsg.remove();
                if (data.error) {
                    self._appendMessage(data.error, 'bot');
                } else if (data.response) {
                    self._appendMessage(data.response, 'bot');
                    self.history.push({role: 'user', content: message});
                    self.history.push({role: 'assistant', content: data.response});
                }
            }).catch(function () {
                $loadingMsg.remove();
                self._appendMessage("Error de conexión.", 'bot');
            });
        },

        _appendMessage: function (text, sender) {
            var $messages = $('#ow-chat-messages');
            var msgClass = sender === 'user' ? 'ow-msg-user' : 'ow-msg-bot';
            var $msg = $('<div>').addClass('ow-msg ' + msgClass).text(text);
            $messages.append($msg);
            $messages.scrollTop($messages[0].scrollHeight);
        }
    });
});
