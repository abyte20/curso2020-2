import json
import logging
import requests
from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)

class OpenWebUIChatController(http.Controller):

    @http.route('/website_chat/is_active', type='json', auth='public', website=True, csrf=False)
    def is_active(self):
        ICP = request.env['ir.config_parameter'].sudo()
        is_active = ICP.get_param('website_openwebui_chat.openwebui_active', 'True')
        return {'active': is_active in ['True', 'true', '1']}

    @http.route('/website_chat/send_message', type='json', auth='public', website=True, csrf=False)
    def send_message(self, message, history=None):
        if not message:
            return {'error': 'Mensaje vacío'}

        ICP = request.env['ir.config_parameter'].sudo()
        url = (ICP.get_param('website_openwebui_chat.openwebui_url', 'http://localhost:3000') or '').rstrip('/')
        api_key = ICP.get_param('website_openwebui_chat.openwebui_api_key', '')
        model = ICP.get_param('website_openwebui_chat.openwebui_model', 'llama3')
        system_prompt = ICP.get_param(
            'website_openwebui_chat.openwebui_system_prompt',
            'Eres un asistente comercial de ventas.'
        )

        endpoint = f"{url}/api/v1/chat/completions"

        headers = {'Content-Type': 'application/json'}
        if api_key:
            headers['Authorization'] = f"Bearer {api_key}"

        messages = [{"role": "system", "content": system_prompt}]
        if history and isinstance(history, list):
            for h in history:
                messages.append({"role": h.get("role", "user"), "content": h.get("content", "")})
        
        messages.append({"role": "user", "content": message})

        payload = {
            "model": model,
            "messages": messages,
            "temperature": 0.7,
            "stream": False
        }

        try:
            response = requests.post(endpoint, json=payload, headers=headers, timeout=15)
            if response.status_code == 200:
                data = response.json()
                answer = data.get('choices', [{}])[0].get('message', {}).get('content', 'Sin respuesta.')
                return {'response': answer}
            else:
                _logger.error("Error OpenWebUI %s: %s", response.status_code, response.text)
                return {'error': f"Error en el servidor OpenWebUI ({response.status_code})"}
        except Exception as e:
            _logger.exception("Error de conexión con OpenWebUI")
            return {'error': 'No se pudo conectar con el asistente de chat.'}
