{
    'name': 'Website Open WebUI Chatbot',
    'summary': 'Chatbot flotante informativo de ventas conectado a Open WebUI',
    'category': 'Website',
    'version': '13.0.1.0.0',
    'depends': ['website'],
    'data': [
        'views/res_config_settings_views.xml',
        'views/templates.xml',
    ],
    'installable': True,
    'application': False,
}
