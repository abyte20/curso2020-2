# Copyright 2018-2022 Sodexis
# License OPL-1 (See LICENSE file for full copyright and licensing details).

{
    'name': "Restrict Invoice Delete",
    'summary': """
        This module will allow us to restrict the deletion of Invoice
         records based on a group.
        """,
    'description': """ Invoice can not be deleted unless you have the specific access rights. """,
    'version': "15.0.1.0.0",
    'category': 'Uncategorized',
    'website': "http://sodexis.com/",
    'author': "Sodexis",
    'license': 'OPL-1',
    'installable': True,
    'application': False,
    'depends': [
        'account',
    ],
    'data': [
        'security/security.xml',
        'views/account_invoice_view.xml',
    ],
    'images': ['images/main_screenshot.png'],
}
