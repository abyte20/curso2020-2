=======================
Restrict Invoice Delete
=======================

This module helps to restrict the delete option for Invoice.

Contributors
------------

* Sodexis, Inc <dev@sodexis.com>
