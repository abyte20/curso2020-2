# TuxAIA 6.5-ui · Odoo 13 · versión de prueba

Parche sobre los dos módulos instalados facilitados: `website_openwebui_chat` y `helpdesk_mgmt_custom`. No es un módulo independiente ni una instalación completa. Conserva los manifiestos, autoría y archivos ajenos a los 13 cambios del paquete.

## Qué incluye

- `/support` y `/new/ticket`: formulario en tarjeta, campos ordenados en dos columnas, bordes suaves, espacios más amplios y botones azules. Los tickets activos aparecen al lado; en móvil, debajo. Los avisos largos se conservan en «Antes de abrir un ticket».
- Vista sin identificar: tarjeta de acceso y registro; conserva el requisito de iniciar sesión para abrir un ticket.
- Chat de Soporte incrustado sobre el formulario, activable desde configuración. Si falta el modelo de Soporte, el bloque incrustado no aparece.
- Ampliar/reducir Soporte: reutiliza el mismo elemento y mantiene mensajes y borrador. También puede habilitarse para el flotante. Ventas no ofrece este botón.
- Un solo pingüino visible: al abrir el chat se oculta el lanzador. Se mantienen cabecera, selector «Hablar con», aviso, animación de respuesta y funcionamiento del campo de escritura del widget recibido.
- Dos opciones de presentación nuevas, inicialmente desactivadas. El diseño del formulario sí se aplica al actualizar Helpdesk.
- Ajuste acotado del controlador de comentarios de tickets: el helper estándar de Odoo valida/publica el mensaje antes de acceder con privilegios al cambio de etapa. No se atribuye una explotación al orden anterior.

No incluye todavía subida de archivos al chatbot, botones que prometan adjuntos, comprobación de compra facturada ni recuperación de chats antiguos. Los archivos del formulario de tickets siguen su circuito anterior; no se envían al chatbot. No cambia la KB ni crea una KB por cliente.

## Instalación

Haz primero la prueba en una copia de Odoo 13 con los mismos módulos, tema y vistas. Los controles automáticos de este paquete no sustituyen una actualización real de Odoo.

1. Descomprime este ZIP y entra en la carpeta `TuxAIA_v6.5_ui`.
2. Como usuario `od`, comprueba las versiones antes de cambiar nada:

```bash
python3 instalar.py --check /home/od/odoo/slimbook
```

El instalador compara los archivos con las versiones facilitadas. Si detecta cambios posteriores o enlaces simbólicos en las rutas que modificaría, se detiene. No elimines esa protección: habrá que comparar la nueva versión.

3. Con Odoo detenido mediante vuestro procedimiento habitual, aplica el parche:

```bash
python3 instalar.py /home/od/odoo/slimbook
```

El script crea una copia de los archivos afectados e imprime su ruta `/tmp/tuxaia_v65_backup_...`. Conserva esa carpeta fuera de `/tmp` para evitar su limpieza automática. El script no modifica la base de datos ni reinicia servicios.

4. Reinicia Odoo y actualiza **ambos módulos**, `helpdesk_mgmt_custom` y `website_openwebui_chat`, desde Aplicaciones. Después recarga el navegador sin caché. Conserva la copia de seguridad habitual de la base de datos antes de actualizar módulos.
5. En la configuración de TuxAIA, grupo **Presentación de Soporte**, activa las opciones de incrustar en `/support` y/o ampliar. Debe estar configurado el ID del modelo de Soporte. Guarda los ajustes.

## Comprobación en vuestro servidor

- Invitado y cliente: `/support`, enlaces de acceso, envío de un ticket de prueba y tickets que le pertenecen.
- Chat flotante, incrustado y ampliado: Ventas/Soporte, envío real, animación, foco, conservar borrador al ampliar y cerrar/reabrir.
- Dos usuarios en navegadores separados: cada uno ve únicamente su conversación y sus tickets. Cerrar sesión y entrar con otra cuenta no recupera la conversación de la primera.
- Opciones desactivadas: el formulario sigue modernizado y el chat funciona como flotante.

## Restaurar

Con Odoo detenido, usa la ruta real de la copia impresa al instalar:

```bash
python3 instalar.py --restore /ruta/a/tuxaia_v65_backup_XXXX /home/od/odoo/slimbook
```

Se restauran los archivos originales y se eliminan los archivos nuevos del parche. Si un archivo fue editado después, el script se detiene para no perder esos cambios. Después reinicia Odoo y actualiza de nuevo ambos módulos para restaurar las vistas y los assets en la base de datos. Los parámetros de presentación sobrantes no se utilizan por la versión anterior.

## Seguridad y límites de esta entrega

La clave compartida de Open WebUI no aísla por sí sola a los clientes. La versión recibida conserva en la sesión de Odoo la referencia del chat y valida token, usuario, sitio y caducidad. El navegador no selecciona directamente un `chat_id` remoto. Se han comprobado esos métodos reales con dependencias simuladas, sin alterar su lógica.

Esto no equivale a una auditoría completa ni a una prueba de penetración contra vuestra instalación. La cuenta de Open WebUI que posee los chats continúa teniendo acceso a ellos. Su clave debe permanecer en el servidor.

Pendiente para la fase de adjuntos: autorización de cliente con pedido facturado, límites configurables por archivo/petición, comprobación del contenido y tipo real, imágenes de máximo 1–2 MB según la configuración elegida, archivos privados con control de propietario, cuotas y tratamiento de contenido no confiable. No basta con limitar tamaño en JavaScript.

En el controlador de tickets recibido, la etiqueta «máximo 10 MB» no va acompañada de una comprobación explícita del tamaño antes de leer el archivo. No se ha cambiado ese circuito en esta entrega visual; habrá que revisar sus límites efectivos de servidor/proxy y validaciones al trabajar los adjuntos. Ese límite del formulario es distinto del futuro límite del chatbot.

## Validación realizada

- Sintaxis Python, XML y SVG; aplicación de los XPath sobre la plantilla base OCA Helpdesk 13.
- Chromium: 1280 y 390 px, invitado/cliente, expansión sin peticiones adicionales ni nueva conversación, borrador, foco, renderizado incremental simulado, selector y opciones de configuración.
- Contrato del formulario: ruta de envío, campos, CSRF y formulario multipart conservados.
- Métodos reales del controlador en aislamiento: separación de sesión/identidad/sitio, caducidad, origen, separación Ventas/Soporte, identificadores manipulados y autorización antes del cambio de etapa.
- Instalador: comprobación, aplicación, segunda ejecución, conservación de manifiestos/autoría, rechazo de cambios posteriores y restauración.

Las capturas de `vistas/` son pruebas locales con API y datos simulados, Bootstrap de referencia y cabecera simplificada. No son capturas del servidor de producción. No se ha ejecutado Odoo 13 ni Open WebUI real en este entorno.
