from odoo import api, fields, models, _
from odoo.exceptions import AccessError, ValidationError
import os
import json
from lxml import etree
from urllib.parse import urlsplit


class TuxAIASettings(models.TransientModel):
    _inherit = 'res.config.settings'

    # Odoo 13 elimina un parametro al guardar False; default=True lo reactiva.
    # Desactivar el guardado automatico y leer/escribir ambos estados expresamente.
    openwebui_active = fields.Boolean(string='Activar Chatbot en la Web',
        config_parameter='website_openwebui_chat.openwebui_active', default=True)
    tuxaia_cf_client_id = fields.Char(string='Cloudflare Access Client ID',
        config_parameter='website_openwebui_chat.cf_client_id', groups='base.group_system')
    tuxaia_cf_client_secret = fields.Char(string='Cloudflare Access Client Secret',
        config_parameter='website_openwebui_chat.cf_client_secret', groups='base.group_system')

    @api.model
    def _get_classified_fields(self):
        classified = super(TuxAIASettings, self)._get_classified_fields()
        # En 13.0 se comprueba hasattr(config_parameter), no su valor: None
        # no desactiva el mecanismo. Excluir solo esta casilla de la lista.
        classified['config'] = [(name, key) for name, key in classified['config']
                                if name != 'openwebui_active']
        if 'openwebui_active' not in classified['other']:
            classified['other'].append('openwebui_active')
        return classified

    @api.model
    def get_values(self):
        values = super(TuxAIASettings, self).get_values()
        params = self.env['ir.config_parameter'].sudo()
        for field, key, default in (
                ('openwebui_active', 'openwebui_active', 'True'),
                ('slimaia_debug_logging', 'debug_logging', 'False'),
                ('slimaia_debug_prompt', 'debug_prompt', 'False')):
            values[field] = params.get_param('website_openwebui_chat.' + key, default) in ('True', 'true', '1')
        return values

    def _cloudflare_values(self):
        client_id = (self.tuxaia_cf_client_id or '').strip()
        secret = (self.tuxaia_cf_client_secret or '').strip()
        if bool(client_id) != bool(secret):
            raise ValidationError(_('Rellena Client ID y Client Secret, o deja ambos vacios.'))
        if any(ord(c) < 33 or ord(c) > 126 for c in client_id + secret):
            raise ValidationError(_('Las credenciales de Cloudflare no admiten espacios ni saltos de linea.'))
        if client_id and urlsplit((self.openwebui_url or '').strip()).scheme != 'https':
            raise ValidationError(_('Usa una URL HTTPS de Open WebUI para enviar las credenciales de Cloudflare.'))
        return {'cf_client_id': client_id, 'cf_client_secret': secret}

    def set_values(self):
        self.ensure_one()
        self._cloudflare_values()
        result = super(TuxAIASettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param(
            'website_openwebui_chat.openwebui_active', 'True' if self.openwebui_active else 'False')
        return result

    slimaia_sales_model_id = fields.Char(string='Modelo de Ventas (ID)',
        config_parameter='website_openwebui_chat.openwebui_sales_model',
        help='ID exacto del perfil Open WebUI. Vacio conserva el modelo general anterior.')
    slimaia_support_model_id = fields.Char(string='Modelo de Soporte (ID)',
        config_parameter='website_openwebui_chat.openwebui_support_model')
    slimaia_debug_logging = fields.Boolean(string='Activar registro privado de diagnostico',
        config_parameter='website_openwebui_chat.debug_logging', default=False)
    slimaia_debug_prompt = fields.Boolean(string='Incluir el prompt del perfil si la API permite leerlo',
        config_parameter='website_openwebui_chat.debug_prompt', default=False)
    slimaia_debug_path = fields.Char(string='Archivo del registro',
        config_parameter='website_openwebui_chat.debug_log_path', default='/var/log/odoo/slimaia_debug.log')
    slimaia_idle_minutes = fields.Integer(string='Caducidad del chat por inactividad (minutos)',
        config_parameter='website_openwebui_chat.session_idle_minutes', default=15)

    tuxaia_support_embedded = fields.Boolean(string='Mostrar Soporte en la página /support',
        config_parameter='website_openwebui_chat.support_embedded', default=False)
    tuxaia_support_expand = fields.Boolean(string='Permitir ampliar el chat de Soporte',
        config_parameter='website_openwebui_chat.support_expand', default=False)

    tuxaia_project_url = fields.Char(string='URL del proyecto TuxAIA',
        config_parameter='website_openwebui_chat.project_url',
        help='Por ejemplo https://tuxaia.com. Vacio oculta Powered by TuxAIA.')

    def action_slimaia_save(self):
        self.ensure_one()
        if not self.env.user.has_group('base.group_system'):
            raise AccessError(_('Solo los administradores pueden configurar TuxAIA.'))
        path = (self.slimaia_debug_path or '/var/log/odoo/slimaia_debug.log').strip()
        if not os.path.isabs(path) or not path.endswith('.log'):
            raise ValidationError(_('Usa una ruta absoluta terminada en .log.'))
        if not 5 <= self.slimaia_idle_minutes <= 120:
            raise ValidationError(_('La caducidad debe estar entre 5 y 120 minutos.'))
        project_url = (self.tuxaia_project_url or '').strip()
        try:
            parsed = urlsplit(project_url)
            valid_url = parsed.scheme in ('http', 'https') and parsed.hostname and not parsed.username and not parsed.password
        except ValueError:
            valid_url = False
        if project_url and not valid_url:
            raise ValidationError(_('Usa una URL http:// o https:// sin credenciales, o deja el campo vacio.'))
        values = {
            'openwebui_active': 'True' if self.openwebui_active else 'False',
            'project_url': project_url,
            'support_embedded': 'True' if self.tuxaia_support_embedded else 'False',
            'support_expand': 'True' if self.tuxaia_support_expand else 'False',
            'openwebui_sales_model': (self.slimaia_sales_model_id or '').strip(),
            'openwebui_support_model': (self.slimaia_support_model_id or '').strip(),
            'debug_logging': 'True' if self.slimaia_debug_logging else 'False',
            'debug_prompt': 'True' if self.slimaia_debug_prompt else 'False',
            'debug_log_path': path,
            'session_idle_minutes': str(self.slimaia_idle_minutes),
        }
        values.update(self._cloudflare_values())
        for key, value in values.items():
            self.env['ir.config_parameter'].sudo().set_param('website_openwebui_chat.' + key, value)
        # No ejecutar res.config.settings.execute(): esta pantalla solo guarda
        # sus propios ajustes y nunca valores de otros modulos que no se muestran.
        return {'type': 'ir.actions.client', 'tag': 'reload'}

    @api.model
    def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
        result = super(TuxAIASettings, self).fields_view_get(
            view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=submenu)
        if view_type != 'form' or not result.get('arch'):
            return result
        # Compatibilidad con el bloque original: descubrir los campos por su
        # parametro, sin adivinar IDs de vistas ni depender de su traduccion.
        legacy_models, legacy_prompts = set(), set()
        for name, field in self._fields.items():
            parameter = getattr(field, 'config_parameter', '') or ''
            if parameter == 'website_openwebui_chat.openwebui_model':
                legacy_models.add(name)
            elif (parameter.startswith('website_openwebui_chat.') and
                  'prompt' in parameter.rsplit('.', 1)[-1] and
                  parameter != 'website_openwebui_chat.debug_prompt'):
                legacy_prompts.add(name)
        if not legacy_models and not legacy_prompts:
            return result
        root = etree.fromstring(result['arch'].encode('utf-8'))
        changed = False
        label = _('Modelo de Ventas (respaldo)')
        explanation = _('Este modelo solo se usa si Ventas esta vacio en el menu superior TuxAIA. '
                        'Configura alli los modelos de Ventas y Soporte, el registro y la caducidad. '
                        'El prompt y los parametros se gestionan en los perfiles de Open WebUI.')
        for node in root.iter():
            field_name = node.get('name') if node.tag == 'field' else node.get('for') if node.tag == 'label' else None
            if field_name in legacy_prompts:
                modifiers = json.loads(node.get('modifiers', '{}'))
                modifiers['invisible'] = True
                node.set('modifiers', json.dumps(modifiers)); node.set('invisible', '1')
                changed = True
            if field_name in legacy_models:
                node.set('string', label)
                if node.tag == 'field':
                    node.set('help', explanation)
                    note = etree.Element('div', {'class': 'text-muted', 'colspan': '2'})
                    note.text = explanation
                    node.addnext(note)
                changed = True
        if changed:
            result = dict(result, arch=etree.tostring(root, encoding='unicode'))
        return result
