odoo.define('website_openwebui_chat.presentation', function () {
    'use strict';
    var $modal, $launcher, $expand, $close, embedded=false, enabled=false, full=false;
    var home, next, oldOverflow='', previousFocus, tr;
    function expand(value) {
        if (!$modal || (value && !enabled)) return;
        if (value === full) return;
        full=value;
        if(full){
            previousFocus=document.activeElement;
            home=$modal[0].parentNode;next=$modal[0].nextSibling;
            oldOverflow=document.body.style.overflow;
            $modal.appendTo(document.body).removeClass('ow-hidden').addClass('ow-fullscreen');
            document.body.style.overflow='hidden';
            $modal.attr({'role':'dialog','aria-modal':'true','aria-label':'TuxAIA'});
        }else{
            $modal.removeClass('ow-fullscreen').removeAttr('aria-modal').attr('role','region');
            document.body.style.overflow=oldOverflow;
            if(home){if(next && next.parentNode===home)home.insertBefore($modal[0],next);else home.appendChild($modal[0]);}
        }
        $expand.attr({'aria-expanded':full?'true':'false','aria-label':full?tr('Reducir chat','Reduce chat'):tr('Ampliar chat','Expand chat'),title:full?tr('Reducir chat','Reduce chat'):tr('Ampliar chat','Expand chat')})
            .find('i').attr('class',full?'fa fa-compress':'fa fa-expand');
        $close.toggle(!embedded || full).attr({'aria-label':embedded?tr('Volver al chat incrustado','Back to embedded chat'):tr('Cerrar ventana del chat','Close chat window')});
        $launcher.toggleClass('ow-launcher-suppressed',embedded || full || !$modal.hasClass('ow-hidden'));
        var target=full ? $expand[0] : previousFocus;
        if(target && document.documentElement.contains(target))target.focus({preventScroll:true});
    }
    return {
        init:function(options){
            embedded=Boolean(options.embedded);enabled=Boolean(options.expand);tr=options.tr;
            $modal=$('#openwebui-chat-modal');$launcher=$('#openwebui-chat-button');$close=$('#ow-chat-close');
            $modal.attr({'role':'region','aria-label':'TuxAIA'});
            if(enabled){
                $expand=$('<button type="button" id="ow-chat-expand" aria-expanded="false">')
                    .attr({'title':tr('Ampliar chat','Expand chat'),'aria-label':tr('Ampliar chat','Expand chat')})
                    .append($('<i class="fa fa-expand" aria-hidden="true">')).insertBefore($close)
                    .on('click',function(){expand(!full);});
            }
            if(embedded){
                $modal.appendTo('#tuxaia-support-mount').addClass('ow-embedded').removeClass('ow-hidden');
                $('#tuxaia-support-entry').show();$close.hide();
                $launcher.addClass('ow-launcher-suppressed');
            }
            this.setAgent(options.agent);
            // Hide the launcher whenever the chat is visible: one penguin at a time.
            var observer=new MutationObserver(function(){
                $launcher.toggleClass('ow-launcher-suppressed',embedded || full || !$modal.hasClass('ow-hidden'));
            });
            observer.observe($modal[0],{attributes:true,attributeFilter:['class']});
            $launcher.toggleClass('ow-launcher-suppressed',embedded || !$modal.hasClass('ow-hidden'));
            document.addEventListener('keydown',function(event){
                if(!full)return;
                if(event.key==='Escape'){event.preventDefault();expand(false);return;}
                if(event.key!=='Tab')return;
                var elements=$modal.find('button,select,textarea,a[href],input').filter(':visible:not(:disabled)').toArray();
                if(!elements.length)return;
                var first=elements[0],last=elements[elements.length-1],active=document.activeElement;
                if(event.shiftKey && (active===first || !$modal[0].contains(active))){event.preventDefault();last.focus();}
                else if(!event.shiftKey && (active===last || !$modal[0].contains(active))){event.preventDefault();first.focus();}
            });
            window.addEventListener('pagehide',function(){if(full)expand(false);});
        },
        setAgent:function(agent){
            if(!enabled || !$expand)return;
            if(agent!=='support' && full)expand(false);
            $expand.toggle(agent==='support');
        },
        handleClose:function(id){
            if(id!=='ow-chat-close')return false;
            if(full){expand(false);if(embedded)return true;}
            return embedded;
        }
    };
});
