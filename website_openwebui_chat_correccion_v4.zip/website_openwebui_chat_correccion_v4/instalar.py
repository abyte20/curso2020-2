#!/usr/bin/env python3
"""Instala la correccion v4 con copia privada en /tmp. No instala paquetes globales."""
import ast
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile


def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else
                '/home/od/odoo/slimbook/website_openwebui_chat').resolve()
    source = Path(__file__).resolve().parent
    controller = root / 'controllers' / 'main.py'
    widget = root / 'static' / 'src' / 'js' / 'chat_widget.js'
    for target in (controller, widget):
        if not target.is_file() or target.is_symlink():
            raise SystemExit('No se ha cambiado nada. Revisa la ruta: %s' % target)
        if not os.access(str(target.parent), os.W_OK):
            raise SystemExit('No se ha cambiado nada. Sin permiso de escritura en: %s' % target.parent)
    pairs = [(source/'main.py', controller), (source/'chat_widget.js', widget),
             (source/'openwebui_transport.py', root/'controllers'/'openwebui_transport.py')]
    vendor = source/'owui_websocket'
    if not (vendor/'__init__.py').is_file() or not (vendor/'LICENSE').is_file():
        raise SystemExit('Paquete incompleto: descomprime todo el ZIP, incluida la carpeta owui_websocket.')
    for item in sorted(vendor.iterdir()):
        if item.is_file() and (item.suffix == '.py' or item.name in ('LICENSE', 'ORIGEN.txt')):
            pairs.append((item, root/'controllers'/'owui_websocket'/item.name))
    for original, target in pairs:
        if not original.is_file() or target.is_symlink() or root not in target.resolve().parents:
            raise SystemExit('No se ha cambiado nada. Ruta no valida: %s' % target)
        if original.suffix == '.py':
            ast.parse(original.read_text(encoding='utf-8'), filename=original.name)
    backup = Path(tempfile.mkdtemp(prefix='website_openwebui_chat_backup_v4_', dir='/tmp'))
    metadata_default = controller.stat()
    staged, replaced, records = [], [], []
    try:
        for original, target in pairs:
            existed = target.exists()
            relative = str(target.relative_to(root))
            records.append({'path':relative, 'existed':existed})
            if existed:
                saved = backup/relative
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(target), str(saved))
            if not target.parent.exists():
                target.parent.mkdir(mode=0o755, parents=True)
                if os.geteuid() == 0:
                    os.chown(str(target.parent), metadata_default.st_uid, metadata_default.st_gid)
            metadata = target.stat() if existed else metadata_default
            fd, name = tempfile.mkstemp(prefix='.openwebui-v4-', dir=str(target.parent))
            staged.append(Path(name))
            with os.fdopen(fd, 'wb') as stream:
                stream.write(original.read_bytes());stream.flush();os.fsync(stream.fileno())
                os.fchmod(stream.fileno(), stat.S_IMODE(metadata.st_mode) if existed else 0o644)
                if (os.geteuid(), os.getegid()) != (metadata.st_uid, metadata.st_gid):
                    os.fchown(stream.fileno(), metadata.st_uid, metadata.st_gid)
        (backup/'archivos.json').write_text(json.dumps({'module':str(root),'files':records}, indent=2),encoding='utf-8')
        for temporary, (_, target), record in zip(staged, pairs, records):
            os.replace(str(temporary), str(target))
            replaced.append((target,record))
    except Exception:
        for target, record in reversed(replaced):
            if record['existed']:
                shutil.copyfile(str(backup/record['path']), str(target))
            else:
                target.unlink()
        print('Instalacion interrumpida. Copia: %s' % backup,file=sys.stderr)
        raise
    finally:
        for temporary in staged:
            if temporary.exists():temporary.unlink()
    print('Instalado: native-profile-v4. Copia privada: %s' % backup)
    print('Reinicia Odoo, actualiza website_openwebui_chat en Aplicaciones y recarga con Ctrl+F5.')
    print('En F12 > Consola debe aparecer [SlimAIA] y native-profile-v4.')
    print('No se modifican el prompt, parametros, documentos ni chats de Open WebUI.')
    print('No se cambian el manifiesto, autoria, CSS o plantillas del modulo.')


if __name__ == '__main__':
    main()
