# SlimAIA — corrección native-profile-v4

Odoo 13 / Open WebUI 0.11.4. Sustituye el enfoque de dos fases de la revisión anterior.

## Instalar

Descomprime **todo** el ZIP, incluida `owui_websocket`. Desde la carpeta descomprimida ejecuta:

```bash
python3 instalar.py /home/od/odoo/slimbook/website_openwebui_chat
```

El instalador guarda una copia privada de los archivos sustituidos en `/tmp/website_openwebui_chat_backup_v4_…` y muestra la ruta. Copia el controlador, el widget, el transporte y su dependencia privada. No ejecuta pip, no reinicia servicios, no cambia la autoría ni el manifiesto del módulo.

Después:

1. Reinicia Odoo con el procedimiento de tu instalación.
2. En Aplicaciones, actualiza `website_openwebui_chat` para regenerar los recursos JavaScript.
3. Recarga la web con **Ctrl+F5**.
4. Abre **F12 → Consola**: debe aparecer `[SlimAIA]` con `native-profile-v4`.

No basta con copiar solamente `main.py`: ahora importa `openwebui_transport.py` y la carpeta privada `owui_websocket`. No hace falta cambiar CSS ni plantillas; el widget actualiza el título al inicializarse.

La clave y el identificador de modelo configurados en Odoo se conservan. La referencia de sesión de v3 también se conserva: actualizar el código no crea otra conversación si esa sesión sigue siendo válida. No se borran ni se fusionan chats.

## Qué fallaba en v3

- El controlador exigía contenido documental antes de devolver cualquier respuesta, incluso ante un saludo. El error «No he podido recuperar…» lo escribía el propio controlador; no demostraba por sí solo que Open WebUI no hubiera consultado documentos.
- El historial excluía mensajes con `error` y ciertos mensajes sin una marca propia del controlador. De ahí las respuestas desaparecidas al recargar.
- Open WebUI 0.11.4 puede guardar el texto del asistente en `output` dejando `content` vacío. Ahora se leen ambos formatos.
- La apertura/cierre del panel no se guardaba.
- La integración añadía instrucciones y fijaba temperatura en una segunda generación. Se han eliminado ambas cosas.

## Prompt y parámetros

La petición usa el identificador del perfil configurado en Odoo y el mensaje del cliente sin reescribirlo. No se envían mensajes `system`, instrucciones adicionales, `params`, temperatura, `top_k`, `top_p`, límites de salida ni un modo de function calling propio.

En el código publicado de Open WebUI **v0.11.4**, `main.py` combina los valores globales con los del perfil y después con las sobreescrituras de la petición. Esta revisión no aporta sobreescrituras de generación. El backend de Open WebUI aplica el prompt del perfil y carga del chat el historial y las salidas de herramientas.

Se trasladan las herramientas, habilidades, filtros opcionales y funciones activadas por defecto en los metadatos del perfil. Las capacidades y los permisos siguen siendo comprobados por Open WebUI. No se copian ajustes personales de otro chat abierto en la interfaz web ni sus interruptores temporales.

Campos operativos que sí envía el conector: identificadores del chat y del mensaje, sesión Socket.IO autenticada, `stream: true` y tareas automáticas de título/etiquetas/sugerencias desactivadas para conservar los títulos solicitados. No impone `function_calling: native`: hereda ese ajuste. Si el perfil tiene `stream_response: false`, Open WebUI puede desactivar el streaming; el conector no modifica ese valor a escondidas.

Los registros muestran la configuración **leída** del perfil y que el conector no añade sobreescrituras. No afirman conocer los parámetros efectivos recibidos por llama.cpp: esta API no los devuelve. Lo indica expresamente `engine_effective_parameters: not_reported_by_api`.

## Respuesta progresiva y conservación

Se realiza una sola petición de generación por turno. Open WebUI ejecuta las herramientas y produce la respuesta. El conector escucha el canal autenticado Socket.IO y transmite sus eventos de texto a Odoo. No hace una segunda generación ni fragmenta artificialmente una respuesta terminada.

La conexión usa WebSocket; si Open WebUI rechaza ese transporte porque utiliza polling de Socket.IO, el cliente admite ese modo. No cambia las opciones del servidor. La dependencia WebSocket se incluye como paquete privado, con su licencia, compatible con Python 3.6+, sin modificar dependencias globales de Odoo.

Cada conexión filtra por chat y mensaje antes de encolar eventos. No muestra eventos de otras conversaciones de la cuenta API. La conexión se cierra al finalizar. Se consulta el estado guardado como respaldo cada cinco segundos durante un turno, no para simular tokens. Si el canal falla tras terminar, puede recuperar la respuesta guardada y lo registra como `recovered_after_disconnect`; no lo llama streaming.

Recargar o cerrar la página no cancela el trabajo remoto. Al volver, se recupera el historial y, si sigue pendiente, se consulta su estado cada cinco segundos. La reapertura recupera el resultado guardado; no vuelve a enviar la pregunta. Un proxy que acumule las respuestas HTTP aún puede retrasar su visualización; el controlador envía `X-Accel-Buffering: no` y los tiempos del navegador permiten detectar esa diferencia.

## Interfaz e historial

- Cabecera: **SlimAIA - Asistente Inteligencia Artificial**.
- Espera: **SlimAIA está pensando…**.
- Se recuerdan apertura y cierre del panel en la pestaña del navegador. En la primera carga tras v3, si existe historial y no hay preferencia anterior, se abre el panel.
- Se restauran mensajes del cliente, respuestas del asistente y errores ya guardados.
- No se muestra un saludo local haciéndolo pasar por una respuesta del modelo.
- Sigue habiendo un chat por conversación de la sesión de Odoo, con correo para usuarios identificados y fecha/hora de Madrid más tres cifras para visitantes.
- Si caduca la sesión o se borran sus cookies, se pierde la relación local con esa conversación, aunque el chat permanezca en Open WebUI. No se añade una lista de conversaciones entre dispositivos.

## Registros del navegador

El widget escribe pocas entradas por turno, nunca por token. Conserva como máximo **60 entradas** en memoria; las consultas periódicas de recuperación no repiten registros. Las entradas no contienen mensajes, prompt, documentos, enlaces privados, correo, API key, argumentos de herramientas ni identificadores del chat remoto.

Datos registrados:

- Revisión instalada y coincidencia entre el modelo configurado y el perfil leído.
- Existencia del prompt y valores numéricos de generación presentes en el perfil.
- Ausencia de instrucciones y parámetros de generación añadidos por el conector.
- Transporte conectado, aceptación del turno, tiempo al primer texto y duración.
- Cantidad de actualizaciones de texto recibidas y cantidad de bloques HTTP leídos por el navegador.
- Contadores de búsquedas de conocimientos, lectura de archivos y resultados de herramientas observados. Un contador no certifica que el contenido baste para responder correctamente.

Para copiar el diagnóstico después de una consulta, ejecuta en F12 → Consola:

```javascript
JSON.stringify(SlimAIADebug.snapshot(), null, 2)
```

Para silenciar la consola durante esa carga de página:

```javascript
SlimAIADebug.setEnabled(false)
```

Para borrar el pequeño registro en memoria:

```javascript
SlimAIADebug.clear()
```

En los registros de Odoo se escribe un resumen por turno con el mismo identificador aleatorio de petición. No se vuelcan cabeceras, payloads ni conversaciones. Si no aparece la revisión nueva, el navegador o el servidor aún tiene la versión anterior; no es una prueba válida del nuevo conector.

## Validación realizada y pendiente

Verificaciones locales realizadas:

- Cliente real contra servidor **Socket.IO/Engine.IO real** de prueba, tanto WebSocket como polling, incluida autenticación y ping/pong.
- Primer texto recibido antes de terminar la generación simulada.
- Una sola llamada de generación por mensaje, sin prompt ni parámetros añadidos, y reutilización del chat.
- Saludo con cero documentos, restauración de respuestas solo en `output` y restauración de los errores de v3.
- Separación de identidades y descarte de eventos de otros chats.
- Lectura de las salidas estructuradas del informe real que aportaste.
- Widget con jQuery oficial de Odoo 13 en DOM simulado: nombre, apertura/cierre tras recarga, fragmentos UTF-8, reemplazos de texto, límites del registro y ausencia de contenido privado en él.
- Instalador sobre un módulo temporal y comprobación de sintaxis compatible con Python 3.6.

No se ha ejecutado contra tu servidor ni con tu modelo: la generación y la API REST de las pruebas son simuladas. La fidelidad de las respuestas documentales sigue dependiendo del perfil, las herramientas, los documentos y el modelo de tu Open WebUI. La integración entrega su respuesta y permite observar lo que sucede; no sustituye esa respuesta por un texto inventado por el conector.

Prueba práctica breve: envía `Hola`, después tu consulta del Creative y recarga con el panel abierto. Comprueba las respuestas en el mismo chat de Open WebUI y el registro `[SlimAIA]`. Si falla, el registro anterior permite distinguir conexión, generación, uso de herramientas y acumulación de fragmentos sin compartir conversaciones ni claves.

## Código de referencia contrastado

- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/main.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/socket/main.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/utils/middleware.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/src/lib/components/chat/Chat.svelte
- https://docs.openwebui.com/reference/server-side-tool-calling/

La copia de seguridad contiene `archivos.json`, con los archivos originales sustituidos y los añadidos por esta revisión. Para revertir, restaura el controlador y el widget desde esa copia, reinicia Odoo y actualiza los recursos del módulo. Los auxiliares nuevos dejan de utilizarse al restaurar el controlador antiguo; no es necesario borrar chats.
