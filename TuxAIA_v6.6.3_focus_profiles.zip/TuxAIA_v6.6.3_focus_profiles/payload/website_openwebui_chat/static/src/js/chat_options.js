odoo.define('website_openwebui_chat.options', function (require) {
    'use strict';
    var options = require('web_editor.snippets.options');
    var presentation = require('website_openwebui_chat.presentation');
    // Odoo 13 uses _setActive and (previewMode, value, $option).
    options.registry.TuxAIAChatOptions = options.Class.extend({
        defaultAgent: function (previewMode, value) {
            if (previewMode || ['sales', 'support'].indexOf(value) < 0) return;
            this.$target.attr('data-tuxaia-default-agent', value);
            presentation.updateGreeting(this.$target[0], value);
        },
        _setActive: function () {
            this._super.apply(this, arguments);
            var value = this.$target.attr('data-tuxaia-default-agent') === 'sales' ? 'sales' : 'support';
            this.$el.find('[data-default-agent]').each(function () {
                $(this).toggleClass('active', this.getAttribute('data-default-agent') === value);
            });
        }
    });
});
