{
    'name': 'Website Open WebUI Chatbot',
    'summary': 'Chat de Ventas y Soporte conectado a Open WebUI',
    'category': 'Website',
    'version': '13.0.2.0.4',
    'depends': ['website'],
    'data': ['views/slimaia_settings.xml', 
        'views/res_config_settings_views.xml',
        'views/templates.xml',
        'views/snippets.xml',
    ],
    'installable': True,
    'application': False,
}
