# TuxAIA 6.6.3 · Conversación estable y perfil del bloque · Odoo 13

Parche sobre la versión 6.6.2 de `website_openwebui_chat`. Versión técnica: `13.0.2.0.4`.

## Qué cambia

- Al alternar entre navegador y terminal, los mensajes permanecen en pantalla. Se conservan la selección de texto, el desplazamiento y el borrador. Los mensajes que no cambian no se vuelven a dibujar ni a animar.
- Recuperar el foco ya no descarga el historial en cada ocasión. Si han pasado al menos 30 segundos desde la última comprobación, puede comprobar la sesión con una petición ligera a Odoo que no consulta Open WebUI ni renueva la caducidad.
- Tras una ausencia de al menos un minuto, una reconexión o un fallo pendiente, puede sincronizar el historial en segundo plano. Actualiza solamente los mensajes diferentes. Durante una respuesta en curso conserva el flujo activo, sin iniciar otra recuperación del historial por foco.
- Un flotante cerrado que todavía no se ha utilizado no crea la sesión ni solicita el historial. Sigue consultándose la configuración para saber si el chat está habilitado.
- El catálogo del editor muestra **TuxAIA · Chat**. Los ajustes del bloque permiten elegir **Chat predeterminado: Ventas / Soporte**.
- Los bloques existentes mantienen Soporte por defecto. Una elección explícita del visitante o una conversación iniciada conserva su perfil dentro de la sesión; el ajuste del bloque no fuerza un cambio.
- El saludo estándar se adapta al perfil. Se conservan los textos de bienvenida que hayas personalizado.
- El bloque de Ventas funciona aunque Soporte esté desactivado. Se conserva la activación independiente del bloque de `/support`, los bloques del editor y la ampliación.
- Las consultas internas de configuración y estado no utilizan redirecciones de idioma.

Se mantienen tu imagen original, los estados de actividad, los puntos animados y la ampliación de Ventas y Soporte. Los adjuntos del chatbot y el historial permanente siguen fuera de esta versión. El parche de `website_profile_custom` para traducir el portal sigue siendo independiente.

## Instalación

Sube `TuxAIA_v6.6.3_focus_profiles.zip` a `/home/od/` y ejecuta como usuario `od`:

```bash
cd /home/od
unzip TuxAIA_v6.6.3_focus_profiles.zip
cd TuxAIA_v6.6.3_focus_profiles
python3 instalar.py --check /home/od/odoo/slimbook
```

Sobre una 6.6.2 sin modificaciones debe indicar **10 archivos pendientes**. Si detecta cambios ajenos al paquete, se detiene sin sobrescribirlos. No fuerces la instalación: conserva la salida para revisarla.

Conserva una copia de seguridad de la base de datos y **detén Odoo** mediante vuestro procedimiento habitual. Después aplica:

```bash
python3 instalar.py /home/od/odoo/slimbook
```

El instalador guarda automáticamente los archivos anteriores en `copias/tuxaia_v663_backup_...`, junto al instalador, y muestra su ubicación. No modifica la base de datos ni reinicia el servicio.

**Arranca Odoo** y, en **Aplicaciones**, quita el filtro «Aplicaciones», busca `website_openwebui_chat` y pulsa **Actualizar**. No basta con reiniciar el servicio o actualizar la lista de aplicaciones. Este parche no requiere actualizar `helpdesk_mgmt_custom`.

Recarga la web y el editor con **Ctrl+F5**.

## Elegir el perfil del bloque

1. Edita la página y coloca **TuxAIA · Chat**, o selecciona un bloque existente.
2. Abre sus opciones y elige **Chat predeterminado → Ventas** o **Soporte**.
3. Guarda la página. Para comprobar el valor inicial sin una elección anterior, usa una sesión nueva del navegador.

La opción global para permitir bloques del editor debe estar activada en Ajustes → TuxAIA. El perfil elegido debe estar habilitado y configurado.

Los bloques de una misma página comparten la interfaz del chat. El valor predeterminado corresponde al bloque activo; no crea una conversación simultánea independiente para cada bloque.

## Comprobación en vuestro servidor

1. Abre chat y terminal en dos mitades del monitor. Selecciona un comando del chat, deja un borrador y desplázate hacia arriba. Alterna repetidamente entre ambas ventanas: el contenido debe permanecer estable.
2. Haz lo mismo mientras llega una respuesta. Debe continuar sin reconstruir los mensajes anteriores.
3. Tras más de un minuto fuera, vuelve: puede haber sincronización, pero el historial que no haya cambiado debe conservar sus nodos y su posición.
4. Prueba un bloque nuevo con Ventas y otro con Soporte. Comprueba sus saludos y el selector del visitante.
5. Comprueba que el editor guarda el perfil y no guarda los mensajes del chat como contenido de la página.

En la consola, `TuxAIADebug.presentation()` y el registro `widget_loaded` de `TuxAIADebug.snapshot()` identifican la revisión `tuxaia-v6.6.3-ui`.

La caducidad, el cierre de sesión o un cambio de identidad siguen retirando el contenido privado cuando se detectan. Una navegación real o restauración desde la caché de navegación puede recuperar la conversación; no equivale a alternar el foco con la terminal.

## Restaurar los archivos

Con Odoo detenido, usa la ruta real que imprimió el instalador:

```bash
python3 instalar.py --restore /ruta/real/tuxaia_v663_backup_XXXX /home/od/odoo/slimbook
```

Después arranca Odoo, actualiza `website_openwebui_chat` y recarga. Se comprueba que los archivos no hayan sufrido cambios posteriores antes de restaurarlos. La copia del instalador contiene archivos; no sustituye la copia de seguridad de la base de datos. Si necesitas una reversión completa tras actualizar vistas en Odoo, restaura también la base de datos correspondiente.

## Validación y alcance

Las comprobaciones aisladas cubren sesiones, usuario, sitio, caducidad, origen de peticiones y separación de perfiles. Las pruebas de navegador emplean respuestas simuladas e incluyen alternancia de foco, conservación de nodos/selección/borrador/desplazamiento, respuesta en curso, sincronización y elección de perfil con el código de opciones de Odoo 13.

El instalador verifica huellas de los archivos, permite repetir la instalación sin cambios y dispone de restauración protegida. Falta comprobar la integración completa con vuestra base de datos, tema y Open WebUI reales. Este paquete no se ha instalado en vuestro servidor.
