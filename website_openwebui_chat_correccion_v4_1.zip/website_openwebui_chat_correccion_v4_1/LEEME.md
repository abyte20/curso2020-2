# SlimAIA — corrección native-profile-v4.1

## Qué corrige

V4 utilizaba la misma credencial para HTTP y Socket.IO. En el código publicado de Open WebUI 0.11.4, HTTP acepta claves API, pero `get_verified_user_by_token`, utilizada por Socket.IO, decodifica un JWT de sesión. Una clave API válida para HTTP no se convierte por ello en una sesión autenticada del socket. Esta incompatibilidad se ha reproducido en las pruebas locales.

Además, el endpoint del perfil devuelve `params: {}` a usuarios con acceso de solo lectura. Por eso el registro anterior podía indicar falsamente que no había prompt. Ahora distingue parámetros ocultos de parámetros visibles: `profile_prompt_present: null` significa que el conector no puede determinarlo con esa respuesta de la API.

## Instalar

Descomprime **todo** el ZIP y ejecuta desde su carpeta:

```bash
python3 instalar.py /home/od/odoo/slimbook/website_openwebui_chat
```

El instalador crea una copia privada en `/tmp/website_openwebui_chat_backup_v41_…`. Copia el controlador, el widget y los auxiliares incluidos. No requiere pip, no modifica modelos ni permisos, no cambia la autoría del módulo y no elimina chats.

Después reinicia Odoo, actualiza `website_openwebui_chat` en Aplicaciones y recarga la web con Ctrl+F5. En F12 → Consola debe aparecer `[SlimAIA]` con la revisión `native-profile-v4.1`.

La referencia de sesión existente se conserva: no se crea otro chat por actualizar el módulo. No cambies la clave API por una clave de administrador; eso no convierte una clave API en JWT.

## Transporte con la clave API actual

Se hace una sola petición nativa de generación, con la clave API y el mismo chat. Se conserva el `session_id` lógico que activa ese flujo HTTP; no se intenta autenticarlo como socket. Este es el mismo tipo de flujo nativo HTTP que ya funcionó en el diagnóstico D.

El endpoint `GET /api/v1/chats/{id}` de 0.11.4 incorpora las respuestas en curso mediante `overlay_response_streams`. La integración lee ese estado **como máximo una vez por segundo, solo mientras espera el turno**, y envía al navegador únicamente el texto nuevo o una corrección de texto si el servidor lo reemplaza. No vuelve a generar la respuesta y no introduce un efecto de escritura artificial.

Esto proporciona actualizaciones por bloques durante la generación. **No equivale a recibir cada token por WebSocket**. La velocidad visible depende de cuándo Open WebUI actualiza su estado y de si un proxy acumula las respuestas HTTP. Si solo aparece texto al terminar, el registro lo refleja mediante `updates_before_done: 0`.

Cada consulta de estado devuelve el chat, así que el coste depende del tamaño del historial y de sus herramientas; no se promete coste cero. No hay consultas periódicas cuando el turno ha terminado. Una recarga durante una respuesta pendiente mantiene la recuperación ya existente cada cinco segundos.

Si la credencial configurada es un JWT de sesión, se conserva el transporte Socket.IO de v4. No se solicita una contraseña ni se extrae un token del navegador. Un JWT tiene su propio vencimiento. Los errores de socket ahora identifican fase, clase de excepción y estado HTTP cuando existe, sin registrar los mensajes privados del servidor.

Las herramientas que necesitan respuestas de un navegador conectado no están implementadas por la vía HTTP; la recuperación de conocimientos con herramientas ejecutadas en el servidor sí usa ese flujo nativo.

## Prompt, parámetros e interfaz

- El conector no añade instrucciones, no reescribe la pregunta y no envía `params`, temperatura, `top_k`, `top_p`, límites de salida o un modo de function calling propio.
- Open WebUI aplica los parámetros y el prompt del perfil en el servidor aunque su API de lectura los oculte al usuario de integración.
- Los registros distinguen lo visible en el perfil de los parámetros efectivos del motor, que esta API no devuelve. `profile_parameters_visibility: hidden_read_only` no significa que falten los parámetros.
- Se mantienen los títulos de los chats, la cabecera «SlimAIA - Asistente Inteligencia Artificial», el estado «SlimAIA está pensando…», el historial y el estado abierto/cerrado del panel.
- Se siguen restaurando tanto `content` como las respuestas de `output` y los errores guardados. La integración no sobrescribe una respuesta del modelo con un mensaje local de falta de documentos.

Los únicos controles operativos propios siguen siendo los identificadores del chat/turno, la solicitud de transmisión y la desactivación de generación automática de títulos, etiquetas y sugerencias. Si el perfil desactiva su transmisión o limita sus herramientas, esa configuración no se cambia a escondidas.

## Diagnóstico seguro

Después de una consulta, ejecuta en F12 → Consola:

```javascript
JSON.stringify(SlimAIADebug.snapshot(), null, 2)
```

Con una clave API debes ver:

- `revision: native-profile-v4.1`
- `transport: http_live_snapshots`
- `phase: generation_accepted`
- Al terminar, `phase: completed`, `snapshots_received`, `progressive_updates` y `updates_before_done`.

`updates_before_done > 0` confirma que se recibió texto antes de la finalización. Los contadores de herramientas describen lo observado; no garantizan por sí solos una respuesta correcta.

El registro conserva como máximo 60 entradas por carga de página y no imprime una por token ni por lectura de estado. No contiene claves, cookies, prompt, documentos, mensajes, correo ni identificadores remotos del chat. Para compartir el diagnóstico basta este resultado; no hacen falta las cabeceras HTTP.

```javascript
SlimAIADebug.setEnabled(false) // Silenciar consola en esta carga de pagina.
SlimAIADebug.clear()           // Vaciar el registro local.
```

## Validación

Se ha probado localmente:

1. La distinción entre clave API y JWT utilizando la función `get_verified_user_by_token` publicada en 0.11.4, con sus dependencias simuladas, y un servidor Socket.IO/Engine.IO real de prueba.
2. Rechazo de la clave API por el socket y éxito de la vía HTTP con texto recibido antes de liberar el final de la generación simulada.
3. El comportamiento de `overlay_response_streams`, usando la función publicada de esa versión.
4. Un perfil con `write_access: false` y `params: {}`, que ahora se registra como oculto y no como ausencia de prompt.
5. Una sola generación por turno, mensajes intactos, ausencia de parámetros añadidos, reutilización del chat y restauración de las respuestas.
6. Socket.IO con JWT, transporte alternativo polling, separación de identidades, lectura de las salidas del informe aportado e historial anterior.
7. Widget con jQuery de Odoo 13 en DOM simulado: recepción incremental, historial, nombre, apertura/cierre y registro limitado sin contenido.

No se ha probado contra tu instancia ni con tu clave. El modelo y la API REST de las pruebas son simulados. La comprobación pendiente es una consulta real tras instalar v4.1, con el diagnóstico anterior.

Fuentes contrastadas de la versión exacta:

- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/utils/auth.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/socket/main.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/routers/models.py
- https://github.com/open-webui/open-webui/blob/v0.11.4/backend/open_webui/routers/chats.py

Para revertir, restaura el controlador y el widget desde la copia indicada por el instalador, reinicia Odoo y actualiza los recursos del módulo. No borres chats.
