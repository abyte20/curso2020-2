import hashlib
import json
import logging
import random
from datetime import datetime
import time
import uuid
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from odoo import http
from odoo.http import request
from werkzeug.wrappers import Response

_logger = logging.getLogger(__name__)
REVISION = 'native-profile-v4.1'

from .openwebui_transport import EventChannel, TransportError


class IntegrationError(Exception):
    def __init__(self, message, status=502):
        super().__init__(message)
        self.status = status


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _event(kind, **values):
    return (json.dumps(dict(type=kind, **values), ensure_ascii=False) + '\n').encode('utf-8')


def _output_text(output):
    parts = []
    for item in output or []:
        if not isinstance(item, dict) or item.get('type') != 'message':
            continue
        if item.get('role', 'assistant') != 'assistant':
            continue
        for part in item.get('content') or []:
            if isinstance(part, dict) and part.get('type') in ('output_text', 'text') and isinstance(part.get('text'), str):
                parts.append(part['text'])
    return '\n\n'.join(parts)


def _node_text(node):
    # En 0.11.4 el resultado final puede vivir solo en output.
    text = _output_text(node.get('output'))
    if text:
        return text
    if node.get('output') and node.get('done') is not True:
        return ''  # No publicar razonamiento o resultados de herramientas como respuesta.
    content = node.get('content')
    if isinstance(content, str) and content:
        return content
    if node.get('error'):
        return 'Open WebUI registró un error en este turno.'
    return ''


def _messages_from_chat(chat, for_model=False):
    history = chat.get('history') or {}
    nodes = history.get('messages') or {}
    current = history.get('currentId')
    result, seen = [], set()
    while current:
        if current in seen or current not in nodes:
            raise IntegrationError('El historial del chat está dañado.')
        seen.add(current)
        node = nodes[current]
        if node.get('role') in ('user', 'assistant'):
            text = _node_text(node)
            if text and not (for_model and node.get('error')):
                message = {'role': node['role'], 'content': text}
                if not for_model:
                    message.update(id=current, error=bool(node.get('error')),
                                   done=node.get('done', node['role'] == 'user'))
                result.append(message)
        current = node.get('parentId')
    return list(reversed(result))


class LiveOutput:
    """Reconstruye eventos de texto/instantaneas sin mostrar razonamiento ni herramientas."""
    def __init__(self):
        self.items = []
        self.text = ''
        self.done = False
        self.error = False
        self.events = 0
        self.knowledge_calls = set()
        self.file_reads = set()
        self.tool_outputs = set()

    def _item(self, index):
        while len(self.items) <= index:
            self.items.append({})
        return self.items[index]

    def apply(self, event):
        self.events += 1
        kind = event.get('type')
        data = event.get('data') or {}
        if not isinstance(data, dict):
            return self.text
        if kind == 'chat:message:error' or data.get('error'):
            self.error = True
        if kind in ('chat:completion', 'response:completion'):
            event_type = data.get('type', '')
            if isinstance(data.get('output'), list):
                self.items = data['output']
                self.text = _output_text(self.items)
            elif event_type.startswith('response.'):
                index = data.get('output_index', 0)
                if not isinstance(index, int) or index < 0 or index > 10000:
                    return self.text
                if event_type in ('response.output_item.added', 'response.output_item.done'):
                    self._item(index)
                    self.items[index] = data.get('item') or {}
                elif event_type in ('response.content_part.added', 'response.content_part.done',
                                    'response.output_text.delta', 'response.output_text.done'):
                    item = self._item(index)
                    item.setdefault('type', 'message')
                    item.setdefault('role', 'assistant')
                    parts = item.setdefault('content', [])
                    part_index = data.get('content_index', 0)
                    if not isinstance(part_index, int) or part_index < 0 or part_index > 10000:
                        return self.text
                    while len(parts) <= part_index:
                        parts.append({'type': 'output_text', 'text': ''})
                    if event_type.endswith('output_text.delta'):
                        parts[part_index]['text'] = parts[part_index].get('text', '') + data.get('delta', '')
                    elif event_type.endswith('output_text.done'):
                        parts[part_index]['text'] = data.get('text', parts[part_index].get('text', ''))
                    else:
                        parts[part_index] = data.get('part') or parts[part_index]
                elif event_type == 'response.completed' and isinstance((data.get('response') or {}).get('output'), list):
                    self.items = data['response']['output']
                # response.completed puede cerrar una ronda de herramientas.
                # Solo data.done en chat:completion finaliza el turno completo.
                self.text = _output_text(self.items)
            elif isinstance(data.get('content'), str):
                self.text = data['content']
            elif data.get('choices'):
                choice = data['choices'][0]
                value = (choice.get('delta') or choice.get('message') or {}).get('content')
                if isinstance(value, str):
                    self.text += value
            if data.get('done') is True:
                self.done = True
        elif kind in ('message', 'replace') and isinstance(data.get('content'), str):
            self.text = data['content'] if kind == 'replace' else self.text + data['content']
        for index, item in enumerate(self.items):
            if not isinstance(item, dict):
                continue
            identifier = item.get('call_id') or item.get('id') or str(index)
            if item.get('type') == 'function_call':
                if item.get('name') in ('search_knowledge_files', 'query_knowledge_files', 'query_knowledge_bases'):
                    self.knowledge_calls.add(identifier)
                if item.get('name') in ('view_file', 'view_knowledge_file'):
                    self.file_reads.add(identifier)
            elif item.get('type') == 'function_call_output':
                self.tool_outputs.add(identifier)
        return self.text

    def stats(self):
        return {'events_received': self.events, 'knowledge_calls': len(self.knowledge_calls),
                'file_reads': len(self.file_reads), 'tool_results': len(self.tool_outputs)}


class OpenWebUIClient:
    def __init__(self, url, api_key, model, timeout=150):
        self.url, self.model, self.timeout = url.rstrip('/'), model, timeout
        self.headers = {'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'}
        self.opener = build_opener(NoRedirect())

    def _open(self, method, path, payload=None, timeout=25):
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8') if payload is not None else None
        req = Request(self.url + path, data=data, headers=self.headers, method=method)
        try:
            return self.opener.open(req, timeout=max(1, timeout))
        except HTTPError as exc:
            raise IntegrationError('Open WebUI: HTTP %s en %s' % (exc.code, path), exc.code) from None
        except (URLError, OSError):
            raise IntegrationError('No se pudo conectar con Open WebUI.') from None

    def _json(self, method, path, payload=None, timeout=25):
        with self._open(method, path, payload, timeout) as response:
            if 'text/event-stream' in response.headers.get('Content-Type', ''):
                raise IntegrationError('Open WebUI devolvió un formato inesperado.')
            try:
                return json.load(response)
            except ValueError:
                raise IntegrationError('Open WebUI devolvió un JSON inválido.') from None

    def prepare(self, reference, question, title):
        """Se ejecuta antes de enviar HTTP para que Odoo pueda guardar su sesion."""
        profile = self._json('GET', '/api/v1/models/model?' + urlencode({'id': self.model}))
        chat_id = reference.get('chat_id') if reference else None
        chat = None
        if chat_id:
            try:
                record = self._json('GET', '/api/v1/chats/' + quote(chat_id, safe=''))
                chat = record.get('chat')
            except IntegrationError as exc:
                if exc.status != 404:
                    raise
                chat_id = None
            if chat_id:
                tasks = self._json('GET', '/api/tasks/chat/' + quote(chat_id, safe=''))
                current = ((chat.get('history') or {}).get('messages') or {}).get((chat.get('history') or {}).get('currentId')) or {}
                pending = current.get('done') is not True and current.get('odoo_pending_until', 0) > time.time()
                if tasks.get('task_ids') or pending:
                    raise IntegrationError('La respuesta anterior todavía está en curso.', 409)
        if not chat_id:
            chat = {'title': title, 'models': [self.model],
                    'history': {'currentId': None, 'messages': {}}, 'messages': []}
        if not isinstance(chat, dict):
            raise IntegrationError('Open WebUI no devolvió un chat válido.')
        messages = _messages_from_chat(chat, for_model=True)
        messages.append({'role': 'user', 'content': question})
        history = chat.setdefault('history', {'currentId': None, 'messages': {}})
        nodes = history.setdefault('messages', {})
        previous = history.get('currentId')
        user_id, assistant_id = str(uuid.uuid4()), str(uuid.uuid4())
        now = int(time.time())
        user_node = {'id': user_id, 'parentId': previous, 'childrenIds': [assistant_id],
                     'role': 'user', 'content': question, 'models': [self.model], 'timestamp': now}
        assistant = {'id': assistant_id, 'parentId': user_id, 'childrenIds': [], 'role': 'assistant',
                     'content': '', 'model': self.model, 'modelName': self.model, 'modelIdx': 0,
                     'done': False, 'timestamp': now, 'odoo_pending_until': now + self.timeout + 60}
        if previous:
            nodes[previous].setdefault('childrenIds', []).append(user_id)
        nodes[user_id], nodes[assistant_id] = user_node, assistant
        history['currentId'] = assistant_id
        chat['messages'] = list(nodes.values())
        if chat_id:
            self._json('POST', '/api/v1/chats/' + quote(chat_id, safe=''), {'chat': chat})
        else:
            created = self._json('POST', '/api/v1/chats/new', {'chat': chat})
            chat_id = created.get('id')
            if not isinstance(chat_id, str) or not chat_id:
                raise IntegrationError('Open WebUI no devolvió el identificador del chat.')
        return {'chat_id': chat_id, 'assistant_id': assistant_id, 'user_node': user_node,
                'chat': chat, 'messages': messages, 'profile': profile, 'trace': uuid.uuid4().hex[:12]}

    def _profile_diagnostic(self, ctx):
        params = ctx['profile'].get('params') or {}
        write_access = ctx['profile'].get('write_access')
        visibility = 'hidden_read_only' if write_access is False else ('visible' if write_access is True else 'not_confirmed')
        prompt_present = bool(params.get('system')) if write_access is True or params.get('system') else None
        names = ('temperature', 'top_k', 'top_p', 'min_p', 'max_tokens', 'num_ctx', 'seed',
                 'repeat_penalty', 'presence_penalty', 'frequency_penalty', 'stream_response',
                 'stream_delta_chunk_size')
        observed = {key: params[key] for key in names if isinstance(params.get(key), (int, float, bool))}
        if params.get('function_calling') in ('native', 'legacy'):
            observed['function_calling'] = params['function_calling']
        return {'revision': REVISION, 'request': ctx['trace'], 'phase': 'profile_read',
                'profile_read': True, 'profile_prompt_present': prompt_present,
                'profile_parameters_visibility': visibility,
                'configured_model_matches_profile': ctx['profile'].get('id') == self.model,
                'profile_is_preset': bool(ctx['profile'].get('base_model_id')),
                'profile_parameters': observed, 'parameter_overrides': [],
                'system_messages_added': 0, 'user_message_changed': False,
                'engine_effective_parameters': 'not_reported_by_api'}

    def _payload(self, ctx, session_id):
        # No params, system, tools ni modificacion de la pregunta.
        # Open WebUI 0.11.4 mezcla sus defaults con el perfil en main.py y
        # recupera del chat el historial y las salidas de herramientas.
        payload = {'model': self.model, 'messages': ctx['messages'], 'stream': True,
                   'chat_id': ctx['chat_id'], 'id': ctx['assistant_id'],
                   'user_message': ctx['user_node'], 'session_id': session_id,
                   'background_tasks': {'title_generation': False, 'tags_generation': False,
                                        'follow_up_generation': False}}
        meta = ctx['profile'].get('meta') or {}
        capabilities = meta.get('capabilities') or {}
        defaults = meta.get('defaultFeatureIds') or []
        payload['features'] = {key: key in defaults and capabilities.get(key, True)
                               for key in ('web_search', 'image_generation', 'code_interpreter', 'memory')}
        for source, destination in (('toolIds', 'tool_ids'), ('skillIds', 'skill_ids'),
                                    ('defaultFilterIds', 'filter_ids')):
            if meta.get(source):
                payload[destination] = meta[source]
        if meta.get('terminalId') and capabilities.get('terminal', True):
            payload['terminal_id'] = meta['terminalId']
        return payload

    def _chat(self, ctx):
        record = self._json('GET', '/api/v1/chats/' + quote(ctx['chat_id'], safe=''))
        chat = record.get('chat') or {}
        node = ((chat.get('history') or {}).get('messages') or {}).get(ctx['assistant_id']) or {}
        return chat, node

    def _mark_before_submission_error(self, ctx):
        # Solo se usa si no se ha solicitado generacion. Nunca sustituye una
        # respuesta del modelo por un error local de lectura de fuentes.
        chat, node = self._chat(ctx)
        if not node:
            return
        node.update(done=True, content='No se pudo iniciar la respuesta en Open WebUI.',
                    error={'content': 'turn_not_started'})
        chat['messages'] = list(chat['history']['messages'].values())
        self._json('POST', '/api/v1/chats/' + quote(ctx['chat_id'], safe=''), {'chat': chat})

    def _stream_snapshots(self, ctx):
        """La API HTTP admite claves API; overlay_response_streams publica texto en curso."""
        started = time.monotonic()
        deadline = started + self.timeout
        state = LiveOutput()
        displayed = ''
        first_text_ms = None
        updates, before_done, snapshots = 0, 0, 0
        diagnostic = self._profile_diagnostic(ctx)
        yield _event('status', text='SlimAIA está pensando…')
        yield _event('diagnostic', **diagnostic)
        yield _event('diagnostic', request=ctx['trace'], phase='transport_selected',
                     transport='http_live_snapshots', credential_kind='api_key', poll_interval_ms=1000)
        submitted = False
        try:
            # session_id no autentica un socket: activa el flujo nativo HTTP.
            # La autorizacion de esta peticion sigue siendo la clave API.
            session_id = 'odoo-api-' + uuid.uuid4().hex
            submitted = True
            try:
                accepted = self._json('POST', '/api/chat/completions', self._payload(ctx, session_id))
            except IntegrationError as exc:
                if exc.status in (400, 401, 403, 404, 422):
                    submitted = False
                raise
            if not isinstance(accepted, dict) or accepted.get('status') is not True:
                submitted = False
                raise IntegrationError('Open WebUI no confirmó el inicio del turno.')
            yield _event('diagnostic', request=ctx['trace'], phase='generation_accepted')
            last_heartbeat = time.monotonic()
            while time.monotonic() < deadline:
                _, node = self._chat(ctx)
                snapshots += 1
                if not node:
                    raise IntegrationError('Open WebUI no devolvió el turno solicitado.')
                if node.get('error'):
                    raise IntegrationError('Open WebUI registró un error en este turno. Revisa su registro.')
                if isinstance(node.get('output'), list) and node['output']:
                    state.apply({'type': 'chat:completion', 'data': {'output': node['output']}})
                text = _node_text(node)
                if text != displayed:
                    if first_text_ms is None and text:
                        first_text_ms = round((time.monotonic() - started) * 1000)
                        yield _event('diagnostic', request=ctx['trace'], phase='first_text', elapsed_ms=first_text_ms)
                    updates += 1
                    if node.get('done') is not True:
                        before_done += 1
                    if text.startswith(displayed):
                        yield _event('delta', text=text[len(displayed):])
                    else:
                        yield _event('replace', text=text)
                    displayed = text
                if node.get('done') is True:
                    stats = state.stats()
                    stats.pop('events_received', None)
                    yield _event('diagnostic', request=ctx['trace'], phase='completed',
                                 transport='http_live_snapshots', snapshots_received=snapshots,
                                 progressive_updates=updates, updates_before_done=before_done,
                                 first_text_ms=first_text_ms,
                                 elapsed_ms=round((time.monotonic() - started) * 1000), saved=True, **stats)
                    _logger.info('%s request=%s transport=http_live_snapshots snapshots=%s updates_before_done=%s',
                                 REVISION, ctx['trace'], snapshots, before_done)
                    yield _event('done', saved=True)
                    return
                if time.monotonic() - last_heartbeat > 5:
                    yield _event('heartbeat')
                    last_heartbeat = time.monotonic()
                # Una lectura a la vez, como maximo una por segundo. No hay
                # sondeo cuando termina el turno ni nuevas generaciones.
                time.sleep(1)
            raise IntegrationError('Se agotó el tiempo de espera. Recarga para recuperar el turno; no reenvíes todavía la pregunta.')
        except GeneratorExit:
            raise
        except Exception as exc:
            if not submitted:
                try:
                    self._mark_before_submission_error(ctx)
                except Exception:
                    pass
            _logger.warning('%s request=%s failure=%s', REVISION, ctx['trace'], type(exc).__name__)
            yield _event('diagnostic', request=ctx['trace'], phase='error', code='http_turn_failed',
                         transport='http_live_snapshots', exception_type=type(exc).__name__)
            yield _event('error', text=str(exc) if isinstance(exc, IntegrationError) else 'Se interrumpió la consulta HTTP a Open WebUI.')

    def stream(self, ctx):
        credential = self.headers['Authorization'][7:]
        if credential.count('.') != 2:
            yield from self._stream_snapshots(ctx)
            return
        yield from self._stream_socket(ctx)

    def _stream_socket(self, ctx):

        started = time.monotonic()
        deadline = started + self.timeout
        channel = EventChannel(self, self.timeout)
        channel.chat_id, channel.message_id = ctx['chat_id'], ctx['assistant_id']
        state = LiveOutput()
        displayed = ''
        submitted = False
        first_text_ms = None
        text_updates = 0
        last_check = started
        try:
            yield _event('status', text='SlimAIA está pensando…')
            yield _event('diagnostic', **self._profile_diagnostic(ctx))
            channel.connect()
            yield _event('diagnostic', request=ctx['trace'], phase='events_connected', transport=channel.kind)
            submitted = True
            try:
                accepted = self._json('POST', '/api/chat/completions', self._payload(ctx, channel.session_id))
            except IntegrationError as exc:
                if exc.status in (400, 401, 403, 404, 422):
                    submitted = False
                raise
            if not isinstance(accepted, dict) or accepted.get('status') is not True:
                submitted = False
                raise IntegrationError('Open WebUI no confirmó el inicio del turno.')
            yield _event('diagnostic', request=ctx['trace'], phase='generation_accepted')
            while time.monotonic() < deadline:
                event = channel.get(timeout=1)
                if event and event.get('transport_error'):
                    # Recuperar una respuesta ya terminada es posible; no se
                    # presenta como streaming ni se vuelve a generar el turno.
                    _, node = self._chat(ctx)
                    if node.get('done') and not node.get('error'):
                        final = _node_text(node)
                        if final != displayed:
                            yield _event('replace', text=final)
                        yield _event('diagnostic', request=ctx['trace'], phase='recovered_after_disconnect',
                                     live_text_updates=text_updates)
                        yield _event('done', saved=True)
                        return
                    raise IntegrationError('Se interrumpió el canal de respuesta. Recarga para recuperar el turno guardado; no hace falta reenviar la pregunta.')
                if event and event.get('chat_id') == ctx['chat_id'] and event.get('message_id') == ctx['assistant_id'] and not event.get('internal'):
                    state.apply(event.get('data') or {})
                    if state.error:
                        raise IntegrationError('Open WebUI registró un error al responder. Revisa el turno en Open WebUI.')
                    if state.text != displayed:
                        if first_text_ms is None and state.text:
                            first_text_ms = round((time.monotonic() - started) * 1000)
                            yield _event('diagnostic', request=ctx['trace'], phase='first_text', elapsed_ms=first_text_ms)
                        text_updates += 1
                        if state.text.startswith(displayed):
                            yield _event('delta', text=state.text[len(displayed):])
                        else:
                            yield _event('replace', text=state.text)
                        displayed = state.text
                    if state.done:
                        break
                if time.monotonic() - last_check > 5:
                    yield _event('heartbeat')
                    last_check = time.monotonic()
                    # Respaldo de finalizacion, no sondeo de tokens.
                    _, node = self._chat(ctx)
                    if node.get('error'):
                        raise IntegrationError('Open WebUI registró un error en este turno.')
                    if node.get('done'):
                        final = _node_text(node)
                        if final != displayed:
                            yield _event('replace', text=final)
                            displayed = final
                        break
            else:
                raise IntegrationError('Se agotó el tiempo de espera. El turno puede seguir en Open WebUI; recarga para recuperar su estado.')
            _, node = self._chat(ctx)
            if node.get('error'):
                raise IntegrationError('Open WebUI registró un error en este turno.')
            # Leer la forma persistida; no escribir ni sustituir el resultado.
            if node.get('done'):
                final = _node_text(node)
                if final != displayed:
                    yield _event('replace', text=final)
                    displayed = final
            diagnostic = dict(state.stats(), request=ctx['trace'], phase='completed',
                              first_text_ms=first_text_ms, live_text_updates=text_updates,
                              elapsed_ms=round((time.monotonic() - started) * 1000),
                              saved=bool(node.get('done')))
            _logger.info('%s request=%s events=%s updates=%s first_text_ms=%s knowledge_calls=%s file_reads=%s',
                         REVISION, ctx['trace'], state.events, text_updates, first_text_ms,
                         len(state.knowledge_calls), len(state.file_reads))
            yield _event('diagnostic', **diagnostic)
            yield _event('done', saved=bool(node.get('done')))
        except GeneratorExit:
            # Cerrar o recargar la web no cancela ni borra el turno remoto.
            raise
        except Exception as exc:
            public = str(exc) if isinstance(exc, IntegrationError) else 'No se pudo conectar con el canal de eventos de Open WebUI.'
            _logger.warning('%s request=%s failure=%s', REVISION, ctx['trace'], type(exc).__name__)
            if not submitted:
                try:
                    self._mark_before_submission_error(ctx)
                except Exception:
                    pass
            yield _event('diagnostic', request=ctx['trace'], phase='error',
                         code=exc.code if isinstance(exc, TransportError) else 'turn_failed',
                         transport_stage=getattr(exc, 'stage', None),
                         http_status=getattr(exc, 'http_status', None),
                         exception_type=getattr(exc, 'exception_type', type(exc).__name__),
                         **state.stats())
            yield _event('error', text=public)
        finally:
            channel.close()


class OpenWebUIChatController(http.Controller):
    def _settings(self):
        ICP = request.env['ir.config_parameter'].sudo()
        if ICP.get_param('website_openwebui_chat.openwebui_active', 'True') not in ['True', 'true', '1']:
            raise IntegrationError('Chat desactivado.', 503)
        url = (ICP.get_param('website_openwebui_chat.openwebui_url', 'http://95.120.141.203:8036') or '').strip()
        key = (ICP.get_param('website_openwebui_chat.openwebui_api_key', '') or '').strip()
        model = (ICP.get_param('website_openwebui_chat.openwebui_model', 'ventas-clone') or '').strip()
        parsed = urlsplit(url)
        if not key or not model or parsed.scheme not in ('http', 'https') or not parsed.netloc or parsed.username:
            raise IntegrationError('Revisa la URL, la clave y el modelo configurados en Odoo.', 503)
        try:
            timeout = max(30, int(ICP.get_param('website_openwebui_chat.openwebui_timeout', '240')))
        except (ValueError, TypeError):
            timeout = 240
        # La identidad se comprueba tambien tras iniciar/cerrar sesion: nunca
        # se restaura el chat de otra identidad a partir de datos del navegador.
        identity = '%s:%s' % (request.env.uid, request.website.id)
        signature = hashlib.sha256(('\0'.join((url, model, key, identity))).encode('utf-8')).hexdigest()
        return OpenWebUIClient(url, key, model, timeout), signature

    def _active(self, signature):
        active = request.session.get('openwebui_active_v3') or {}
        if active.get('signature') != signature:
            active = {'id': str(uuid.uuid4()), 'signature': signature}
            request.session['openwebui_active_v3'] = active
        return active

    def _title(self):
        user = request.env.user
        if not user._is_public():
            return (user.partner_id.email or user.login or user.name).strip()
        import pytz  # Dependencia de Odoo 13.
        zone = request.env['ir.config_parameter'].sudo().get_param(
            'website_openwebui_chat.openwebui_timezone', 'Europe/Madrid')
        try:
            timezone = pytz.timezone(zone)
        except pytz.UnknownTimeZoneError:
            timezone = pytz.timezone('Europe/Madrid')
        return datetime.now(timezone).strftime('%d-%m-%Y_%H:%M:%S') + '_%03d' % random.SystemRandom().randrange(1000)

    def _error(self, exc):
        return Response(str(exc), status=exc.status if exc.status in (400, 401, 403, 409, 503) else 502,
                        content_type='text/plain; charset=utf-8', headers={'Cache-Control': 'no-store'})

    @http.route('/website_chat/is_active', type='json', auth='public', website=True, csrf=False)
    def is_active(self):
        ICP = request.env['ir.config_parameter'].sudo()
        return {'active': ICP.get_param('website_openwebui_chat.openwebui_active', 'True') in ['True', 'true', '1']}

    @http.route('/website_chat/state', type='http', auth='public', website=True, methods=['GET'])
    def state(self, **kwargs):
        try:
            client, signature = self._settings()
            active = self._active(signature)
            reference = active.get('reference')
            messages, pending = [], False
            if reference:
                try:
                    record = client._json('GET', '/api/v1/chats/' + quote(reference['chat_id'], safe=''))
                    chat = record.get('chat')
                    if not isinstance(chat, dict):
                        raise IntegrationError('No se pudo recuperar el historial.')
                    messages = _messages_from_chat(chat)
                    nodes = (chat.get('history') or {}).get('messages') or {}
                    current = nodes.get((chat.get('history') or {}).get('currentId')) or {}
                    tasks = client._json('GET', '/api/tasks/chat/' + quote(reference['chat_id'], safe=''))
                    pending = bool(tasks.get('task_ids')) or (current.get('done') is not True and current.get('odoo_pending_until', 0) > time.time())
                except IntegrationError as exc:
                    if exc.status != 404:
                        raise
                    active = dict(active)
                    active.pop('reference', None)
                    request.session['openwebui_active_v3'] = active
            data = {'conversation_id': active['id'], 'messages': messages, 'pending': pending, 'revision': REVISION}
            return Response(json.dumps(data, ensure_ascii=False), content_type='application/json; charset=utf-8',
                            headers={'Cache-Control': 'no-store'})
        except IntegrationError as exc:
            return self._error(exc)

    @http.route('/website_chat/stream_message', type='http', auth='public', website=True, csrf=False, methods=['POST'])
    def stream_message(self, **post):
        params = dict(post, **request.params)
        if params.get('protocol') != REVISION:
            return Response('Actualiza el widget y recarga la página: versiones de controlador y widget distintas.', status=409)
        question = params.get('message')
        if not isinstance(question, str) or not question.strip():
            return Response('Mensaje vacío.', status=400)
        if len(question) > 16000:
            return Response('El mensaje es demasiado largo.', status=400)
        try:
            client, signature = self._settings()
            active = self._active(signature)
            if params.get('conversation_id') != active['id']:
                raise IntegrationError('La sesión ha cambiado. Recarga la página para recuperar tu conversación.', 409)
            ctx = client.prepare(active.get('reference'), question, self._title())
        except IntegrationError as exc:
            _logger.error('%s preparación fallida: %s', REVISION, exc)
            return self._error(exc)
        active = dict(active, reference={'chat_id': ctx['chat_id']})
        # Guardar antes de crear la respuesta iterable: Odoo persiste su sesion
        # al cerrar la peticion, antes de consumir el generador de streaming.
        request.session['openwebui_active_v3'] = active
        return Response(client.stream(ctx), headers={
            'Cache-Control': 'no-cache, no-store, must-revalidate', 'X-Accel-Buffering': 'no',
            'X-OpenWebUI-Protocol': REVISION,
        }, content_type='application/x-ndjson; charset=utf-8', direct_passthrough=True)
